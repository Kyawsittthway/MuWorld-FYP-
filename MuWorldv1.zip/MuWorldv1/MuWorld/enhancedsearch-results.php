<?php 
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
    <!-- CSS FILES -->
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 
    <link rel='stylesheet' href='CSS/test.css'> 
    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <!-- Javascripts -->

    <!-- ajax script for dynamic webpage -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <!-- Select2 script for form multiple options -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- custom-file-input script for file name to show up -->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
</head>
<body>
    <!--Research Section-->
    <section>
    <div class='container'>
        <h1>Search results</h1>
        <a href='dashboard2.php'><button class='btn btn-outline-danger fas fa-step-backward'></button></a>
        <?php
            //SQL statement for database, might be subjected to change!!**
            $sql = "SELECT * FROM ((`user` u 
            INNER JOIN `profile` p ON u.ID = p.ID)
            INNER JOIN `organisations` o ON o.orgid = p.Organisation)
            WHERE `Name` LIKE ? OR orgname LIKE ?;";

            $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
            
            //Condition to prepare the stmt variable if successful carrys on if not show fail message.
            if(!mysqli_stmt_prepare($stmt,$sql))
            {
                header("location: enhancedsearch-results.php?error=stmtfailed");
                exit();
            }
            $input = "%$_GET[input]%";
            mysqli_stmt_bind_param($stmt,"ss",$input,$input);
            mysqli_stmt_execute($stmt);
            $pic = 'no-image.png';
            $result = mysqli_stmt_get_result($stmt);
            if($numrows = mysqli_num_rows($result) >0)
            {
                while($row = mysqli_fetch_assoc($result))
                {

                    if(!empty(profileExists($con,$row['Email'])))
                    {
                    $profile = profileExists($con,$row['Email']);
                    $pic = $profile['ProfilePicture'];
                    }
                    
                    echo "
                    <!--Article List1 -->
                        <div class='card mt-5 border-5 pt-2 active pb-0 px-3'>
                            <div class='card-body '>
                                <div class='row'>
                                    <div class='col-12 '>
                                        <h4 class='card-title '>
                                        <img src='img/$pic' class='rounded-circle' onerror=this.src='img/beard.png' style='height:100px;'>
                                        <a href='profile.php?name=".$row['Name']."&token=".$row['Token']."'><b>$row[Name]</b></a>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ";
                }
            }
            else
            {
            echo "
            <div class='card mt-5 border-5 pt-2 active pb-0 px-3'>
                        <div class='card-body '>
                            <div class='row'>
                                <div class='col-12 '>
                                
                                    <h4 class='card-title '>
                                    No results found!!
                                    
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
            ";
            }
            mysqli_stmt_close($stmt);
            ?>
    </div>
    </section>
</body>
</html>