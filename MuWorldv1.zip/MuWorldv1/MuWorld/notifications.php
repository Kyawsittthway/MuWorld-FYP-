<?php
      if(isset($_SESSION['semail']))
      {
        //FOR TOTAL NOTIFICATIONS
        $numofrows;
        if($numofrows = checkNotifications($con,$_SESSION['suserid'])===false)
        {
          $numofrows = 0;
        }
        else
        {
          $numofrows = checkNotifications($con,$_SESSION['suserid']);
        }
        
        //FOR FRIEND NOTIFICATIONS
        $Fnumofrows;
        if($Fnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'friend')===false)
        {
          $Fnumofrows = 0;
        }
        else
        {
          $Fnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'friend');
        }
        
        //FOR RESERACH NOTIFICATIONS
        $Rnumofrows;
        if($Rnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'research')===false)
        {
          $Rnumofrows = 0;
        }
        else
        {
          $Rnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'research');
        }
        
        //FOR COMMENT NOTIFICATIONS
        $Cnumofrows;
        if($Cnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'comment')===false)
        {
          $Cnumofrows = 0;
        }
        else
        {
          $Cnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'comment');
        }

        //FOR REPORT NOTIFICATIONS
        $REnumofrows;
        if($REnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'report')===false)
        {
          $REnumofrows = 0;
        }
        else
        {
          $REnumofrows = checkNotificationsType($con,$_SESSION['suserid'],'report');
        }

        echo "
        <li class='nav-item dropdown'>
            <a class='nav-link' data-toggle='dropdown' href='#'>
              <i class='far fa-bell'></i>
              ";
              if($numofrows>0)
                echo "<span class='badge badge-warning navbar-badge'>$numofrows</span>";
              else
                echo "<span class='badge badge-warning navbar-badge'></span>";
         echo "</a>";
          echo "  
            <div class='dropdown-menu dropdown-menu-lg dropdown-menu-right'>
              <span class='dropdown-item dropdown-header'>$numofrows Notifications</span>
              ";
              if($Rnumofrows>0)
              {
              echo "
              <div class='dropdown-divider'></div>
              <a href='researchnote.php' class='dropdown-item' style='color:black;'>
                <i class='fas fa-envelope mr-2'></i> $Rnumofrows research notifications
                <!-- <span class='float-right text-muted text-sm'>3 mins</span> -->
              </a>
                   ";
              }
              if($Fnumofrows>0)
              {
                echo "
                <div class='dropdown-divider'></div>
                <a href='friendrequest.php' class='dropdown-item' style='color:black;'>
                  <i class='fas fa-users mr-2'></i> $Fnumofrows friend requests
                  <!--<span class='float-right text-muted text-sm'>12 hours</span>-->
                </a>
                     ";
              }
              if($Cnumofrows>0)
              {
                echo "
                <div class='dropdown-divider'></div>
                <a href='comments.php' class='dropdown-item' style='color:black;'>
                  <i class='fas fa-comments'></i> $Cnumofrows new comments
                  <!-- <span class='float-right text-muted text-sm'>2 days</span> -->
                </a>
                     ";
              }
              if($REnumofrows>0)
              {
                echo "
                <div class='dropdown-divider'></div>
                <a href='reportupdates.php' class='dropdown-item' style='color:black;'>
                  <i class='fas fa-comments'></i> $REnumofrows New Report updates
                  <!-- <span class='float-right text-muted text-sm'>2 days</span> -->
                </a>
                     ";
              }
          if($numofrows>0)
          {
          echo "
              <div class='dropdown-divider'></div>
              <a href='allnotifications.php' class='dropdown-item dropdown-footer' style='color:black;'>See All Notifications</a>
               ";  
          }
          echo "
          </div>
        </li>
               ";
      }
      ?>