<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php'; 

    if(!isset($_SESSION['semail']))
    {
        header('location: index.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name='viewport' content='with=device-width, initial-scale=1.0'>
    <title>Mu World Website</title>
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/dash.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    <!-- leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css">

    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
</head>
<body>
    <!--Navigation Bar -->
        <section class='dash-header'>
            <?php include_once 'topnavbar.php'; ?>      
        </section>
            
<!--Dashboard Section-->
<?php
  if(isset($_SESSION['semail']))
  {
    $user = uidExists($con,$_SESSION['semail']);
    $userP = profileExistsID($con,$_SESSION['suserid']);
  }
?>
<div class='wrapper'>
      <main class='main'>
        <header class='dash2-header'>
          <div class='header__wrapper'>
              <!--Search & Small round usr profile Section -->
            <form action='' class='search'>
              <button class='search__button focus--box-shadow' type='submit'>
                <svg class='search__icon' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'>
                  <path d='M21.71,20.29,18,16.61A9,9,0,1,0,16.61,18l3.68,3.68a1,1,0,0,0,1.42,0A1,1,0,0,0,21.71,20.29ZM11,18a7,7,0,1,1,7-7A7,7,0,0,1,11,18Z'/>
                </svg>
              </button>
              <input
                class='search__input focus--box-shadow' type='text' placeholder='Search'/>
            </form>
            <div class='profile'>
              <button class='profile__button'>
              <a href='profile.php'><span class='profile__name'><?php echo $user['Name'];?></span></a>
                <img class='profile__img' src='img/<?php echo $userP['ProfilePicture'];?>' onerror=this.src='img/beard.png'>
              </button>
            </div>
          </div>
       

       </header>
        <!--Live Feed Section-->
        <section class='section'>
          <header class='section__header'>
            <h2 class='section__title'>Dashboard</h2>
          </header>
          <ul class='team'>
          <li class='team__item'>
              <a class='team__link focus--box-shadow' href='friends.php'>
                <div class='team__inform'>
                <p class='team__name'>Friends</p>
                <time class='date' datetime='2021-04-05T10:00:00'> My friends list </time>
                <br>
                <br>
                <br>
                </div>
              </a>
            </li>
            <li class='team__item'>
              <a class='team__link focus--box-shadow' href='research.php'>
                <div class='team__inform'>
                  <p class='team__name'>Personal Researches</p>
                  <time class='date' datetime='2021-04-05T10:00:00'>My Research list</time>
                </div>
              </a>
            </li>
            <!--My Calendar Section -->
            <li class='team__item'>
              <a class='team__link focus--box-shadow' href='#'>
                <div class='team__inform'>
                  <p class='team__name'>Calendar</p>
                  <time class='date' datetime='2021-04-05T10:00:00'>My Personal Calendar</time>
                </div>
              </a>
            </li>
          </ul>
        </section>
        <!--Research List Section -->
        <section class='section'>
          <header class='section__header'>
            <h2 class='section__title'>Latest Researches</h2>
            <div class='section__control'>
              <button class='section__button focus--box-shadow' type='button' aria-label='Filter projects' >
                <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' role='presentation'>
                  <path d='M20,8.18V3a1,1,0,0,0-2,0V8.18a3,3,0,0,0,0,5.64V21a1,1,0,0,0,2,0V13.82a3,3,0,0,0,0-5.64ZM19,12a1,1,0,1,1,1-1A1,1,0,0,1,19,12Zm-6,2.18V3a1,1,0,0,0-2,0V14.18a3,3,0,0,0,0,5.64V21a1,1,0,0,0,2,0V19.82a3,3,0,0,0,0-5.64ZM12,18a1,1,0,1,1,1-1A1,1,0,0,1,12,18ZM6,6.18V3A1,1,0,0,0,4,3V6.18a3,3,0,0,0,0,5.64V21a1,1,0,0,0,2,0V11.82A3,3,0,0,0,6,6.18ZM5,10A1,1,0,1,1,6,9,1,1,0,0,1,5,10Z'/>
                </svg>
              </button>
              <a href='createresearch.php'>
              <button class='section__button section__button--painted focus--box-shadow' type='button' aria-label='Add New project'>
                <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' role='presentation'>
                  <path d='M19,11H13V5a1,1,0,0,0-2,0v6H5a1,1,0,0,0,0,2h6v6a1,1,0,0,0,2,0V13h6a1,1,0,0,0,0-2Z'/>
                </svg>
              </button>
              </a>
            </div>
          </header>
          
          <?php
          $sql = "SELECT * FROM research ORDER BY rcdate DESC;";
          $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
          
          //Condition to prepare the stmt variable if successful carrys on if not show fail message.
          if(!mysqli_stmt_prepare($stmt,$sql))
          {
              header("location: enhancedsearch-results.php?error=stmtfailed");
              exit();
          }

          mysqli_stmt_execute($stmt);
          
          $result = mysqli_stmt_get_result($stmt);

          if($numrows = mysqli_num_rows($result) >0)
          {
                echo "<ul class='project'>";
                while($row = mysqli_fetch_assoc($result))
                {
                $uExists = userIDExists($con,$row['rcreator']);
                $uProfile = profileExistsID($con,$row['rcreator']);
                    echo" 
                        <!--Article List1 -->
                        <li class='project__item'>
                        <a href='detailedresearch.php?ID=$row[rid]' class='project__link focus--box-shadow'>
                            <div class='project__wrapper'>
                            <div class='project__element project__icon'>
                                <div class='icon icon--viking'>
                                <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' role='presentation'>
                                <path d='M15,6H9A1,1,0,0,0,8,7v4a1,1,0,0,0,1,1h6a1,1,0,0,0,1-1V7A1,1,0,0,0,15,6Zm-1,4H10V8h4Zm3-8H5A1,1,0,0,0,4,3V21a1,1,0,0,0,1,1H17a3,3,0,0,0,3-3V5A3,3,0,0,0,17,2Zm1,17a1,1,0,0,1-1,1H6V4H17a1,1,0,0,1,1,1Z'/>
                                </svg>
                                </div>
                            </div>
                            <div class='project__element project__inform'>
                                <span class='project__inform-name'>$row[rtitle]</span>
                            </div>
                            <div class='project__element project__photo'>
                                <ul class='photo'>
                                <li class='photo__item'>
                                    <img src='img/$uProfile[ProfilePicture]' onerror=this.src='img/beard.png'>
                                </li>
                                </ul>
                            </div>
                            <div class='project__element project__date'>$uExists[Name]</div>
                            <div class='project__element project__status'>
                                <span class='status status--published'>INSERT ORGANISATION</span>
                            </div>
                            <div class='project__element project__setting'>
                            </div>
                            </div>
                        </a>
                        </li>
                        ";
                }
            }
           
                echo "</ul>
    

      </main>
                ";
      ?>
      <!-- Right side section -->
      
</div>

    <!--Map Section-->
    <section class="mapmain">
    <h1 style='text-align: center;'>Your organisation might be linked with us!</h1>
    <p style='text-align: center;'>Murdoch University has many partners around the world both domestic and international.</p>

    <div class="map-wrapper">
    <div id="map" style="height: 405px; overflow: hidden"></div>
        <select class="layer-picker">
        <option onclick=testFunction0()>All Partners</option>
        <option onclick=testFunction()>Kaplan Singapore</option>
        <option onclick=testFunction1()>Perron Institute</option>
        <option onclick=testFunction2()>Sarepta Therapeutics</option>
        <option onclick=testFunction3()>Harry Perkins Institute of Medical Research</option>
        <option onclick=testFunction4()>Chevron – The Harry Butler Institute</option>
        <option onclick=testFunction5()>Peel-Harvey Catchment Council</option>
        <option onclick=testFunction6()>Bunbury Dolphin Discovery Centre</option>
        <option onclick=testFunction7()>Commonwealth Department of Infrastructure</option>
        <option onclick=testFunction8()>Regional Development</option>
        <option onclick=testFunction9()>Phosphates Resources Limited</option>
        <option onclick=testFunction10()>Western Barley Genetics Alliance</option>
        <option onclick=testFunction11()>Peel Development Commission</option>
        <option onclick=testFunction12()>The University of Western Australia</option>d
        <option onclick=testFunction13()>Curtin university</option>
        <option onclick=testFunction14()>Edith Cowan University</option>
        <option onclick=testFunction15()>Pawsey Supercomputing Centre</option>
        </select>
    </div>
    </section>

    


    <section class="footer">
    
    <h4>MuWorld</h4>
<p>A multi-media connection system. <br>A platform to provide FOLLOW UPS for user to stay in touch
    with each other.</p>
    <div class="icons">      
        <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
        <a href="https://www.twitter.com/"><i class="fa fa-twitter"></i></a>
        <a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
        <a href="https://sg.linkedin.com/"><i class="fa fa-linkedin"></i></a>
    </div>
    <p>Made with <i class="fa fa-heart"></i> by Local Sense</p>
</section>
        </div>
    <script>
        var navLinks = document.getElementById('navLinks');

        function showMenu(){
            navLinks.style.right = '0';
        }
        function hideMenu(){
            navLinks.style.right = '-200px';
        }
    </script>

<!-- leaflet -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="javascript/partnermap.js"></script>
</body>
</html>