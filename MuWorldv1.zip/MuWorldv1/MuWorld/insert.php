<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
    if(isset($_SESSION['semail']))
    {
      $usr_id =$_SESSION['suserid'];
    
    } 

$connect = new PDO('mysql:host=localhost;dbname=test','root','');

if(isset($_POST["title"]))
{
    $query = 
    "INSERT INTO events (title,start_event,end_event,user_id,event_color,weblink) VALUES (:title,:start_event,:end_event,$usr_id,:event_color,:weblink)";
    $statement = $connect->prepare($query);
    $statement->execute(
        array(
            ':title'        => $_POST['title'],
            ':start_event'  => $_POST['start'],
            ':end_event'    => $_POST['end'],
            ':event_color'  =>$_POST['color'],
            ':weblink'      =>$_POST['link']
            
            

            )
        );
}

?>