<?php 
   session_start();
   include_once 'header.php';
   include_once 'includephp/dbh.inc.php';
   include_once 'includephp/functions.inc.php';
if(isset($_SESSION['semail']))
{
  $usr_id =$_SESSION['suserid'];

} 
$connect = mysqli_connect("localhost","root","","test");

if(isset($_POST['submit']))
{
                        $name           =$_POST['username'];
                        $email          =$_POST['email'];
                        $location       =$_POST['visit-location'];
                        $associateEmail =$_POST['visit-associateEmail'];
                        $duration       =$_POST['visit-duration'];
                        $purpose        =$_POST['visit-purpose'];
       
    $query =mysqli_query($connect,"INSERT INTO `uservisit`(`visit_name`,`visit_email`,`visit_location`,`visit_associationEmail`,`visit_duration`,`visit_purpose`,`visit_uid`) VALUES ('$name','$email','$location','$associateEmail','$duration','$purpose','$usr_id')");

    if($query)
    {
        echo "<div style='text-align:center;color:green;'><h1> &check;Sucessfully Registered</h1></div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make a visit</title>
<style>
    .container input{
        width:15rem;
    }
    </style>
     <link rel="stylesheet" href="CSS/calendar.css">
     <link rel="stylesheet" href="CSSS/reg.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
</head>
<body style="background-image:url('../img/plan.jpg');background-repeat:no-repeat;">
    <br>
    <div class="makeVisit-header" style="text-align:center;">
     <h1>Plan A Visit</h1>
    </div>
 
<form method="POST">
    <div class="makeVisit-body" style="text-align:center;">
    
    <div class="container" style="margin-top:2rem;margin-bottom:5rem; text-align: center;">

        <div class="form-group">
            <label for="visit-username" style="margin-bottom:1rem; margin-right: 10px;">Name:</label>
            <br>
          <input type="text" name="username" value="" required> 
        </div>

        <div class="form-group"  >
            <label for="visit-email" style=" margin-right: 10px;margin-top:1rem;">Email:</label>
            <br>    
            <input type="email" name="email" value="" required>
        </div>
        <br>
        <div class="form-group" >
            <p for="visit-location" style="margin-bottom:0rem;">Visit Location:</p>
            <input type="text" name="visit-location" value="" required>
        </div>
        <br>

        <div class="form-group"  >
            <p for="visit-associateEmail">Associate Email</p>
            <input type="email" name="visit-associateEmail" value="" required>
        </div> 
        <br>

        <div class="form-group"  >
            <label for="visit-duration">Duration</label><br>
            <input type="text" name="visit-duration" value="" required>
        </div>
        <br>
        <div class="form-group"  >
            <label for="visit-purpose">Purpose of Visit</label><br>
            <input type="text" name="visit-purpose" value="" required>
            <br>
            <br>
            <input type="submit" class="btn btn-success" name="submit" value="Confirm" style='background: crimson; width: 100px;'>
        
        <button id="cancel-btn-event" class="btn btn-secondary"><a href='calendar.php' style='color:white;'>Cancel</a></button>        
        </div>
    

    </div>   

    <br>
    <br>
    <!--
    <div class="visit-Button" style="text-align:center;">
        <button id="confirm-btn-event" class="btn btn-success" name="submit">Confirm</button>
        <button id="cancel-btn-event" class="btn btn-secondary"><a href='calendar.php' style='color:white;'>Cancel</a></button>
    </div>
 </div> -->

</form> 

    <div class="makeVisit-footer">
</div>
</body>
</html>