<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie-edge">
    <title>Mu World Website</title>
    <link rel="stylesheet" href="CSS/reg.css">
    <link rel="stylesheet" href="CSS/joshua.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <!-- Ajax scripts to have a non-refreshing page. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function()
        {
            $("form").submit(function(event)
            {
                event.preventDefault();
                var name = $("#reg-name").val();
                var email = $("#reg-email").val();
                var pass = $("#reg-pass").val();
                var repass = $("#reg-repass").val();
                var pic = $("#upload-profile").val();
                var rsubmit = $("#reg-submit").val();

                var aterms = false;

                if(document.getElementById("reg-aterms").checked)
                {
                    aterms = true;
                }

                $(".reg-message").load("includephp/register.inc.php",
                {
                    name: name,
                    email: email,
                    pass: pass,
                    repass: repass,
                    aterms: aterms,
                    pic : pic,
                    submit: rsubmit
                });
            });
        });
    </script>

</head>
<body>

<main id="main-area"> 

    <!-- registration area -->
    <section id="register">
        <div class="row m-0">
            <div class="col-lg-4 offset-lg-2">
                <div class="text-center pb-5">
                    <h1 class="login-title text-dark">Register</h1>
                    <p class="p-1 m-0 font-ubuntu text-black-50">Register and enjoy additional features</p>
                    <span class="font-ubuntu text-black-50">I already have an<a href="login.php"> account</a></span><br>
                </div>
                <div>

                <div class="upload-profile-image d-flex justify-content-center pb-5">
                    <div class="text-center">
                        <div class="d-flex justify-content-center">
                        </div>
                        <img src="./img/beard.png" style="width: 200px; height: 200px" class="img rounded-circle" alt="profile">   
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <form action="includephp/register.inc.php" method="post" enctype="multipart/form-data" id="reg-form">
                        <div class="form-row">
                            <div class="col">
                                <input type="text" name="name" id="reg-name" class="form-control" placeholder="Enter your name*">
                            </div>
                        </div>

                        <div class="form-row my-4">
                            <div class="col">
                                <input type="email" name="email" id="reg-email" class="form-control" placeholder="Email*">
                            </div>
                        </div>

                        <div class="form-row my-4">
                            <div class="col">
                                <input type="password" name="pass" id="reg-pass" class="form-control" placeholder="password*">
                            </div>
                        </div>

                        <div class="form-row my-4">
                            <div class="col">
                                <input type="password" name="repass" id="reg-repass" class="form-control" placeholder="Confirm Password*">
                                <small id="confirm_error" class="text-danger"></small>
                            </div>
                        </div>

                        <div class="form-check form-check-inline">
                            <input type="checkbox" id="reg-aterms" name="aterms" class="form-check-input">
                            <label for="agreement" class="form-check-label font-ubuntu text-black-50">I agree <a href="#">term, conditions, and policy </a>(*) </label><br>
                            <span class="font-ubuntu text-black-50">Not feeling it? you can always go <a href="index.php"> back</a></span>
                        </div>
                        <p class="reg-message"></p>
                        <div class="submit-btn text-center my-5">
                            <button type="submit" id="reg-submit" name="register" class="btn btn-warning rounded-pill text-dark px-5">Continue</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </section>

<!--FOOTER SECTION-->
<section class="footer">
    <h4>MuWorld</h4>
<p>A multi-media connection system. <br>A platform to provide FOLLOW UPS for user to stay in touch
    with each other. <br><a href="faq.php">FAQ</a></p>
    <p>Made with <i class="fa fa-heart"></i> by Local Sense</p>
</section>



</main>

</body>
</html>