<?php 
  session_start();
  include_once 'includephp/dbh.inc.php';
  include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html lang="en" class="faq-html">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie-edge">
    <title>Mu World Website</title>
    <link rel="stylesheet" href="CSS/joshua.css">
    <link rel="stylesheet" href="CSS/faq.css">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- fontAwesome CSS -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- bootsctrap scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body>
        <!--Navigation Bar -->   
        <section class="faq-header">
    <?php include_once 'topnavbar.php' ?>    
    </section>
  
    <section class="sec-faq">
      <div class="container-faq">
        <div class="accordion">
          <div class="accordion-item" id="question1">
            <a class="accordion-link" href="#question1" style="outline: none;">
              How do you get notified?
            </a>
            <div class="answer">
                <p>
              Check the notification in your Dashboard page in the Navbar section. If the number increments means that you've been notified 
              and thats the number of notifications you have.
                </p>
            </div>
          </div>
          <div class="accordion-item" id="question2">
            <a class="accordion-link" href="#question2">
              How to create a research?

            </a>
            <div class="answer">
            <p>
              Click the "+" button on the Dashboard fill in the fields then submits it will be posted in the Dashboard that other users can view and join.
            </p>
            </div>
          </div>
          <div class="accordion-item" id="question3">
            <a class="accordion-link" href="#question3">
              What type of research I can post?
            </a>
            <div class="answer">
            <p>
              Any type of research will do as long as it is a legitimate research.
            </p>
            </div>
          </div>
          <div class="accordion-item" id="question4">
            <a class="accordion-link" href="#question4">
              How to join or leave a research?
            </a>
            <div class="answer">
            <p>
              Click on any of the researches posted on the latest research section or search a research based on organisation on the search field. 
              Upon clicking you will see the full article and you should be able to see the "Join" button click that and you will see your avatar join the 
              current member section which then notifies the Author who can then contact you or you contact them. To leave a research simply click on the "Leave Research" button
              and you will see your avatar leave the current member section.
        </p>
            </div>
          </div>
          <div class="accordion-item" id="question5">
            <a class="accordion-link" href="#question5">
              How do I add friends?
            </a>
            <div class="answer">
                <p>
              You search a friend in a search bar then click on their profile, you will see the "Add friend" button. Similarly if you are in a research you can click on their name and you 
              will be redirected ot their profile page where then you can click the "Add friend" button. Upon addding friend a notification will be sent so that you can accept the friend request.
            </p>
            </div>
          </div>
          <div class="accordion-item" id="question6">
            <a class="accordion-link" href="#question6">
              How do I join for an event?
            </a>
            <div class="answer">
            <p>
              To join for an event simply click on the event display on the calendar date, then click on the RSVP button. Fill in the form and you will be notified via email once the event date is near.
            </p>
            </div>
          </div>
          <div class="accordion-item" id="question7">
            <a class="accordion-link" href="#question7">
              Why do I need to plan a schedule when visiting an organisation or a person?
            </a>
            <div class="answer">
                <p>
              Due to covid protocols it is important that the goverment know where yuo've been so if ever there is a case it can be countered easily. Do click on the "Make Visit" button whenever
              you are planning a visit on an organisation.
            </p>
            </div>
          </div>
          <div class="accordion-item" id="question8">
            <a class="accordion-link" href="#question8">
              How do I add Events in "My Calendar"?
            </a>
            <div class="answer">
                <p>
              Click on the Calendar button on the Dashboard, in order to create an event simply lcick on the dates and fill in the fields that popup. Go to day and drag the event the ideal time.
              To delete an event right click on the event in the calendar date.
            </p>
            </div>
          </div>
          <div class="accordion-item" id="question9">
            <a class="accordion-link" href="#question9">
              How do I access and edit my Profile?
            </a>
            <div class="answer">
                <p>
             Click on your name in the navigation bar and you will be redirected to your Profile page. To edit the profile page simply click on icon on top of your profile picture. 
             Full in the fields and click the "Submit" button.              
                </p>
            </div>
          </div>
          <div class="accordion-item" id="question10">
            <a class="accordion-link" href="#question10">
              What type of stuff can I search on the searchbar
            </a>
            <div class="answer">
                <p>
             You can search for users by simply filling their names, can search organiation by typing their name and upon doing so it would display users associated with that organisation as well as researches hosted
             by that organisation.               
</p>
            </div>
          </div>
        </div>
      </div>
    </section>


</body>
</html>