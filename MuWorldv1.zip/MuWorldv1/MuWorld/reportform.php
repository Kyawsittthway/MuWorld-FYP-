<?php 
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
    <!-- CSS FILES -->
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 
    <link rel='stylesheet' href='CSS/test.css'> 
    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <!-- Javascripts -->

    <!-- ajax script for dynamic webpage -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <!-- Select2 script for form multiple options -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- custom-file-input script for file name to show up -->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
</head>
<body>
    <!--Research Section-->
    <section>
    <div class='container'>
    <h1>Report on Event</h1>
    <a href='dashboard2.php'><button class='btn btn-primary fas fa-step-backward'></button></a>
        <div class='card-body'>
                <form action="includephp/reportform.inc.php" method="POST" enctype="multipart/form-data">
                      <div class="card-body">
                          <!-- Input section 1 -->
                          <div class="form-group">
                            <label>Event Title</label>
                            <select class="js-example-responsive" name="eid" style="width: 100%;">
                                <option selected disabled hidden>Select an event</option>
                                <?php
                                    //SQL statement for database, might be subjected to change!!**
                                    $sql = "SELECT * FROM `admin_event`;";
                                    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                    
                                    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                    if(!mysqli_stmt_prepare($stmt,$sql))
                                    {
                                        header("location: ../editprofile.php?error=stmtfailed");
                                        exit();
                                    }

                                    mysqli_stmt_execute($stmt);

                                    $resultData = mysqli_stmt_get_result($stmt);

                                    //Condition to check if data exists in the database matches with input.
                                    if($numofrow = mysqli_num_rows($resultData)>0)
                                    {
                                        while($row = mysqli_fetch_assoc($resultData))
                                        {
                                        echo "<option value ='$row[id]'>$row[title]</option>";
                                        }
                                    }
                                    else
                                    {
                                        echo "<option>No options currently</option>";
                                    }
                                    mysqli_stmt_close($stmt);
                                    ?>
                            </select>
                          </div>
                          <!--Input section 2-->
                          <div class="form-group">
                              <label>Host of the Event</label>
                              <input type="text" class="form-control" name="hevent" placeholder="">
                          </div>
                            <!--Input section 3-->
                          <div class="form-group">
                            <label>Description of the Event</label>
                            <br>
                            <textarea class='form-control' name ='devent' rows='4' cols='50'></textarea>
                          </div>
                           <!--Input section 4-->
                           <div class="form-group">
                            <label>Contacts that you have made during the Event</label>
                            <br>
                            <textarea class='form-control' name ='cevent' rows='4' cols='50'></textarea>
                          </div>
                          <?php
                            if(isset($_GET["error"]))
                            {
                              if($_GET["error"] == "noinput")
                              {
                                  echo "<p style='color:red'> No inputs were made.</p>";
                              }
                              else if($_GET["error"] == "re")
                              {
                                  echo "<p style='color:red'> Event report already exists.</p>"; 
                              }
                              else if($_GET["error"] == "none")
                              {
                                echo "<p style='color:green'> Successfully created an event report.</p>";
                              }
                            }
                          ?>
                      </div>
                      <!-- /.card-body -->

                      <!-- Input section hidden -->
                      <input type='hidden' name='UID' value="<?php echo $_SESSION['suserid'];?>"/>
                      
                      <!-- card-footer -->
                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary" name="rfSubmit">Submit</button>
                      </div>
                </form>
                </div>
    </div>
    </section>

    <!-- IMPORTANT!! WITHOUT THIS SCRIPT YOU WILL NOT BE ABLE TO SELECT MULTIPLE OPTIONS FOR SKILLS -->
    <script>
    $(".js-example-responsive").select2(
    {
         width: 'resolve' // need to override the changed default
    });
    </script>

    <!-- Script to show text of file. -->
    <script>
    $(function () {
    bsCustomFileInput.init();
    });
    </script>


</body>
</html>