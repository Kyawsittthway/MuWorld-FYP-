<?php 
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';  
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="with=device-width, initial-scale=1.0">
    <title>Mu World Website</title>
    <link rel="stylesheet" href="CSS/joshua.css">
    <link rel="stylesheet" href="CSS/contact.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- fontAwesome CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- bootsctrap scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script>
        $(document).ready(function(){
            $("form").submit(function(event){
                event.preventDefault();
                var name = $("#mail-name").val();
                var email = $("#mail-email").val();
                var subject = $("#mail-subject").val();
                var message = $("#mail-message").val();
                var submit = $("#mail-submit").val();

                $(".form-message").load("includephp/about.inc.php", {
                    name: name,
                    email: email,
                    subject: subject,
                    message: message,
                    submit: submit
                });
            });
        });
    </script> 
    
</head>
<body>
    <!--Navigation Bar -->
    <section class="sub-header">
    <?php include_once 'topnavbar.php' ?>    
    </section>

<!--Content-->
<section class="abt-us">
<h1 style="text-align:center; color:red; after:">ABOUT US</h1>
    <div class="row">
        <div class="abt-col">
            <h1>We are the first integrated social feature in a Univeristy's Website</h1>
            <p>This system is aimed at allowing staff and researchers to see and engage in communities of practice 
                (research, research and industry), Share spheres of influence (connecting people to people) and showing 
                everyone where Murdoch has an impact both globally and domestically. The system should also show 
                articulations and other partnerships with overseas universities</p>
                <a href="register.php" class="hero-btn red-btn">REGISTER NOW</a>
        </div>
        <div class="abt-col">
            <img src ="img/about.jpg">
        </div>
    </div>
</section>

<!--Blog-->
<section class="blog">
    <div class="row">
        <div class="blog-left">
            <img src="img/mdc.jpg">
            <h2>IMPORTANCE OF CONNECTING WITH PEOPLE</h2>
            <p>You may be a CEO who says, “I don’t have time to go to events and network.” Other CEOs may say, “What’s the real value to me to make time and effort to do so?” 
                Before we answer these questions, let’s first establish that there is a big difference between making connections versus networking. The definition of networking
                 is interacting with other people to exchange information and develop contacts, especially to further one's career. Networking is an activity. It is an activity that
                  can be acted upon with great or little success.</p>
            <br>
            <p>The definition of a connection, however, is a relationship in which a person, thing or idea is linked or associated with something else. A connection is a relationship
                 that occurs as a result of successful networking, and its primary goal. Connections look out for each other and make appropriate introductions to each other because 
                 they believe in each other and like to help one another. They also give you advantages you might otherwise not have access to. Imagine being connected with the owner 
                 Of the top new restaurant in town with a several month wait list, and you want to celebrate your spouse’s birthday there the following week? Calling the owner and getting
                  a table is an example of a connection paying dividends.</p>

        </div>
        <div class="blog-right">
            <h3>Partners in Different Category</h3>
            <div>
                <span>Business Industry</span>
                <span>2</span>
            </div>
            <div>
                <span>Research Industry</span>
                <span>12</span>
            </div>
            <div>
                <span>Education Industry</span>
                <span>8</span>
            </div>
            <div>
                <span>Hospital Industry</span>
                <span>3</span>
            </div>
            <div>
                <span>Videography Industry</span>
                <span>2</span>
            </div>
            <div>
                <span>Sports Industry</span>
                <span>1</span>
            </div>
            <div>
                <span>Community</span>
                <span>2</span>
            </div>
        </div>
    </div>
</section>

<!--TEAM-->
<section class="team">
<div class="container">
<h1 style="text-aligncenter;">MEET THE BRAINS BEHIND MUWORLD</h1>
    <div class="profiles">
      <div class="profile">
        <img src="img/user2.png" class="profile-img">
        <h3 class="user-name">Joshua</h3>
        <h5>Project Manager</h5>
        <p>When life gives you lemon you make them and sell them.</p>
      </div>
      <div class="profile">
        <img src="img/user1.png" class="profile-img">
        <h3 class="user-name">Yong Kang</h3>
        <h5>Lead Developer</h5>
        <p>I tell you my biggest secret, I hate coding.</p>
      </div>
      <div class="profile">
        <img src="img/doris1.jpeg" class="profile-img">
        <h3 class="user-name">Doris</h3>
        <h5>Secretary</h5>
        <p>The beautiful thing about learning is that no one can take it away from you.</p>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="profiles">
      <div class="profile">
        <img src="img/vicky.jpeg" class="profile-img">
        <h3 class="user-name">Vicky</h3>
        <h5>Developer</h5>
        <p>Measuring programming progress by lines of code is like measuring aircraft building progress by weight.</p>
      </div>
      <div class="profile">
        <img src="img/charles.jpeg" class="profile-img">
        <h3 class="user-name">Charles</h3>
        <h5>Developer</h5>
        <p>One man’s crappy software is another man’s full-time job.</p>
      </div>
      <div class="profile">
        <img src="img/sahi2.jpeg" class="profile-img">
        <h3 class="user-name">Sahana</h3>
        <h5>Documentor</h5>
        <p>The mind is not a vessel to be filled but a fire to be ignited.</p>
      </div>
    </div>
  </div>
</section> 

<!--CONTACT-->
<section class="contact section" id="contact">
                <h2 class="section-title">Leave a review or Contact us</h2>
                <div class="contact__container bd-grid">
                <form action="includephp/about.inc.php" class="contact__form" method="post" name="myForm">
                         
                         <span id="name" class="error" style="color:red;"></span> 
                         <input id="mail-name" name="name" type="text" value=""  placeholder="Name" class="contact__input" oninput="checkName()">  
 
                         <span id="email" class="error" style="color:red;"></span>
                         <input id="mail-email" name="email" type="text" value="" placeholder="Email" class="contact__input" oninput="checkMail()">
                          
                         <span id="sbj" class="error" style="color:red;"></span>
                         <input id="mail-subject" name="subject" type="text" placeholder="Subject" class="contact__input" oninput="checkSub()">
                         
                         <span id="msg" class="error" style="color:red;"></span> 
                         <textarea id="mail-message" name="message" cols="0" rows="10" class="contact__input" placeholder="Leave a message here..." oninput="checkMsg()"></textarea>
 
                         <span class=form-message></span>
                         <button id="mail-submit" name="submit" type = "submit" class="contact__button button">Submit</button>
                         <p>Upon sending a message do wait for the "Message Sent!" notification to appear!</p>

                         
                     </form>
                </div>
            </section>

<!--FOOTER SECTION-->
<section class="footer">
    <h4>MuWorld</h4>
<p>A multi-media connection system. <br>A platform to provide FOLLOW UPS for user to stay in touch
    with each other. <br><a href="faq.php">FAQ</a></p>
    <p>Made with <i class="fa fa-heart"></i> by Local Sense</p>
</section>

<script>
        var navLinks = document.getElementById("navLinks");

        function showMenu(){
            navLinks.style.right = "0";
        }
        function hideMenu(){
            navLinks.style.right = "-200px";
        }
</script>
<script> 
    
    var Uname = document.myForm.name;      
    var Uemail = document.myForm.email;
    var Usub = document.myForm.subject;
    var Umsg = document.myForm.message;

    var  erName= document.getElementById('name');
    var erMail = document.getElementById('email');
    var erSub = document.getElementById('sbj');
    var erMsg = document.getElementById('msg');
  
    
    function checkName()
    {
        if(Uname.value == "" || Uname.value.length < 2)
            {
               erName.innerHTML="Real name is required"; 
               erName.style.color ="red";
                
            }
        else if(!isNaN(Uname.value))
            {
               erName.innerHTML="Real name is required"; 
               erName.style.color ="red"; 
            }
 

        else if(Uname.value.length > 2)
        {
            erName.innerHTML ="";
            
        }
  
    }
                   
    function checkMail()
    {
        if(Uemail.value == "" || Uemail.value.length < 3)
            {
                erMail.innerHTML = "Valid Email is required";
                erMail.style.color = "red";
            }
        else if(Uemail.value.indexOf('@') <= 0)
            {
               erMail.innerHTML = "Valid Email is required";
                erMail.style.color = "red"; 
            }
        else if((Uemail.value.charAt(Uemail.value.length-4)!='.') && (Uemail.value.charAt(Uemail.value.length-3)!='.'))
            {
                erMail.innerHTML = "Valid Email is required";
                erMail.style.color = "red"; 
            }
            else if(Uemail.value.length > 3)
        {
            erMail.innerHTML = "";
        }
        
        
    }

    function checkSub()
    {
        if(Usub.value == "" || Usub.value.length < 5)
            {
               erSub.innerHTML="Subject must be at least 5 words long"; 
               erSub.style.color ="red";
                
            }      

        else if(Usub.value.length > 10)
        {
          erSub.innerHTML ="";
            
        }       
    }

    function checkMsg()
    {
        if(Umsg.value == "" || Umsg.value.length < 10)
            {
              erMsg.innerHTML="Your feedback matters!"; 
              erMsg.style.color ="red";
                
            }      

        else
        {
          erMsg.innerHTML ="";
            
        }       
    }
</script>
<!--Javascript for Toggle Menu-->
   <script src="javascript/idx.js"></script>

</body>
</html>