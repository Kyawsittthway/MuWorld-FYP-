<?php
       session_start();
       include_once 'header.php';
       include_once 'includephp/dbh.inc.php';
       include_once 'includephp/functions.inc.php';
    if(isset($_SESSION['semail']))
    {
      $usr_id =$_SESSION['suserid'];
    
    } 
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mu World | Calendar</title>

  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
  <!--<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">-->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- fullCalendar -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="CSS/calendar.css">
 
  


  
<!-- jQuery -->
<script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- jQuery UI -->
<script src="../plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
<!-- fullCalendar 2.2.5 -->
<script src="../plugins/moment/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>




</head>


<body>
  <div class="event-navi" style="background-color: crimson; height:20px">
  <ul style=" list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: crimson;">
  <?php
   if(isset($_SESSION['semail'])){
        echo "<li><a href='index.php'> Go to Home</a></li>";
        echo "<li><a href='event_register.php'> Register Event</a></li>";
        echo "<li><a href='makeVisit.php'> Make Visit</a></li>";
   }else
   {

   echo  "<li><a href='index.php' style='font-size:26px;font-weight:bold;width:4rem;'> &#60;</a></li>";
   }
  ?>

  </ul>
  </div>
<div class="wrapper">

<div class="event-heading-text" style="text-align: center;">  
<h1 style="text-align: center;margin-top:3rem;">Event Calendar</h1>
<hr style="width:15rem;height:0.2rem;margin-left:auto;margin-right:auto;color:crimson;opacity:100%">
  </div>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<!-- Modal for admin created events-->
 <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" >
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="font-weight:bold;">Event Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <p1  id ='publicEvent' style="font-weight:bold;"></p1>
     <br>
     <p1  id ='eventTitle' style="font-weight:bold;"></p1>
     <br>
     <p1  id ='eventLink' style="font-weight:bold;"></p1>
     <br>
     <p1  id ='CreateAdmin' style="font-weight:bold;"></p1>
     <br>
  
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <?php 
           if(isset($_SESSION['semail']))
           {
             echo    "<a href='event_register.php'><button type='button' class='btn btn-secondary'>RSVP</button></a> ";
           }else
           {
            echo    "<a href='register.php'><button type='button' class='btn btn-secondary'>RSVP</button></a> ";
           }
        ?>
     
      
      </div>
    </div>
  </div>
</div>
<!-- Modal for client created events-->
<div class="modal fade" id="clientModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" >
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" style="font-weight:bold;">Event Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

     <p1  id ='clientTitle' style="font-weight:bold;"></p1>
     <br>
     <p1  id ='clientLink' style="font-weight:bold;"></p1>
     
 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       
      
      </div>
    </div>
  </div>
</div>




          
    
                  <h5 style="display:block;text-align:center;margin-top:2rem;margin-bottom:2rem;">Upcoming Events</h5>            
            <div class="row">
               <?php  
                $currentDateTime=date('Y-m-d H:i:s');
               
                $connect=mysqli_connect("localhost","root","","test");
                
                $query = "SELECT * FROM admin_event"; 
                $result = mysqli_query($connect, $query);  

                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                       if($row["admin_start"]>$currentDateTime)
                      {
              
                echo "<div class='card' style=' box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);width:50px;height:250px;margin-left: 5rem;text-align: center;margin-bottom:4rem;'>
                      <span class='liner' style='background-color:crimson;'>. </span>
                    <h5 class='title' style='margin:auto;'>";echo $row["title"];echo"</h5>";

                    echo "<p class='start' style=' color: black;font-size: 18px;font-weight:bold; '>Start:";echo$row["admin_start"];echo"</p>";
                    echo "<p class='end' style=' color: black;font-size: 18px;font-weight:bold;'>End:";echo$row["admin_end"];echo"</p></div>";
   
        
                  
                     }
                    }  
                }  
                ?> 
              
            </div>




                <!-- THE CALENDAR -->
                <div class='col-md-8' style="margin-left:auto;margin-right:auto;" oncontextmenu="return false;">
                <div id="calendar"></div>
                </div>
                </div>
                </div>
   
 
      </div>


  </div>
              </body>

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <p1><b>Created by Local Sense&#169;2021 </b> </p1>
    </div>
  
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<script>
document.addEventListener('contextmenu', event => event.preventDefault());
 $(document).ready(function()
 {
  
   var calendar = $('#calendar').fullCalendar({
       editable:false,
       header:{
         left:'prev,next today',
         center:'title',
         right:'month,agendaWeek,agendaDay'
       }, 
       events: '/events_db/adminLoad.php',
       selectable: false,
       selectHelper: false,
       allDay:true,
       eventLimit:false,
       editable:false,
           
            eventDrop:function(event)
            {
              var start = $.fullCalendar.formatDate(event.start,"Y-MM-DD HH:mm:ss");
              var end = $.fullCalendar.formatDate(event.end,"Y-MM-DD HH:mm:ss");
              var title = event.title;
              var id = event.id;
              $.ajax({
                url:"/events_db/adminLoad.php",
                type:"POST",
                data:{title:title,start:start,end:end,id:id},
                success:function()
                {
                  calendar.fullCalendar('refetchEvents');
                  // alert("Event Update!");
                }
              })
            },
            eventClick:function(event)
            {
            
      

                  var pb='This is a public event.\n';
                  var evtName='Event Name   :  '+ event.title; 
                  var evtLink ='Contact to  : '+event.url;
                  var createAd ="Created by Admin.";
                  $('.modal-body #publicEvent').text(pb);
                  $('.modal-body #eventTitle').text(evtName);
                  $('.modal-body #CreateAdmin').text(createAd);
                  $('.modal-body #eventLink').text(evtLink);
                  $('#exampleModalCenter').modal('show');
                  if (event.url) {
            return false;
        }        
              
            }
            
   
            // eventColor:  '#FF6347'
            // function(event)
            // {
            //   var color = #FF6347;
            //   $.ajax({
            //     url:'insert.php',
            //     type:'POST',
            //     data:{color:color},
            //     success:function()
            //     {
            //       calendar.fullCalendar('refetchEvents');
            //     }
            //   })
            // }
          

     });

     function del(event)
     {
       var id = event.id;

      $.ajax({
                  url:"delete.php",
                  type:"POST",
                  data:{id:id},
                  success:function()
                  {
                    calendar.fullCalendar('refetchEvents');
                    // alert("Event Removed!");
                  }
                })
     }

   console.log( $('test-dropdown').val());
   });

//    function choice1(select) {
//      var color_code;
//   if((select.options[select.selectedIndex].text)=='Red'){
//         color_code = '	#FF6347';
//     }
//     else if((select.options[select.selectedIndex].text)=='Blue'){
//         color_code = '#0073CF';
//     }
//     else{
//       color_code = "#88D969";
//     }
//     return color_code;
// }
</script>

</body>
</html>
