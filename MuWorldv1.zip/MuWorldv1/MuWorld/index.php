<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html>
<!--HEADER SECTION -->
<head>
    <meta name="viewport" content="with=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Mu World Website</title>
    <link rel="stylesheet" href="CSS/joshua.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css">
    
    <!-- fontAwesome -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- bootsctrap scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</head>

<?php
//PHP CONDITION TO CHECK IF SOMEONE IS LOGGED IN OR NOT
$log = "<li><a href='login.php'>LOGIN</a></li>" ;
if(isset($_SESSION['semail']))
{
    $log = "<li><a href='includephp/logout.inc.php'>LOGOUT</a></li>";
}
?>

<body>
    <!--Navbar section -->
    <section class="header">
        <?php include_once 'topnavbar.php'; ?>

    <div class="text-box">
    <h1><span>Mu</span>World<span></span></h1>
        <p style="color: #fff;">A platform for students, researchers, employees and organisations to connect and collaborate.<br>A one stop application to connect you with the people you need.</p>
        
        <?php
            if(!isset($_SESSION['semail']))
            {
                echo "<a href='register.php' class='hero-btn'>Register now to Find out more</a>";
            }
        ?>
        
    </div>
    </section>

<!---Features-->
<section class="features">
    <h1>Things you can do</h1>
    <p>Features in the website that you can interact with.</p>
    
    <div class="row">
        <div class="feat-col">
            <h3>Registeration</h3>
            <p>Create an account to be a registered user to access the additional feature which includes the Dashboard where 
                you can meet other users and be updated to the latest researches. Look for reseaches that you can take part in.</p>
        </div>
        <div class="feat-col">
            <h3>Event</h3>
            <p>Be updated in the latest event that are posted and hosted by organisations by looking through the Event Page. Be a Registeres user! so you can  RSVP if you are interested on the activities offered!
                As well as planning your own schedule to keep track of the activities that you have. If you are interested in visiting an organisation do make sure you fill in the form by clicking "Make Visit".
            </p>
        </div>
        <div class="feat-col">
            <h3>Collaborate and Connect</h3>
            <p>Log in now to create research project or upload your research link for users in the website to see. This allows users to collaborate with you or you finding other users
                to collaborate with and stay connected with.
            </p>
        </div>
    </div>

</section>

<!--Campuses-->
<section class="campus">
    <h1>Our Global campus</h1>
    <p>Murdoch is open globally through close partners to channel more students to come.</p>

    <div class="row">
        <!--Campus1-->
        <div class="campus-col">
            <img src="img/dub.png">
            <div class="layer">
                <h3>DUBAI</h3>
            </div>
        </div>
        <!--Campus2-->
        <div class="campus-col">
            <img src="img/aus.png">
            <div class="layer">
                <h3>AUSTRALIA</h3>
            </div>
        </div>
        <!--Campus3-->
        <div class="campus-col">
            <img src="img/sg.png">
            <div class="layer">
                <h3>SINGAPORE</h3>
            </div>
        </div>
    </div>
</section>

<!--MAP TO BE DONE-->
<section class="mapmain">
    <h1>Find our partners around the world!</h1>
    <p>Murdoch University has many partners around the world both domestic and international.</p>

    <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27048.050177484696!2d115.81976459361448!3d-32.069079096241005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2a32a2b900348291%3A0x504f0b535df4c70!2sMurdoch%20WA%206150%2C%20Australia!5e0!3m2!1sen!2ssg!4v1617196196971!5m2!1sen!2ssg" 
    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
    <div class="map-wrapper">
    <div id="map" style="height: 405px; overflow: hidden"></div>
        <select class="layer-picker">
        <option onclick=testFunction0()>All Partners</option>
        <option onclick=testFunction()>Kaplan Singapore</option>
        <option onclick=testFunction1()>Perron Institute</option>
        <option onclick=testFunction2()>Sarepta Therapeutics</option>
        <option onclick=testFunction3()>Harry Perkins Institute of Medical Research</option>
        <option onclick=testFunction4()>Chevron – The Harry Butler Institute</option>
        <option onclick=testFunction5()>Peel-Harvey Catchment Council</option>
        <option onclick=testFunction6()>Bunbury Dolphin Discovery Centre</option>
        <option onclick=testFunction7()>Commonwealth Department of Infrastructure</option>
        <option onclick=testFunction8()>Regional Development</option>
        <option onclick=testFunction9()>Phosphates Resources Limited</option>
        <option onclick=testFunction10()>Western Barley Genetics Alliance</option>
        <option onclick=testFunction11()>Peel Development Commission</option>
        <option onclick=testFunction12()>The University of Western Australia</option>d
        <option onclick=testFunction13()>Curtin university</option>
        <option onclick=testFunction14()>Edith Cowan University</option>
        <option onclick=testFunction15()>Pawsey Supercomputing Centre</option>
        <option onclick=testFunction16()>RAC Arena</option>
        <option onclick=testFunction17()>WACA</option>
        <option onclick=testFunction18()>Home Resources Development Fund</option>
        <option onclick=testFunction19()>K-Pintar Sdn Bhd</option>
        <option onclick=testFunction20()>Universität f. Bodenkultur Wien</option>
        <option onclick=testFunction21()>MCI | The Entrepreneurial School®</option>
        <option onclick=testFunction22()>University in Puch bei Hallein</option>
        <option onclick=testFunction23()>Mount Royal University</option>
        <option onclick=testFunction24()>Simon Fraser University</option>
        <option onclick=testFunction25()>University of Victoria</option>
        <option onclick=testFunction26()>University of Waterloo</option>
        <option onclick=testFunction27()>Communication University of Zhejiang</option>
        <option onclick=testFunction28()>Zhejiang University of Technology</option>
        <option onclick=testFunction29()>University of Zagreb</option>
        <option onclick=testFunction30()>Anglo-American University</option>
        <option onclick=testFunction31()>Danish School of Media and Journalism</option>
        <option onclick=testFunction32()>University of Southern Denmark</option>
        <option onclick=testFunction33()>University of Turku</option>
        <option onclick=testFunction34()>Bremen University of Applied Sciences</option>
        <option onclick=testFunction35()>Hamburg University of Applied Sciences</option>
        <option onclick=testFunction36()>Munich University of Applied Science</option>
        <option onclick=testFunction37()>Ostfalia University of Applied Science</option>
        <option onclick=testFunction38()>University of Oldenburg</option>
        <option onclick=testFunction39()>City University Hong Kong</option>
        <option onclick=testFunction40()>University of Hong Kong</option>
        <option onclick=testFunction41()>O.P. Jindal Global University</option>
        <option onclick=testFunction42()>Griffith College</option>
        <option onclick=testFunction43()>University of Limerick</option>
        <option onclick=testFunction44()>University of Bologna</option>
        <option onclick=testFunction45()>Hokkaido University</option>
        <option onclick=testFunction46()>Konkuk University</option>
        <option onclick=testFunction47()>Utrecht University of Applied Sciences</option>
        <option onclick=testFunction48()>CEU San Pablo University</option>
        <option onclick=testFunction49()>Linnaeus University</option>
        <option onclick=testFunction50()>Lucerne University of Applied Sciences</option>
        <option onclick=testFunction51()>Aberystwyth University</option>
        <option onclick=testFunction52()>California State University Monterey Bay</option>
        </select>
    </div>


</section>

<!--NEWS-->
<section class="news">
    <h1>Catch the latest news</h1>
    <p>Different news taken all from different trustested news network</p>
    <div class="row">
        <!--News1-->
        <div class="news-col">
            <a href="https://www.channelnewsasia.com/news/world/data-withheld-from-who-team-probing-covid-19-origins-in-china-14525720">
            <img src="img/virus.png">
        </a>
            <h3>Data withheld from WHO team probing COVID-19 origins in China: Tedros</h3>
            <p> Data was withheld from World Health Organization investigators who travelled to China to research the origins of the coronavirus epidemic, 
                WHO Director-General Tedros Adhanom Ghebreyesus said on Tuesday (Mar 30).</p>
        </div>
        
         <!--News2-->
         <div class="news-col">
            <a href="https://edition.cnn.com/2021/03/30/asia/thailand-myanmar-refugees-intl-hnk/index.html">
            <img src="img/myan.png">
        </a>
            <h3>Thailand pushes back thousands fleeing Myanmar as death toll surpasses 500</h3>
            <p>Thailand has reportedly pushed back more than 2,000 people attempting to flee neighboring Myanmar following a series of air strikes carried out by the ruling junta in the southeast of the country..</p>
        </div>

         <!--News3-->
         <div class="news-col">
            <a href="https://www.straitstimes.com/business/invest/many-dont-know-the-costs-of-retirement">
            <img src="img/old.png">
        </a>
            <h3>Many in S'pore don't know the costs of retirement</h3>
            <p> One in every two people underestimates the monthly expenses needed, according to survey by Invest and OCBC Bank.</p>
        </div>
    </div>
</section>

<!--Reviews-->
<section class="review">
    <h1>What our Users Says</h1>
    <p>See what our user has to say about the website!</p>

    <div class="row">
        <!--Review1-->
        <div class="review-col">
            <img src="img/user1.png">
            <div>
                <p>The website has provided me enough features to be able to find 
                    suitable people to collaborate work with and provides a platform
                     for me to meet and socialise with new people.</p>
                     <h3>Yong Kang</h3>
            </div>
        </div>
        <!--Review1-->
        <div class="review-col">
            <img src="img/user2.png">
            <div>
                <p>The website is a wonderful platform for me to meet other users who are 
                    interested in looking for potential candidates to work with, as well as to showcase
                    some research I've done to find suitable organisations.</p>
                     <h3>Juswa Ace</h3>
            </div>
        </div>
    </div>
</section>

<!--Contact Us-->
<section class="contact">
    <h1>Got any question?<br>Feel free to email us and we'll respond ASAP!</h1>
    <a href="about.php" class=hero-btn>CONTACT US</a>
</section>

<!--FOOTER SECTION-->
<section class="footer">
    <h4>MuWorld</h4>
<p>A multi-media connection system. <br>A platform to provide FOLLOW UPS for user to stay in touch
    with each other. <br><a href="faq.php">FAQ</a></p>
    <p>Made with <i class="fa fa-heart"></i> by Local Sense</p>
</section>

<!--Javascript for Toggle Menu-->
<script>
        var navLinks = document.getElementById("navLinks");

        function showMenu(){
            navLinks.style.right = "0";
        }
        function hideMenu(){
            navLinks.style.right = "-200px";
        }

    </script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="javascript/idx.js"></script>
<!-- leaflet -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="javascript/partnermap.js"></script>
</body>
</html>

