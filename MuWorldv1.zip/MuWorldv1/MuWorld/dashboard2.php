<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';

    if(!isset($_SESSION['semail']))
    {
        header('location: index.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<!--HEADER SECTION -->
<head>
    <meta name="viewport" content="with=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Mu World Website</title>
    <link rel="stylesheet" href="CSS/joshua.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    
    <!-- leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css">

    <link rel="stylesheet" href="CSS/joshua.css">

    <!-- fontAwesome -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- bootsctrap scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    <!-- Table styling -->
    <style>
        table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
        }

        tr:nth-child(even) {
        background-color: white;
        }
    </style>

</head>

<body style='background: #F0F0F0;'>
    <!--Navbar section -->
    <section>
        <?php include_once 'topnavbar.php'; ?>
    </section>

<!---Features-->
<section class="dash-first">
    <h1 style='text-align:left;'><b>Dashboard</b></h1>
    <div class="dash-row">
        <a class='dash dash-hbox' href='friends.php'>
                <h3><b>Friends</b></h3>
                <h5>My friend list<br><br><br><br><br></h5>
        </a>
        <a class='dash dash-hbox' href='research.php'>
            <h3><b>Researches</b></h3>
            <h5>My research list</h5>
        </a>
        <a class='dash dash-hbox' href='calendar.php'>
            <h3><b>Calendar</b></h3>
            <h5>My personal calendar</h5>
        </a>
    </div>

</section>

<!-- Admin Features -->
<?php
if($_SESSION['suserid']==1)
{
    echo "
    <section class='dash-first'>
        <h1 style='text-align:left;'><b>Admin Features</b></h1>
        
        <div class='dash-row'>
            <a class='dash dash-hbox' href='reports.php'>
                    <h3><b>Reports</b></h3>
                    <h5>Website reports<br><br><br><br><br></h5>
            </a>
            <a class='dash dash-hbox' href='eventActivities.php'>
                <h3><b>Event Activities</b></h3>
                <h5>Website Events</h5>
            </a>
            <a class='dash dash-hbox' href='allorg.php'>
                <h3><b>Organisation</b></h3>
                <h5>Website Organistations</h5>
            </a>
        </div>

    </section>
         ";
}
?>

<!-- Latest research -->
<section class="dash-research">
    <h1 style='text-align:left;'><b>Latest Researches</b></h1>
    <a href='createresearch.php'><button class='btn btn-outline-danger' style='float:right;margin-bottom:10px;'>+</button></a>
    
    <div class='dash-col'>
        <?php
          $sql = "SELECT * FROM research ORDER BY rcdate DESC LIMIT 6;";
          $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
          
          //Condition to prepare the stmt variable if successful carrys on if not show fail message.
          if(!mysqli_stmt_prepare($stmt,$sql))
          {
              header("location: enhancedsearch-results.php?error=stmtfailed");
              exit();
          }

          mysqli_stmt_execute($stmt);
          
          $result = mysqli_stmt_get_result($stmt);

          if($numrows = mysqli_num_rows($result) >0)
          {
                while($row = mysqli_fetch_assoc($result))
                {
                $uExists = userIDExists($con,$row['rcreator']);
                $uProfile = profileExistsID($con,$row['rcreator']);
                $orgname;
                if(checkOrgID($con,$row['rorg'])!==false)
                {
                    $org = checkOrgID($con,$row['rorg']);
                    $orgname = $org['orgname'];
                }
                else
                {
                    $orgname = "No Organisation";
                }

                    echo"       
            <!-- Research Article -->
            <div class='dash-vbox'>
                    <div style='display:table-row;'>
                        <span style='display:table-cell;'><a href='detailedresearch.php?ID=$row[rid]'>$row[rtitle]</a></span> 
                        <span style='display:table-cell;'><img src='img/$uProfile[ProfilePicture]' class='rounded-circle' style='width:50px;height:50px;'></img></span>
                        <span style='display:table-cell;'><a href='profile.php?name=".$uExists['Name']."&token=".$uExists['Token']."'>$uExists[Name]</a></span>
                        <span style='display:table-cell;'><a href='org-profile.php?ID=$row[rorg]'>$orgname</a></span>
                    </div>
            </div>
                        ";
                }
          }
        ?>
    </div>
</section>

<!-- Feedback Report -->
<section class="dash-research">
    <h1 style='text-align:left;'><b>Feedback Reports</b></h1>
    <a href='reportform.php'><button class='btn btn-outline-danger' style='float:right;margin-bottom:10px;'>+</button></a>
    <table>
    <!--Heading Row-->
        <tr>
            <th>Report ID</th>
            <th>Event Title</th>
            <th>Event Host</th>
            <th>Date Event Ended</th>
            <th>Status</th>
            <th>Date of Submission</th>
        </tr>
        <!--Row Results-->
        <?php
            $sql = "SELECT * FROM eventreports WHERE ERuid = $_SESSION[suserid];";
            $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
            
            //Condition to prepare the stmt variable if successful carrys on if not show fail message.
            if(!mysqli_stmt_prepare($stmt,$sql))
            {
                throw new exception("Error: STMT FAILED");
                exit();
            }

            mysqli_stmt_execute($stmt);
            
            $result = mysqli_stmt_get_result($stmt);

            

            if($numrows = mysqli_num_rows($result) >0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    $event = checkEventExists($con,$row['EReid']);
                    
                    echo"
                    <tr>
                        <th><a href='detailedreport.php?ID=$row[ERid]'>$row[ERid]</a></th>
                        <th>$event[title]</th>
                        <th>$row[Hevent]</th>
                        <th>$event[admin_end]</th>
                        <th>$row[ERstatus]</th>
                        <th>$row[ERdate]</th>
                    </tr>
                        ";
                        
                }
            }
        ?>  
    </table>
</section>

<!--MAP TO BE DONE-->
<section class="mapmain">
    <h1>Find our partners around the world!</h1>
    <p>Murdoch University has many partners around the world both domestic and international.</p>

    <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27048.050177484696!2d115.81976459361448!3d-32.069079096241005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2a32a2b900348291%3A0x504f0b535df4c70!2sMurdoch%20WA%206150%2C%20Australia!5e0!3m2!1sen!2ssg!4v1617196196971!5m2!1sen!2ssg" 
    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
    <div class="map-wrapper">
    <div id="map" style="height: 405px; overflow: hidden"></div>
        <select class="layer-picker">
        <option onclick=testFunction0()>All Partners</option>
        <option onclick="testFunction()">Kaplan Singapore</option>
        <option onclick=testFunction1()>Perron Institute</option>
        <option onclick=testFunction2()>Sarepta Therapeutics</option>
        <option onclick=testFunction3()>Harry Perkins Institute of Medical Research</option>
        <option onclick=testFunction4()>Chevron – The Harry Butler Institute</option>
        <option onclick=testFunction5()>Peel-Harvey Catchment Council</option>
        <option onclick=testFunction6()>Bunbury Dolphin Discovery Centre</option>
        <option onclick=testFunction7()>Commonwealth Department of Infrastructure</option>
        <option onclick=testFunction8()>Regional Development</option>
        <option onclick=testFunction9()>Phosphates Resources Limited</option>
        <option onclick=testFunction10()>Western Barley Genetics Alliance</option>
        <option onclick=testFunction11()>Peel Development Commission</option>
        <option onclick=testFunction12()>The University of Western Australia</option>d
        <option onclick=testFunction13()>Curtin university</option>
        <option onclick=testFunction14()>Edith Cowan University</option>
        <option onclick=testFunction15()>Pawsey Supercomputing Centre</option>
        </select>
    </div>


</section>

<!--Footer-->
<section class="footer">
    <h4>MuWorld</h4>
<p>A multi-media connection system. <br>A platform to provide FOLLOW UPS for user to stay in touch
    with each other. <br><a href="faq.php">FAQ</a></p>
    <p>Made with <i class="fa fa-heart"></i> by Local Sense</p>
</section>
<!--Javascript for Toggle Menu-->
<script>
        var navLinks = document.getElementById("navLinks");

        function showMenu(){
            navLinks.style.right = "0";
        }
        function hideMenu(){
            navLinks.style.right = "-200px";
        }

    </script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="javascript/idx.js"></script>
<!-- leaflet -->
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
<script src="javascript/partnermap.js"></script>
</body>
</html>