-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2021 at 05:33 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_event`
--

CREATE TABLE `admin_event` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `admin_start` datetime NOT NULL,
  `admin_end` datetime NOT NULL,
  `admin_color` varchar(10) NOT NULL DEFAULT '#fd08cd'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_event`
--

INSERT INTO `admin_event` (`id`, `title`, `admin_start`, `admin_end`, `admin_color`) VALUES
(4, 'YK touchingself day', '2021-03-20 23:30:00', '2021-03-24 23:30:00', '#fd08cd'),
(6, 'Jumbo', '2021-03-09 00:00:00', '2021-03-09 04:30:00', '#fd08cd'),
(7, 'Joko', '2021-03-07 02:00:00', '2021-03-07 04:30:00', '#fd08cd');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_event` datetime NOT NULL,
  `end_event` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_color` varchar(10) NOT NULL DEFAULT '#2ae26a'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `start_event`, `end_event`, `user_id`, `event_color`) VALUES
(28, 'w', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 4, '#2ae26a'),
(29, 'asd', '2021-03-26 00:00:00', '2021-03-27 00:00:00', 4, '#2ae26a'),
(30, 'l', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 4, '#2ae26a'),
(31, 's', '2021-03-26 00:00:00', '2021-03-27 00:00:00', 4, '#2ae26a'),
(32, 'cv', '2021-03-01 00:00:00', '2021-03-02 00:00:00', 4, '#2ae26a'),
(37, 'YK\'s blue', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 2, '#0071c5'),
(38, 'YK\'s amraella', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 2, '#FFD700'),
(39, 'YK\'s hair', '2021-03-27 00:00:00', '2021-03-28 00:00:00', 2, '#000'),
(56, 'Junko\'s BD', '2021-03-27 00:00:00', '2021-03-28 00:00:00', 3, '#FF8C00');

-- --------------------------------------------------------

--
-- Table structure for table `friendstatus`
--

CREATE TABLE `friendstatus` (
  `FRuids` int(11) NOT NULL,
  `FRuidr` int(11) NOT NULL,
  `FRstatus` varchar(20) NOT NULL,
  `FRdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendstatus`
--

INSERT INTO `friendstatus` (`FRuids`, `FRuidr`, `FRstatus`, `FRdate`) VALUES
(1, 5, 'accepted', '2021-03-29 00:50:17'),
(2, 1, 'accepted', '2021-03-25 11:40:49'),
(2, 3, 'accepted', '2021-03-26 20:35:36'),
(3, 1, 'accepted', '2021-03-25 14:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `Lid` int(11) NOT NULL,
  `Lname` varchar(256) NOT NULL,
  `Lcdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`Lid`, `Lname`, `Lcdate`) VALUES
(1, 'Singapore', '2021-03-28 08:16:55'),
(2, 'Australia', '2021-03-28 08:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `nid` int(11) NOT NULL,
  `nuid` int(11) NOT NULL,
  `ntype` varchar(11) NOT NULL,
  `nmessage` text NOT NULL,
  `nstatus` varchar(11) NOT NULL,
  `ndate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table to store notifications on the website.';

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`nid`, `nuid`, `ntype`, `nmessage`, `nstatus`, `ndate`) VALUES
(6, 1, 'friend', 'You have a friend request from Melissa Low', 'read', '2021-03-25 11:40:49'),
(7, 1, 'friend', 'You have a friend request from Liang Chai', 'read', '2021-03-25 14:14:40'),
(8, 3, 'friend', 'You have a friend request from Melissa Low', 'read', '2021-03-26 20:35:36'),
(9, 5, 'friend', 'You have a friend request from Ng Yong Kang', 'read', '2021-03-29 00:50:17');

-- --------------------------------------------------------

--
-- Table structure for table `occupations`
--

CREATE TABLE `occupations` (
  `Oid` int(11) NOT NULL,
  `Oname` varchar(256) NOT NULL,
  `Ocdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `occupations`
--

INSERT INTO `occupations` (`Oid`, `Oname`, `Ocdate`) VALUES
(1, 'Student', '2021-03-28 08:56:35'),
(2, 'Researcher', '2021-03-28 08:56:35'),
(3, 'Staff', '2021-03-28 08:56:46');

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE `organisations` (
  `orgid` int(11) NOT NULL,
  `orgname` varchar(256) NOT NULL,
  `orgcdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organisations`
--

INSERT INTO `organisations` (`orgid`, `orgname`, `orgcdate`) VALUES
(1, 'Murdoch University', '2021-03-28 20:51:07');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `ID` int(11) NOT NULL COMMENT 'Foreign Key From user table',
  `Education` varchar(256) DEFAULT NULL,
  `Location` text DEFAULT NULL,
  `Occupation` text DEFAULT NULL,
  `ProfilePicture` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`ID`, `Education`, `Location`, `Occupation`, `ProfilePicture`) VALUES
(1, 'Double Degree in Computer Science & Cyber Forensics', 'Singapore', 'Student', 'unr_mionkll_210213_0159_2rnqlag.png'),
(2, 'Double Degree in Marketing & Sales', 'Singapore, Toa Payoh street 10 (310213)', 'Website Engineer', 'user3-128x128.jpg'),
(3, NULL, NULL, NULL, 'CHAIAHHHH.jpeg'),
(4, NULL, NULL, NULL, 'unr_kylepalacios_210128_0058_zskm9.png'),
(5, NULL, NULL, NULL, 'avatar4.png'),
(6, NULL, NULL, NULL, 'avatar5.png'),
(7, NULL, NULL, NULL, 'avatar3.png'),
(8, NULL, NULL, NULL, 'unr_mijjjjjjjjjjj_201207_0745_9gs8qn.png');

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE `research` (
  `rid` int(11) NOT NULL,
  `rtitle` varchar(256) NOT NULL,
  `rdescript` text NOT NULL,
  `rlink` varchar(256) NOT NULL,
  `rcreator` int(11) NOT NULL COMMENT 'Foreign key from user table',
  `rcdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `research`
--

INSERT INTO `research` (`rid`, `rtitle`, `rdescript`, `rlink`, `rcreator`, `rcdate`) VALUES
(1, 'Research on buttocks', 'Researching the buttocks of humans.', 'https://www.google.com/', 1, '2021-03-23 00:00:00'),
(4, 'Research on monkeys', 'Researching monkeys buttocks...', 'https://www.yahoo.com/', 2, '2021-03-25 00:00:00'),
(5, 'Research on Chefs in Singapore', 'Research is made to analyze the many difficulties a Chef in Singapore faces.', 'https://www.msn.com/', 3, '2021-03-27 11:32:13'),
(7, 'Mu World', 'A research project to create a website to allow researchers to collaborate and stay connected, this project will be used to provide a baseline on how to do so and executed on a later date.', 'http://localhost/index.php', 4, '2021-03-28 19:23:15');

-- --------------------------------------------------------

--
-- Table structure for table `researchusers`
--

CREATE TABLE `researchusers` (
  `RUrid` int(11) NOT NULL,
  `RUuid` int(11) NOT NULL,
  `RUstatus` varchar(11) NOT NULL,
  `RUdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `researchusers`
--

INSERT INTO `researchusers` (`RUrid`, `RUuid`, `RUstatus`, `RUdate`) VALUES
(1, 1, 'Admin', '2021-03-27 19:12:32'),
(4, 2, 'Admin', '2021-03-27 19:12:32'),
(5, 1, 'Member', '2021-03-27 21:41:01'),
(5, 3, 'Admin', '2021-03-27 19:12:32'),
(7, 1, 'Member', '2021-03-28 19:25:48'),
(7, 4, 'Admin', '2021-03-28 19:23:15'),
(7, 5, 'Member', '2021-03-28 19:30:59'),
(7, 6, 'Member', '2021-03-28 19:40:36'),
(7, 7, 'Member', '2021-03-28 19:43:41'),
(7, 8, 'Member', '2021-03-28 19:45:23');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `sid` int(11) NOT NULL,
  `sname` varchar(256) NOT NULL,
  `scategory` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`sid`, `sname`, `scategory`) VALUES
(1, 'HTML', 'Programming Language'),
(2, 'Javascript', 'Programming Language'),
(3, 'PHP', 'Programming Language'),
(4, 'Sales', 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `skillsuser`
--

CREATE TABLE `skillsuser` (
  `SUsid` int(11) NOT NULL,
  `SUuid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skillsuser`
--

INSERT INTO `skillsuser` (`SUsid`, `SUuid`) VALUES
(1, 1),
(2, 1),
(3, 2),
(4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `Password` varchar(256) NOT NULL,
  `Token` varchar(256) NOT NULL,
  `Verified` tinyint(1) NOT NULL DEFAULT 0,
  `CreateDate` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Email`, `Password`, `Token`, `Verified`, `CreateDate`) VALUES
(1, 'Ng Yong Kang', 'nyk.com.sg@gmail.com', '$2y$10$xl7Mv5ULT9VCnoYuEgVl7eKErgJIRUgeyUHiS5fVjPJSPnfQbHZrG', 'c2a4c741cbefdb5284f45553989125f8', 1, '2021-03-19 23:12:42.931176'),
(2, 'Melissa Low', 'nykslashbaka@gmail.com', '$2y$10$Y4KwMzSxq88YOZBhbgLsv..kTAvs/qqj7uSsLSuBkoPQVNq8I/Ghi', 'ab258a2a44d8ecc3b75ff5201f22ee95', 1, '2021-03-25 03:32:10.074092'),
(3, 'Liang Chai', 'lc@gmail.com', '$2y$10$Ip8OGFwU6TabXgQGtnfbZ.SaixwVHVKbgA1WVfiSD4dfVJNF2tLOG', 'a2448283b0b8d51ccffb81b44e4f2c07', 1, '2021-03-25 06:13:26.069540'),
(4, 'Joshua', 'j@gmail.com', '$2y$10$5ssGPu0aFl.lmkS7WIwpH.2IHPhneWmYAr1YKhi/RULjpg7FDYacm', '896010de9d955ee0c976c9daab4be196', 1, '2021-03-28 11:15:00.413777'),
(5, 'Charles', 'c@gmail.com', '$2y$10$A7HrbEuvpcKrwOq70urfn.DytCpFnY.o1KREiB/FSh0cxXAxf5QRa', '5ce8fc049c802a892e0886d667fdcd96', 1, '2021-03-28 11:29:40.626232'),
(6, 'Vicky', 'v@gmail.com', '$2y$10$EJWkPp0CI2lQ166dhU/AuOBdx4.lVzfZoHBpFYNLQkEBTpyhwBr02', '60ab8e1877d7e801b1dbf36658ea1ec6', 1, '2021-03-28 11:39:38.969578'),
(7, 'Doris', 'd@gmail.com', '$2y$10$4rAsYdaEKeUvNXrfO7pxnOCqYqNiBOeaXn8RdGmxidygKo8hqxBfO', '7267ad5cc5f808b098e2e54d94be6922', 1, '2021-03-28 11:41:05.817528'),
(8, 'Sahana', 's@gmail.com', '$2y$10$m/YThdNE48a8VtZPtJHtwe0Y3uuD2PwrQWcEFR56zs2ZFMN0inKOK', '454631628bb2238a83f795e76aba1fcd', 1, '2021-03-28 11:44:04.226488');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_event`
--
ALTER TABLE `admin_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test` (`user_id`);

--
-- Indexes for table `friendstatus`
--
ALTER TABLE `friendstatus`
  ADD PRIMARY KEY (`FRuids`,`FRuidr`),
  ADD KEY `FR_link-to-user(r)` (`FRuidr`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`Lid`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`nid`),
  ADD KEY `nuid` (`nuid`);

--
-- Indexes for table `occupations`
--
ALTER TABLE `occupations`
  ADD PRIMARY KEY (`Oid`);

--
-- Indexes for table `organisations`
--
ALTER TABLE `organisations`
  ADD PRIMARY KEY (`orgid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `research`
--
ALTER TABLE `research`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `r-creator` (`rcreator`);

--
-- Indexes for table `researchusers`
--
ALTER TABLE `researchusers`
  ADD PRIMARY KEY (`RUrid`,`RUuid`),
  ADD KEY `ru_link-to-user` (`RUuid`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `skillsuser`
--
ALTER TABLE `skillsuser`
  ADD PRIMARY KEY (`SUsid`,`SUuid`),
  ADD KEY `su_link-to-user` (`SUuid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_event`
--
ALTER TABLE `admin_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `Lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `occupations`
--
ALTER TABLE `occupations`
  MODIFY `Oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `organisations`
--
ALTER TABLE `organisations`
  MODIFY `orgid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `research`
--
ALTER TABLE `research`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `test` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `friendstatus`
--
ALTER TABLE `friendstatus`
  ADD CONSTRAINT `FR_link-to-user(r)` FOREIGN KEY (`FRuidr`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FR_link-to-user(s)` FOREIGN KEY (`FRuids`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `n_link_to_user` FOREIGN KEY (`nuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `User Profile` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `research`
--
ALTER TABLE `research`
  ADD CONSTRAINT `link-to-user` FOREIGN KEY (`rcreator`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `researchusers`
--
ALTER TABLE `researchusers`
  ADD CONSTRAINT `ru_link-to-research` FOREIGN KEY (`RUrid`) REFERENCES `research` (`rid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_link-to-user` FOREIGN KEY (`RUuid`) REFERENCES `user` (`ID`);

--
-- Constraints for table `skillsuser`
--
ALTER TABLE `skillsuser`
  ADD CONSTRAINT `su_link-to-skills` FOREIGN KEY (`SUsid`) REFERENCES `skills` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `su_link-to-user` FOREIGN KEY (`SUuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
