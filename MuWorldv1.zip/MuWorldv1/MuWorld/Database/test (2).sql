-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2021 at 08:05 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `friendstatus`
--

CREATE TABLE `friendstatus` (
  `FRuids` int(11) NOT NULL,
  `FRuidr` int(11) NOT NULL,
  `FRstatus` varchar(20) NOT NULL,
  `FRdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendstatus`
--

INSERT INTO `friendstatus` (`FRuids`, `FRuidr`, `FRstatus`, `FRdate`) VALUES
(2, 1, 'accepted', '2021-03-25 11:40:49'),
(3, 1, 'accepted', '2021-03-25 14:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `nid` int(11) NOT NULL,
  `nuid` int(11) NOT NULL,
  `ntype` varchar(11) NOT NULL,
  `nmessage` text NOT NULL,
  `nstatus` varchar(11) NOT NULL,
  `ndate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table to store notifications on the website.';

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`nid`, `nuid`, `ntype`, `nmessage`, `nstatus`, `ndate`) VALUES
(6, 1, 'friend', 'You have a friend request from Melissa Low', 'read', '2021-03-25 11:40:49'),
(7, 1, 'friend', 'You have a friend request from Liang Chai', 'read', '2021-03-25 14:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `ID` int(11) NOT NULL COMMENT 'Foreign Key From user table',
  `Education` varchar(256) DEFAULT NULL,
  `Location` text DEFAULT NULL,
  `Occupation` text DEFAULT NULL,
  `ProfilePicture` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`ID`, `Education`, `Location`, `Occupation`, `ProfilePicture`) VALUES
(1, 'Double Degree in Computer Science & Cyber Forensics', 'Singapore, Tampines street 123 (250431)', 'Website Developer', 'avatar5.png'),
(2, 'Double Degree in Marketing & Sales', 'Singapore, Toa Payoh street 10 (310213)', 'Website Engineer', 'user3-128x128.jpg'),
(3, NULL, NULL, NULL, 'CHAIAHHHH.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE `research` (
  `rid` int(11) NOT NULL,
  `rtitle` varchar(256) NOT NULL,
  `rdescript` text NOT NULL,
  `rlink` varchar(256) NOT NULL,
  `rcreator` int(11) NOT NULL,
  `rcdate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `research`
--

INSERT INTO `research` (`rid`, `rtitle`, `rdescript`, `rlink`, `rcreator`, `rcdate`) VALUES
(1, 'Research on buttocks', 'Researching the buttocks of humans.', 'https://www.google.com/', 1, '2021-03-23'),
(2, 'Research on buttocks', 'qwe', 'https://www.google.com/', 1, '2021-03-23'),
(4, 'Research on monkeys', 'Researching monkeys buttocks...', 'https://www.yahoo.com/', 2, '2021-03-25');

-- --------------------------------------------------------

--
-- Table structure for table `researchusers`
--

CREATE TABLE `researchusers` (
  `RUrid` int(11) NOT NULL,
  `RUuid` int(11) NOT NULL,
  `RUstatus` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `researchusers`
--

INSERT INTO `researchusers` (`RUrid`, `RUuid`, `RUstatus`) VALUES
(1, 1, 'Admin'),
(2, 1, 'Admin'),
(4, 2, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `sid` int(11) NOT NULL,
  `sname` varchar(256) NOT NULL,
  `scategory` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`sid`, `sname`, `scategory`) VALUES
(1, 'HTML', 'Programming Language'),
(2, 'Javascript', 'Programming Language'),
(3, 'PHP', 'Programming Language'),
(4, 'Sales', 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `skillsuser`
--

CREATE TABLE `skillsuser` (
  `SUsid` int(11) NOT NULL,
  `SUuid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skillsuser`
--

INSERT INTO `skillsuser` (`SUsid`, `SUuid`) VALUES
(1, 1),
(2, 1),
(3, 2),
(4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `Password` varchar(256) NOT NULL,
  `Token` varchar(256) NOT NULL,
  `Verified` tinyint(1) NOT NULL DEFAULT 0,
  `CreateDate` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Email`, `Password`, `Token`, `Verified`, `CreateDate`) VALUES
(1, 'Ng Yong Kang', 'nyk.com.sg@gmail.com', '$2y$10$xl7Mv5ULT9VCnoYuEgVl7eKErgJIRUgeyUHiS5fVjPJSPnfQbHZrG', 'c2a4c741cbefdb5284f45553989125f8', 1, '2021-03-19 23:12:42.931176'),
(2, 'Melissa Low', 'nykslashbaka@gmail.com', '$2y$10$Y4KwMzSxq88YOZBhbgLsv..kTAvs/qqj7uSsLSuBkoPQVNq8I/Ghi', 'ab258a2a44d8ecc3b75ff5201f22ee95', 1, '2021-03-25 03:32:10.074092'),
(3, 'Liang Chai', 'lc@gmail.com', '$2y$10$Ip8OGFwU6TabXgQGtnfbZ.SaixwVHVKbgA1WVfiSD4dfVJNF2tLOG', 'a2448283b0b8d51ccffb81b44e4f2c07', 1, '2021-03-25 06:13:26.069540');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `friendstatus`
--
ALTER TABLE `friendstatus`
  ADD PRIMARY KEY (`FRuids`,`FRuidr`),
  ADD KEY `FR_link-to-user(r)` (`FRuidr`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`nid`),
  ADD KEY `nuid` (`nuid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `research`
--
ALTER TABLE `research`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `r-creator` (`rcreator`);

--
-- Indexes for table `researchusers`
--
ALTER TABLE `researchusers`
  ADD PRIMARY KEY (`RUrid`,`RUuid`),
  ADD KEY `ru_link-to-user` (`RUuid`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `skillsuser`
--
ALTER TABLE `skillsuser`
  ADD PRIMARY KEY (`SUsid`,`SUuid`),
  ADD KEY `su_link-to-user` (`SUuid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `research`
--
ALTER TABLE `research`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `friendstatus`
--
ALTER TABLE `friendstatus`
  ADD CONSTRAINT `FR_link-to-user(r)` FOREIGN KEY (`FRuidr`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FR_link-to-user(s)` FOREIGN KEY (`FRuids`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `n_link_to_user` FOREIGN KEY (`nuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `User Profile` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `research`
--
ALTER TABLE `research`
  ADD CONSTRAINT `link-to-user` FOREIGN KEY (`rcreator`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `researchusers`
--
ALTER TABLE `researchusers`
  ADD CONSTRAINT `ru_link-to-research` FOREIGN KEY (`RUrid`) REFERENCES `research` (`rid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_link-to-user` FOREIGN KEY (`RUuid`) REFERENCES `user` (`ID`);

--
-- Constraints for table `skillsuser`
--
ALTER TABLE `skillsuser`
  ADD CONSTRAINT `su_link-to-skills` FOREIGN KEY (`SUsid`) REFERENCES `skills` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `su_link-to-user` FOREIGN KEY (`SUuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
