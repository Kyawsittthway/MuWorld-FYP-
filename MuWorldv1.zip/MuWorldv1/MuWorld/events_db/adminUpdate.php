<?php

 if(isset($_SESSION['semail']))
 {
   $usr_id =$_SESSION['suserid'];
 
 }
$connect = new PDO('mysql:host=localhost;dbname=test','root','');

if(isset($_POST["id"]))
{
    $query ="
    UPDATE admin_event 
    SET title=:title, admin_start=:admin_start, admin_end=:admin_end
    WHERE id=:id
    ";

    $statement = $connect->prepare($query);
    $statement->execute(
        array(
            ':title'        => $_POST['title'],
            ':admin_start'  => $_POST['start'],
            ':admin_end'    => $_POST['end'],
            ':id'           =>$_POST['id']
        )
        );
}
?>