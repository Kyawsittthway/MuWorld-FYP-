<?php

    if(isset($_SESSION['semail']))
    {
      $usr_id =$_SESSION['suserid'];
    
    } 

$connect = new PDO('mysql:host=localhost;dbname=test','root','');

if(isset($_POST["title"]))
{
    $query = 
    "INSERT INTO admin_event (title,admin_start,admin_end,link) VALUES (:title,:admin_start,:admin_end,:link)";
    $statement = $connect->prepare($query);
    $statement->execute(
        array(
            ':title'        => $_POST['title'],
            ':admin_start'  => $_POST['start'],
            ':admin_end'    => $_POST['end'],
            ':link'         =>$_POST['link']
           
            
            

            )
        );
}

?>