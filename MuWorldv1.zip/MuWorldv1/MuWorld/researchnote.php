<?php 
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
    <!-- CSS FILES -->
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 
    <link rel='stylesheet' href='CSS/test.css'> 
    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <!-- Javascripts -->

    <!-- ajax script for dynamic webpage -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <!-- Select2 script for form multiple options -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- custom-file-input script for file name to show up -->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
</head>
<body>
    <!--Research Section-->
    <section>
    <div class='container'>
        <h1>Research Notifications</h1>
        <a href='dashboard2.php'><button class='btn btn-outline-danger fas fa-step-backward' style='margin-bottom:10px;'></button></a>
        <?php
                      $uid = $_SESSION['suserid'];
                       //SQL statement for database, might be subjected to change!!**
                      $sql = "SELECT * FROM notifications WHERE ntype = 'research' AND nuid = $uid AND nstatus = 'unread'";
                      $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                      
                      //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                      if(!mysqli_stmt_prepare($stmt,$sql))
                      {
                          trigger_error($con->error, E_USER_ERROR); //used to check sql errors
                          exit();
                      }
                      mysqli_stmt_execute($stmt);
                      $result = mysqli_stmt_get_result($stmt);
                      if($numrows = mysqli_num_rows($result) >0)
                      {
                        while($row = mysqli_fetch_assoc($result))
                        {
                          
                          echo "
                          <div class='list-group-item'>
                              <div class='row'>
                                  <div class='col-auto'>
                    
                                  </div>
                                  <div class='col px-4'>
                                      <div>
                                          <div class='float-right'>
                                            <form action='includephp/researchnote.inc.php' method='POST'>
                                            <input type='submit' name='deletenote' class='btn btn-outline-danger' value='X'>
                                            <input type='hidden' name='NID' value='$row[nid]'>
                                            </form>
                                          </div>
                                          
                                          <h5>$row[nmessage]</h5>
                                          <p class='mb-0'></p>
                                         
                                      </div>
                                  </div>
                              </div>
                          </div>
                          ";
                        }
                      }
                      else
                      {
                        echo "
                        <div class='list-group-item'>
                            <div class='row'>
                                <div class='col-auto'>
                                
                                </div>
                                <div class='col px-4'>
                                    <div>
                                        <div class='float-right'></div>
                                        <h5 align='center'>no research notifications.</h5>
                                        <p class='mb-0'></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ";
                      }
                      mysqli_stmt_close($stmt);
                      ?>
    </div>
    </section>
</body>
</html>