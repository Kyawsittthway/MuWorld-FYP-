<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php'; 

    if(!isset($_SESSION['semail']))
    {
        header('location: index.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name='viewport' content='with=device-width, initial-scale=1.0'>
    <title>Mu World Website</title>
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 

    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet">


    <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- bootsctrap scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!--
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    
    --> 
</head>
<body>
    <!--Navigation Bar -->
        <section class='dash-header'>
            <?php include_once 'topnavbar.php'; ?> 
        </section>  

<?php
    if(isset($_GET['token']))
    {
        $User = uTokenExists($con,$_GET['token']);
        $UPro = profileExistsID($con,$User['ID']);
    }
    else if(isset($_SESSION['semail']))
    {
        $User = userIDExists($con,$_SESSION['suserid']);
        $UPro = profileExistsID($con,$_SESSION['suserid']);
    }

    $UOrgResult;
    if(checkOrgID($con, $UPro['Organisation'])!==false)
    {
        $UOrg = checkOrgID($con, $UPro['Organisation']);
        $UOrgResult = $UOrg['orgname'];
    }
    else
    {
        $UOrgResult = '';
    }

    $UDepResult;
    if(checkDepID($con,$UPro['Department'])!==false)
    {
        $UDep = checkDepID($con,$UPro['Department']);
        $UDepResult = $UDep['Dname'];
    }
    else
    {
        $UDepResult = '';
    }
?>


 <!--Profile Section-->
<section class='prof-sect'>
    <div class='container'>
        <div class='main-body'>
            <div class='row gutters-sm'>
                <div class='col-md-4 mb-3'>
                <div class='card'>
                    <div class='card-body'>
                    <div class='d-flex flex-column align-items-center text-center'>
                        <?php
                        //Edit button should only be on the profile page.
                        if(isset($_GET['token']))
                        {

                        }
                        else if(isset($_SESSION['semail']))
                        {
                            echo "<a href='editprofile.php'><button class='btn btn-outline-primary fas fa-edit'></button></a>";
                        }
                        ?>
                        
                        <br>
                        <img src=<?php echo "img/$UPro[ProfilePicture]" ?> onerror="this.src='img/beard.png'" class='rounded-circle' style='width:170px;height:170px;'>
                        <div class='mt-3'>
                        <h4><?php echo $User['Name'] ?></h4>
                        <p class='text-secondary mb-1'><?php echo $UPro['Occupation']; ?></p>
                        <!-- SKILL SECTION -->
                        <?php
                            $sql = "SELECT * FROM skillsuser WHERE SUuid = $User[ID];";
                            $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                
                                //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                if(!mysqli_stmt_prepare($stmt,$sql))
                                {
                                    header("location: profile.php?error=stmtfailed");
                                    exit();
                                }
                                
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);
                                if($numrows = mysqli_num_rows($result) >0)
                                {
                                  echo "<p class='text-muted font-size-sm'><span style='color:black;font-size:20px;'><b>Talents</b></span><br>";
                                  while($row = mysqli_fetch_assoc($result))
                                  {
                                    $skill = checkSkillExistsID($con,$row['SUsid']);
                                    echo "$skill[sname]<br>";
                                  }
                                  echo "</p>";
                                }
                        ?>
                        <!-- END OF SKILL SECTION -->
                        <?php
                            if(isset($_SESSION['semail'])&& $_SESSION['suserid']!=$User['ID'])
                            {
                                $row;
                                if($row = checkFriendRequest($con,$_SESSION['suserid'],$User['ID']))
                                {
                                  $row = checkFriendRequest($con,$_SESSION['suserid'],$User['ID']); 
                                  if($row!==false && strcmp($row['FRstatus'],'pending')!=0 && strcmp($row['FRstatus'],'accepted')!=0)
                                  {
                                  echo "
                                    <form action='includephp/profile.inc.php' method='POST'>
                                    <input class= 'btn btn-outline-primary' type='submit' name='addfriend' value='Add Friend'>
                                    <input type='hidden' name='currentU' value='$_SESSION[suserid]'>
                                    <input type='hidden' name='targetU' value='$User[ID]'>
                                    <input type='hidden' name='url' value='name=".$User['Name']."&token=".$$User['Token']."'>
                                    <input type='hidden' name='currentUE' value='$_SESSION[semail]'>
                                    </form>
                                    <br>
                                    ";
                                  }
                                  else if(strcmp($row['FRstatus'],'pending')==0)
                                  {
                                    echo "<button class= 'btn btn-outline-primary' disabled>Pending</button><br>";
                                    
                                  }
                                  else
                                  {
                                    echo "<p>You are friends with $User[Name]</p>";
                                  }
                                }
                                else
                                {
                                  echo "
                                    <form action='includephp/profile.inc.php' method='POST'>
                                    <input class= 'btn btn-outline-primary' type='submit' name='addfriend' value='Add Friend'>
                                    <input type='hidden' name='currentU' value='$_SESSION[suserid]'>
                                    <input type='hidden' name='targetU' value='$User[ID]'>
                                    <input type='hidden' name='url' value='name=".$User['Name']."&token=".$User['Token']."'>
                                    <input type='hidden' name='currentUE' value='$_SESSION[semail]'>
                                    </form>
                                    <br>
                                    ";
                                } 
                            }
                            if(isset($_SESSION['semail']) && isset($_GET['token'])==NULL)
                            {
                                echo "<a href='dashboard2.php'><button class='btn btn-outline-primary' type='button' >Dashboard</button></a>";
                            }
                        ?>
                        </div>
                    </div>
                    </div>
                </div>

                </div>
                <div class='col-md-8'>
                <div class='card mb-3'>
                    <div class='card-body'>
                    <div class='row'>
                        <div class='col-sm-3'>
                        <h6 class='mb-0'>Full Name</h6>
                        </div>
                        <div class='col-sm-9 text-secondary'><?php echo $User['Name']; ?></div>
                    </div>
                    <hr>
                    <div class='row'>
                        <div class='col-sm-3'>
                        <h6 class='mb-0'>Email</h6>
                        </div>
                        <div class='col-sm-9 text-secondary'><?php echo $User['Email']; ?></div>
                    </div>
                    <hr>
                    <div class='row'>
                        <div class='col-sm-3'>
                        <h6 class='mb-0'>Organisation</h6>
                        </div>
                        <div class='col-sm-9 text-secondary'><?php echo $UOrgResult; ?></div>
                    </div>
                    <hr>
                    <div class='row'>
                        <div class='col-sm-3'>
                        <h6 class='mb-0'>Department</h6>
                        </div>
                        <div class='col-sm-9 text-secondary'><?php echo $UDepResult;  ?> </div>
                    </div>
                    <hr>
                    <div class='row'>
                        <div class='col-sm-3'>
                        <h6 class='mb-0'>Occupation</h6>
                        </div>
                        <div class='col-sm-9 text-secondary'><?php echo $UPro['Occupation']; ?></div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
</section>
<!--Research Section-->
<section>
<div class='container'>
    <h1>Researches</h1>
    <?php
          $sql = "SELECT * FROM research WHERE rcreator = $User[ID] ORDER BY rcdate DESC;";
          $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
          
          //Condition to prepare the stmt variable if successful carrys on if not show fail message.
          if(!mysqli_stmt_prepare($stmt,$sql))
          {
              header("location: enhancedsearch-results.php?error=stmtfailed");
              exit();
          }

          mysqli_stmt_execute($stmt);
          
          $result = mysqli_stmt_get_result($stmt);

          if($numrows = mysqli_num_rows($result) >0)
          {
                while($row = mysqli_fetch_assoc($result))
                {

                    echo" 
                        <!--Article List1 -->
                        <div class='card mt-5 border-5 pt-2 active pb-0 px-3'>
                            <div class='card-body '>
                                <div class='row'>
                                    <div class='col-12 '>
                                        <h4 class='card-title '><a href='detailedresearch.php?ID=$row[rid]'><b>$row[rtitle]</b></a></h4>
                                    </div>
                                    <div class='col'>
                                        <h6 class='card-subtitle mb-2 text-muted'>
                                            <p class='card-text text-muted small '>Created by<span class='font-weight-bold'> $User[Name]</span></p>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ";
                }
            }
    ?>
     
 </div>
</section>


<!--Script for scroll down-->
<script>
    const body = document.querySelector('body');
    const navbar = document.querySelector('.navbar');
    const menuBtn = document.querySelector('.menu-btn');
    const cancelBtn = document.querySelector('.cancel-btn');
    menuBtn.onclick = ()=>{
      navbar.classList.add('show');
      menuBtn.classList.add('hide');
      body.classList.add('disabled');
    }
    cancelBtn.onclick = ()=>{
      body.classList.remove('disabled');
      navbar.classList.remove('show');
      menuBtn.classList.remove('hide');
    }
    window.onscroll = ()=>{
      this.scrollY > 20 ? navbar.classList.add('sticky') : navbar.classList.remove('sticky');
    }
    </script>
  <!--End of scroll-->
        <script>
        var navLinks = document.getElementById('navLinks');

        function showMenu(){
            navLinks.style.right = '0';
        }
        function hideMenu(){
            navLinks.style.right = '-200px';
        }    
    </script>
        
    
</body>
</html>