<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
 if(isset($_SESSION['semail']))
 {
   $usr_id =$_SESSION['suserid'];
 
 }
$connect = new PDO('mysql:host=localhost;dbname=test','root','');

if(isset($_POST["id"]))
{
    $query ="
    UPDATE events 
    SET title=:title, start_event=:start_event, end_event=:end_event 
    WHERE id=:id
    ";

    $statement = $connect->prepare($query);
    $statement->execute(
        array(
            ':title'        => $_POST['title'],
            ':start_event'  => $_POST['start'],
            ':end_event'    => $_POST['end'],
            ':id'           =>$_POST['id']
        )
        );
}
?>