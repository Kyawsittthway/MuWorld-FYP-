<?php

    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php'; 

    if(!isset($_SESSION['semail']))
    {
        header('location: index.php');
        exit();
    }
    
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mu World Website</title>
    
    <!-- CSS FILES -->
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 
    <link rel='stylesheet' href='CSS/test.css'> 
    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <!-- Javascripts -->

    <!-- ajax script for dynamic webpage -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <!-- Select2 script for form multiple options -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- custom-file-input script for file name to show up -->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>

</head>
<body>
    
    <?php
        if(isset($_SESSION['semail']))
        {
            $User = userIDExists($con,$_SESSION['suserid']);
            $UPro = profileExistsID($con,$_SESSION['suserid']);
        }
    ?>

    <section class='prof-sect'>
        <div class='container'>
            <div class='main-body'>
                <div class='row gutters-sm'>
                    <div class='col-md-4 mb-3'>
                    <div class='card'>
                        <div class='card-body'>
                        <div class='d-flex flex-column align-items-center text-center'>
                            <a href='profile.php'><button class='btn btn-outline-primary fas fa-step-backward'></button></a>
                            <br>
                            <img src=<?php echo "img/$UPro[ProfilePicture]" ?> onerror="this.src='img/beard.png'" class='rounded-circle' width='150'>
                            <div class='mt-3'>
                            <h4><?php echo $User['Name'] ?></h4>
                            <p class='text-secondary mb-1'><?php echo $UPro['Occupation'] ?></p>
                            <!-- SKILL SECTION -->
                            <?php
                            $sql = "SELECT * FROM skillsuser WHERE SUuid = $User[ID];";
                            $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                
                                //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                if(!mysqli_stmt_prepare($stmt,$sql))
                                {
                                    header("location: profile.php?error=stmtfailed");
                                    exit();
                                }
                                
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);
                                if($numrows = mysqli_num_rows($result) >0)
                                {
                                  echo "<p class='text-muted font-size-sm'><span style='color:black;font-size:20px;'><b>Talents</b></span><br>";
                                  while($row = mysqli_fetch_assoc($result))
                                  {
                                    $skill = checkSkillExistsID($con,$row['SUsid']);
                                    echo "$skill[sname]<br>";
                                  }
                                  echo "</p>";
                                }
                            ?>
                            <!-- END OF SKILL SECTION -->
                            </div>
                        </div>
                        </div>
                    </div>

                </div>
                    <div class='col-md-8'>
                    <div class='card mb-3'>
                        <div class='card-body'>
                        <!-- CARD BODY -->
                        <form action="includephp/editprofile.inc.php" method="POST" enctype="multipart/form-data">
                        <div class="card-body">
                                <!-- Input section 1 -->
                                <div class="form-group">
                                <label>Organisation</label>
                                <select class="js-example-responsive" name="orgtext" style="width: 100%;">
                                    <option selected disabled hidden>Select a organisation</option>
                                    <?php
                                        //SQL statement for database, might be subjected to change!!**
                                        $sql = "SELECT * FROM `organisations`;";
                                        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                        
                                        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                        if(!mysqli_stmt_prepare($stmt,$sql))
                                        {
                                            header("location: ../editprofile.php?error=stmtfailed");
                                            exit();
                                        }

                                        mysqli_stmt_execute($stmt);

                                        $resultData = mysqli_stmt_get_result($stmt);

                                        //Condition to check if data exists in the database matches with input.
                                        if($numofrow = mysqli_num_rows($resultData)>0)
                                        {
                                            while($row = mysqli_fetch_assoc($resultData))
                                            {
                                            echo "<option>$row[orgname]</option>";
                                            }
                                        }
                                        else
                                        {
                                            echo "<option>No options currently</option>";
                                        }
                                        mysqli_stmt_close($stmt);
                                        ?>
                                </select>
                                </div>
                                <!-- Input section 2 -->
                                <?php
                                if(isset($UPro['Organisation'])!==false)
                                {
                                echo"
                                <div class='form-group'>
                                <label>Department</label>
                                <select class='js-example-responsive' name='depart' style='width: 100%;'>
                                <option selected disabled hidden>Select a department</option>
                                    ";
                                        //SQL statement for database, might be subjected to change!!**
                                        $sql = "SELECT * FROM `orgdep` WHERE ODorgid = '$UPro[Organisation]';";
                                        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                        
                                        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                        if(!mysqli_stmt_prepare($stmt,$sql))
                                        {
                                            header("location: ../editprofile.php?error=stmtfailed");
                                            exit();
                                        }

                                        mysqli_stmt_execute($stmt);

                                        $resultData = mysqli_stmt_get_result($stmt);

                                        //Condition to check if data exists in the database matches with input.
                                        if($numofrow = mysqli_num_rows($resultData)>0)
                                        {
                                            while($row = mysqli_fetch_assoc($resultData))
                                            {
                                                $dep = checkDepID($con,$row['ODDid']);
                                            echo "<option>$dep[Dname]</option>";
                                            }
                                        }
                                        else
                                        {
                                            echo "<option>No options currently</option>";
                                        }
                                        mysqli_stmt_close($stmt);
                                            
                                echo "
                                      </select>
                                      </div>
                                     ";
                                }
                                ?>
                                <!-- Input section 3 -->
                                <div class="form-group">
                                <label>Location</label>
                                <select class="js-example-responsive" name="loctext" style="width: 100%;">
                                    <option selected disabled hidden>Select a location</option>
                                    <?php
                                        //SQL statement for database, might be subjected to change!!**
                                        $sql = "SELECT * FROM `locations`;";
                                        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                        
                                        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                        if(!mysqli_stmt_prepare($stmt,$sql))
                                        {
                                            header("location: ../editprofile.php?error=stmtfailed");
                                            exit();
                                        }

                                        mysqli_stmt_execute($stmt);

                                        $resultData = mysqli_stmt_get_result($stmt);

                                        //Condition to check if data exists in the database matches with input.
                                        if($numofrow = mysqli_num_rows($resultData)>0)
                                        {
                                            while($row = mysqli_fetch_assoc($resultData))
                                            {
                                            echo "<option>$row[Lname]</option>";
                                            }
                                        }
                                        else
                                        {
                                            echo "<option>No options currently</option>";
                                        }
                                        mysqli_stmt_close($stmt);
                                        ?>
                                </select>
                                </div>
                            <!-- Input section 4 -->
                            <div class="form-group">
                                <label>Occupation</label>
                                <select class="js-example-responsive" name="occtext" style="width: 100%;">
                                    <option selected disabled hidden>Select an occupation</option>
                                    <?php
                                        //SQL statement for database, might be subjected to change!!**
                                        $sql = "SELECT * FROM `occupations`;";
                                        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                        
                                        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                        if(!mysqli_stmt_prepare($stmt,$sql))
                                        {
                                            header("location: ../editprofile.php?error=stmtfailed");
                                            exit();
                                        }

                                        mysqli_stmt_execute($stmt);

                                        $resultData = mysqli_stmt_get_result($stmt);

                                        //Condition to check if data exists in the database matches with input.
                                        if($numofrow = mysqli_num_rows($resultData)>0)
                                        {
                                            while($row = mysqli_fetch_assoc($resultData))
                                            {
                                            echo "<option>$row[Oname]</option>";
                                            }
                                        }
                                        else
                                        {
                                            echo "<option>No options currently</option>";
                                        }
                                        mysqli_stmt_close($stmt);
                                        ?>
                                </select>
                                </div>
                                <!-- Input section 5 -->
                            <div class="form-group">
                                <label>Profile Picture</label>
                                <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="exampleInputFile" name="profilepic">
                                    <label class="custom-file-label" for="exampleInputFile" >Choose File</label>
                                </div>
                                <div class="input-group-append">
                                    <button type="submit" class="input-group-text">Upload</button>
                                </div>
                                </div>
                            </div>
                            <!-- Input section 6 -->
                            <div class='form-group'>
                                <label>Skills</label>
                                <select class="js-example-responsive" multiple='multiple' name='selectskills[]'
                                                data-placeholder='Any' style='width: 100%;'>
                                    <?php
                                        //SQL statement for database, might be subjected to change!!**
                                        $sql = "SELECT * FROM `skills`;";
                                        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                                        
                                        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                                        if(!mysqli_stmt_prepare($stmt,$sql))
                                        {
                                            header("location: ../editprofile.php?error=stmtfailed");
                                            exit();
                                        }

                                        mysqli_stmt_execute($stmt);

                                        $resultData = mysqli_stmt_get_result($stmt);

                                        //Condition to check if data exists in the database matches with input.
                                        if($numofrow = mysqli_num_rows($resultData)>0)
                                        {
                                        while($row = mysqli_fetch_assoc($resultData))
                                        {
                                            echo "<option>$row[sname]</option>";
                                        }
                                        }
                                        else
                                        {
                                        echo "<option>No options currently</option>";
                                        }
                                        mysqli_stmt_close($stmt);
                                    ?>
                                </select>
                            </div>
                            <!-- error handling -->
                            <?php
                                    if(isset($_GET["error"]))
                                    {
                                    if($_GET["error"] == "noinput")
                                    {
                                        echo "<p style='color:red'> No inputs were made!</p>";
                                    }
                                    else if($_GET["error"] == "none")
                                    {
                                        echo "<p style='color:green'> Successfully Updated!!</p>";
                                    }
                                    }
                                ?>
                        </div>
                        <!-- /.card-body -->
                            <div class="card-footer">
                                <input type='hidden' value='<?php echo $User['ID']?>' name='uID'>
                                <button type="submit" class="btn btn-primary" name="pSubmit">Submit</button>
                            </div>
                        </form>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
    </section>
    
    
    <!-- IMPORTANT!! WITHOUT THIS SCRIPT YOU WILL NOT BE ABLE TO SELECT MULTIPLE OPTIONS FOR SKILLS -->
    <script>
    $(".js-example-responsive").select2(
    {
         width: 'resolve' // need to override the changed default
    });
    </script>

    <!-- Script to show text of file. -->
    <script>
    $(function () {
    bsCustomFileInput.init();
    });
    </script>

</body>
</html>