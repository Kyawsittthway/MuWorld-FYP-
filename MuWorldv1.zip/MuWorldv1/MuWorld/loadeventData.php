<?php  
 //load_data.php     
      session_start();
      include_once 'includephp/dbh.inc.php';
      include_once 'includephp/functions.inc.php';
   if(isset($_SESSION['semail']))
   {
     $usr_id =$_SESSION['suserid'];
   
   } 
 $connect = mysqli_connect("localhost", "root", "", "test");  
 $output = '';  
 if(isset($_POST["id"]))  
 {  
      if($_POST["id"] != '')  
      {  
           $sql = "SELECT * FROM admin_event WHERE id = '".$_POST["id"]."'";  
      }  
      else  
      {  
           $sql = "SELECT * FROM admin_event";  
      }  
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '<div class="col-md-12"><div style="border:1px solid #ccc; padding:10px; margin-bottom:20px;text-align:center;margin-left:auto;margin-right:auto;"><p1>Start Time: '.$row["admin_start"].'</p1><br><p1>End Time: '.$row["admin_end"].'</p1></div></div>';  
      }  
      echo $output;  
 }  
 ?>