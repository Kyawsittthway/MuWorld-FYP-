<?php 
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
    <!-- CSS FILES -->
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 
    <link rel='stylesheet' href='CSS/test.css'> 
    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <!-- Javascripts -->

    <!-- ajax script for dynamic webpage -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <!-- Select2 script for form multiple options -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- custom-file-input script for file name to show up -->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
</head>
<body>
    <!--Research Section-->
    <div class='container'>
    <h1>Create Organisation</h1>
            <a href='allorg.php'><button class='btn btn-primary fas fa-step-backward'></button></a>
        <div class='card-body'>
                <form action="includephp/createorg.inc.php" method="POST" enctype="multipart/form-data">
                      <div class="card-body">
                            <!-- Input section 1 -->
                            <div class="form-group">
                              <label>Organisation Name</label>
                              <input type="text" class="form-control" name="orgname" placeholder="">
                            </div>
                            <!-- Input section 2 -->
                            <div class="form-group">
                              <label>Email</label>
                              <input type="email" class="form-control" name="orgemail" placeholder="">
                            </div>
                            <!-- Input section 3 -->
                            <div class="form-group">
                              <label>Contact No.</label>
                              <input type="text" class="form-control" name="orgtel" pattern="\+[0-9]{2} [0-9]{4} [0-9]{4}" placeholder="Please enter in this format: +65 9432 1432">
                            </div>
                            <!-- Input section 4 -->
                            <div class="form-group">
                              <label>Address</label>
                              <input type="text" class="form-control" name="orgadd" placeholder="">
                            </div>
                            <!-- Input section 5 -->
                            <div class="form-group">
                              <label>Web page</label>
                              <input type="url" class="form-control" name="orgweb" placeholder="">
                            </div>
                             <!-- Input section 6 -->
                             <div class="form-group">
                              <label for='orgindustry'>Industry</label>
                              <input type="text" class="form-control" name="orgindustry" placeholder="">
                            </div>
                            <?php
                                if(isset($_GET["error"]))
                                {
                                    if($_GET["error"] == "noinput")
                                    {
                                        echo "<p style='color:red'> Fill in all fields!!</p>";
                                    }
                                    else if($_GET["error"] == "oe")
                                    {
                                        echo "<p style='color:red'> Organisation already exists!</p>"; 
                                    }
                                    else if($_GET["error"] == "none")
                                    {
                                        echo "<p style='color:green'> Successfully created a an organisation!!</p>";
                                    }
                                }
                            ?>
                      </div>
                      
                      <!-- Input section hidden -->
                      <input type='hidden' name='uemail' value="<?php echo $_SESSION['semail'];?>"/>
                      <!-- /.card-body -->
                          <div class="card-footer">
                            <button type="submit" class="btn btn-primary" name="oSubmit">Submit</button>
                          </div>
                          <!-- Input section 6 -->
                </form>
                </div>
    </div>
</body>
</html>