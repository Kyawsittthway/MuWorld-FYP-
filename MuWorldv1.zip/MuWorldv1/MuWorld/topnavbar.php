<?php
    if(isset($_SESSION['semail']))
    {
     
        echo "
            <nav class='navbar' style='background:crimson; padding:0px;position:fixed;height:70px;'>
            <a href='index.php'><img src='img/red_2.png'></a>
            <a href='https://www.murdoch.edu.au/'><img src='img/mu1.png' style='width:110px;height:70px;margin-bottom:10px;'></a>
                <div class='nav-links' id='navLinks' style='color: red;'>
                    <i class='fa fa-times' onclick='hideMenu()'></i>
                    <ul>
                    <li><a href='profile.php'>$_SESSION[sfullname]</a></li>
             ";
              
            include_once 'notifications.php';
            
        echo "
                        <li style=''>  
                            <form class='form-inline ml-3' action='includephp/search.inc.php' method='POST'>
                                <div class='input-group input-group-sm'>
                                <input class='form-control form-control-navbar' type='search' placeholder='Search' aria-label='Search' name='searchinput'>
                                <div class='input-group-append'>
                                    <button class='btn btn-navbar' type='submit' name='subsearch'>
                                    <i class='fas fa-search'></i>
                                    </button>
                                    <input type='hidden' name='location' value='index.php'>
                                </div>
                                </div>
                            </form>
                        </li>
                        <li><a href='index.php'>HOME</a></li>
                        <li><a href='about.php'>ABOUT</a></li>
             ";
        
        
            if($_SESSION['suserid'] == 1)
            {
                echo "<li><a href='adminCalendar.php'>EVENTS</a></li>";
            }
            else
            {
            
                echo "<li><a href='publicEvent.php'>EVENTS</a></li>";
            }
        
        
  
 

        echo "      
                        <li><a href='dashboard2.php'>DASHBOARD</a></li>
                        <li><a href='includephp/logout.inc.php'>LOGOUT</a></li>
                    </ul>
                </div>
                <i class='fa fa-bars' onclick='showMenu()'></i>
            </nav>       
             ";
    }
    else
    {
        echo "
            <nav class='navbar' style='background:crimson; padding:0px;position:fixed;height:70px;'>
            <a href='index.php'><img src='img/red_2.png'></a> 
            <a href='https://www.murdoch.edu.au/'><img src='img/mu1.png' style='width:110px;height:70px;margin-bottom:10px;'></a>
                <div class='nav-links' id='navLinks' style='color: red;'>
                    <i class='fa fa-times' onclick='hideMenu()'></i>
                    <ul>
                        <li>  
                            <form class='form-inline ml-3' action='includephp/search.inc.php' method='POST'>
                                <div class='input-group input-group-sm'>
                                <input class='form-control form-control-navbar' type='search' placeholder='Search' aria-label='Search' name='searchinput'>
                                <div class='input-group-append'>
                                    <button class='btn btn-navbar' type='submit' name='subsearch'>
                                    <i class='fas fa-search'></i>
                                    </button>
                                    <input type='hidden' name='location' value='index.php'>
                                </div>
                                </div>
                            </form>
                        </li>
                        <li><a href='index.php'>HOME</a></li>
                        <li><a href='about.php'>ABOUT</a></li>
                        <li><a href='publicEvent.php'>EVENTS</a></li>
                        <li><a href='register.php'>REGISTER</a></li>
                        <li><a href='login.php'>LOGIN</a></li>
                    </ul>
                </div>
                <i class='fa fa-bars' onclick='showMenu()'></i>
            </nav>       
             ";
    }
?>