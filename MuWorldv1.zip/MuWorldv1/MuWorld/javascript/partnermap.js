
var map = L.map('map',{
  center: [5,28],
  zoom:2,
  minZoom:2,
  maxZoom:16
});

L.tileLayer('https://api.maptiler.com/maps/outdoor/{z}/{x}/{y}@2x.png?key=Ki6nVgPxgp0EsIBJoBLy', {
  attribution: '<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>',
}).addTo(map);


var partnerMap = [
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Kaplan Singapore",
        "BusType": "global",
        "Description": "Murdoch University Singapore Partner.",
        "Address": "8 Wilkie Rd, #02-01 ATO, Singapore 228095"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          103.8496881723404,
          1.302030660568302
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Perron Institute",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.8130794,
          -31.9680376
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Sarepta Therapeutics",
        "BusType": "global",
        "Description": "Murdoch University United States Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -71.07921600341797,
          42.364315032958984
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Harry Perkins Institute of Medical Research",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.81378936767578,
          -31.968111038208008
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Chevron – The Harry Butler Institute",
        "BusType": "global",
        "Description": "Murdoch University United States Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -121.9594581,
          37.7583351
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Peel-Harvey Catchment Council",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.7382191,
          -32.5098252
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Bunbury Dolphin Discovery Centre",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.6434708,
          -33.3199116
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Commonwealth Department of Infrastructure",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          149.1294755,
          -35.278417
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Regional Development",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          149.1293,
          -35.2813
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Phosphates Resources Limited",
        "BusType": "global",
        "Description": "Murdoch University Christmas Island Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          105.6731971,
          -10.4251577
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Western Barley Genetics Alliance",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.8851714,
          -31.9884265
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Peel Development Commission",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.7202908,
          -32.5319166
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "The University of Western Australia",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.7979004,
          -31.9504045
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Curtin university",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.8928644,
          -32.0057415
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Curtin university",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.8691215,
          -31.9192816
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Pawsey Supercomputing Centre",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.8834581,
          -31.9931649
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "RAC Arena",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.85944366455078,
          -31.951677322387695
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "WACA",
        "BusType": "global",
        "Description": "Murdoch University Australia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          115.8795043,
          -31.959846
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Home Resources Development Fund",
        "BusType": "global",
        "Description": "Murdoch University Malaysia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          101.6673,
          3.1466
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "K-Pintar Sdn Bhd",
        "BusType": "global",
        "Description": "Murdoch University Malaysia Partner."
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          101.6757,
          3.1185
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Universität f. Bodenkultur Wien",
        "BusType": "global",
        "Description": "University of Natural Resources and Life Sciences partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          16.3690911,
          48.2527457
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "MCI | The Entrepreneurial School®",
        "BusType": "global",
        "Description": "MCI Management Centre Innsbruck partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          11.3986773,
          47.269275
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University in Puch bei Hallein",
        "BusType": "global",
        "Description": "Salzburg University of Applied Sciences partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          13.086338,
          47.724121
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Mount Royal University",
        "BusType": "global",
        "Description": "Canada University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -114.13231658935547,
          51.00950622558594
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Simon Fraser University",
        "BusType": "global",
        "Description": "Canada University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -122.903839,
          49.279113
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Victoria",
        "BusType": "global",
        "Description": "Canada University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -123.303686,
          48.464326
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Waterloo",
        "BusType": "global",
        "Description": "Canada University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -80.53893280029297,
          43.46920394897461
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Communication University of Zhejiang",
        "BusType": "global",
        "Description": "China University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          120.35351038021167,
          30.423328587932932
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Zhejiang University of Technology",
        "BusType": "global",
        "Description": "China University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          120.03908916715108,
          30.226037007551252
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Zagreb",
        "BusType": "global",
        "Description": "Croatia University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          15.970408924572492,
          45.8112948826838
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Anglo-American University",
        "BusType": "global",
        "Description": "Czechia University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          14.409109830681503,
          50.090688106374685
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Danish School of Media and Journalism",
        "BusType": "global",
        "Description": "Denmark University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          10.190342728200095,
          56.175490408778195
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Southern Denmark",
        "BusType": "global",
        "Description": "Denmark University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          10.427427659370114,
          55.37130358251361
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Turku",
        "BusType": "global",
        "Description": "Finland University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          22.291594016474598,
          60.452555831215406
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Bremen University of Applied Sciences",
        "BusType": "global",
        "Description": "Germany University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          8.793733569318496,
          53.073215527720635
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Bremen University of Applied Sciences",
        "BusType": "global",
        "Description": "Germany University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          8.793733569318496,
          53.073215527720635
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Hamburg University of Applied Sciences",
        "BusType": "global",
        "Description": "Germany University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          10.022292276703762,
          53.55721548653281
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Munich University of Applied Science",
        "BusType": "global",
        "Description": "Germany University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          11.552835298027958,
          48.153707024966835
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Ostfalia University of Applied Science",
        "BusType": "global",
        "Description": "Germany University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          10.548910192044517,
          52.177504157172066
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Oldenburg",
        "BusType": "global",
        "Description": "Germany University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          8.182866507955483,
          53.14744112325332
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "City University Hong Kong",
        "BusType": "global",
        "Description": "HongKong University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          114.17246631534076,
          22.337612135483557
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Hong Kong",
        "BusType": "global",
        "Description": "HongKong University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          114.13695605397776,
          22.283932094177562
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "O.P. Jindal Global University",
        "BusType": "global",
        "Description": "India University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          77.05653398465924,
          28.927373508591206
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Griffith College",
        "BusType": "global",
        "Description": "Ireland University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -6.277919211136234,
          53.332055480798395
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Limerick",
        "BusType": "global",
        "Description": "Ireland University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -8.572425021519138,
          52.673734083561506
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "University of Bologna",
        "BusType": "global",
        "Description": "Italy University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          11.356494771870045,
          44.60139185127737
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Hokkaido University",
        "BusType": "global",
        "Description": "Japan University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          141.34002372692305,
          43.0780201720032
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Konkuk University",
        "BusType": "global",
        "Description": "Korea University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          127.07938571303005,
          37.54101343909534
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Utrecht University of Applied Sciences",
        "BusType": "global",
        "Description": "Netherlands University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          5.167877855840037,
          52.08460671172734
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "CEU San Pablo University",
        "BusType": "global",
        "Description": "Spain University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -3.717598113873017,
          40.442567679039854
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Linnaeus University",
        "BusType": "global",
        "Description": "Sweden University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          14.830270476401038,
          56.855373681804714
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Lucerne University of Applied Sciences",
        "BusType": "global",
        "Description": "Switzerland University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          8.314944184495129,
          47.04687471110781
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "Aberystwyth University",
        "BusType": "global",
        "Description": "United Kingdom University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -4.063819828806818,
          52.417716129394705
        ]
      }
    },
    {
      "type": "Feature",
      "properties": {
        "marker-color": "#66b8ff",
        "marker-size": "small",
        "marker-symbol": "star",
        "Name": "California State University Monterey Bay",
        "BusType": "global",
        "Description": "United States University partner with Murdoch University"
      },
      "geometry": {
        "type": "Point",
        "coordinates": [
          -121.79787360418221,
          36.65156440089918
        ]
      }
    }
  ];


function onEachFeature(feature, layer) {


  var partnername = feature.properties.Name;


  if (feature.properties.Name) {
    layer.bindPopup(partnername + "<br>" + feature.properties.Description);
  }

}

L.geoJSON(partnerMap, {
  onEachFeature: onEachFeature
}).addTo(map);

var layerGroup = L.layerGroup().addTo(map);

//All partners
function testFunction0(feature, layer){
  layerGroup.clearLayers();
  map.setView([5,28], 2);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Kaplan Singapore
function testFunction(feature, layer){
  layerGroup.clearLayers();
  map.setView([1.302060, 103.849080], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Perron Institute
function testFunction1(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.9680376, 115.8130794], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Sarepta Therapeutics
function testFunction2(feature, layer){
  layerGroup.clearLayers();
  map.setView([42.364315032958984, -71.07921600341797], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Harry Perkins Institute of Medical Research
function testFunction3(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.968111038208008, 115.81378936767578], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Chevron – The Harry Butler Institute
function testFunction4(feature, layer){
  layerGroup.clearLayers();
  map.setView([37.7583351, -121.9594581], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Peel-Harvey Catchment Council
function testFunction5(feature, layer){
  layerGroup.clearLayers();
  map.setView([-32.5098252, 115.7382191], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Bunbury Dolphin Discovery Centre
function testFunction6(feature, layer){
  layerGroup.clearLayers();
  map.setView([-33.3199116, 115.6434708], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Commonwealth Department of Infrastructure
function testFunction7(feature, layer){
  layerGroup.clearLayers();
  map.setView([-35.278417, 149.1294755], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Regional Development
function testFunction8(feature, layer){
  layerGroup.clearLayers();
  map.setView([-35.2813, 149.1293], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Phosphates Resources Limited
function testFunction9(feature, layer){
  layerGroup.clearLayers();
  map.setView([-10.4251577, 105.6731971], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Western Barley Genetics Alliance
function testFunction10(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.9884265, 115.8851714], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Peel Development Commission
function testFunction11(feature, layer){
  layerGroup.clearLayers();
  map.setView([-32.5319166, 115.7202908], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//The University of Western Australia
function testFunction12(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.9504045, 115.7979004], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Curtin university
function testFunction13(feature, layer){
  layerGroup.clearLayers();
  map.setView([-32.0057415, 115.8928644], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Edith Cowan University
function testFunction14(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.9192816, 115.8691215], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Pawsey Supercomputing Centre
function testFunction15(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.9931649, 115.8834581], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//RAC Arena
function testFunction16(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.951677322387695, 115.85944366455078], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//WACA
function testFunction17(feature, layer){
  layerGroup.clearLayers();
  map.setView([-31.959846, 115.8795043], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Home Resources Development Fund
function testFunction18(feature, layer){
  layerGroup.clearLayers();
  map.setView([3.1466, 101.6673], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//K-Pintar Sdn Bhd
function testFunction19(feature, layer){
  layerGroup.clearLayers();
  map.setView([3.1185, 101.6757], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Universität f. Bodenkultur Wien
function testFunction20(feature, layer){
  layerGroup.clearLayers();
  map.setView([48.2527457, 16.3690911], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//MCI | The Entrepreneurial School®
function testFunction21(feature, layer){
  layerGroup.clearLayers();
  map.setView([47.269275, 11.3986773], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University in Puch bei Hallein
function testFunction22(feature, layer){
  layerGroup.clearLayers();
  map.setView([47.724121, 13.086338], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Mount Royal University
function testFunction23(feature, layer){
  layerGroup.clearLayers();
  map.setView([51.00950622558594, -114.13231658935547], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Simon Fraser University
function testFunction24(feature, layer){
  layerGroup.clearLayers();
  map.setView([49.279113, -122.903839], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Victoria
function testFunction25(feature, layer){
  layerGroup.clearLayers();
  map.setView([48.464326, -123.303686], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Waterloo
function testFunction26(feature, layer){
  layerGroup.clearLayers();
  map.setView([43.46920394897461, -80.53893280029297], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Communication University of Zhejiang
function testFunction27(feature, layer){
  layerGroup.clearLayers();
  map.setView([30.423328587932932, 120.35351038021167], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Zhejiang University of Technology
function testFunction28(feature, layer){
  layerGroup.clearLayers();
  map.setView([30.226037007551252, 120.03908916715108], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Zagreb
function testFunction29(feature, layer){
  layerGroup.clearLayers();
  map.setView([45.8112948826838, 15.970408924572492], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Anglo-American University
function testFunction30(feature, layer){
  layerGroup.clearLayers();
  map.setView([50.090688106374685, 14.409109830681503], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Danish School of Media and Journalism
function testFunction31(feature, layer){
  layerGroup.clearLayers();
  map.setView([56.175490408778195, 10.190342728200095], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Southern Denmark
function testFunction32(feature, layer){
  layerGroup.clearLayers();
  map.setView([55.37130358251361, 10.427427659370114], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Turku
function testFunction33(feature, layer){
  layerGroup.clearLayers();
  map.setView([60.452555831215406, 22.291594016474598], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Bremen University of Applied Sciences
function testFunction34(feature, layer){
  layerGroup.clearLayers();
  map.setView([53.073215527720635, 8.793733569318496], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Hamburg University of Applied Sciences
function testFunction35(feature, layer){
  layerGroup.clearLayers();
  map.setView([53.55721548653281, 10.022292276703762], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Munich University of Applied Science
function testFunction36(feature, layer){
  layerGroup.clearLayers();
  map.setView([48.153707024966835, 11.552835298027958], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Ostfalia University of Applied Science
function testFunction37(feature, layer){
  layerGroup.clearLayers();
  map.setView([52.177504157172066, 10.548910192044517], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Oldenburg
function testFunction38(feature, layer){
  layerGroup.clearLayers();
  map.setView([53.14744112325332, 8.182866507955483], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//City University Hong Kong
function testFunction39(feature, layer){
  layerGroup.clearLayers();
  map.setView([22.337612135483557, 114.17246631534076], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Hong Kong
function testFunction40(feature, layer){
  layerGroup.clearLayers();
  map.setView([22.283932094177562, 114.13695605397776], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//O.P. Jindal Global University
function testFunction41(feature, layer){
  layerGroup.clearLayers();
  map.setView([28.927373508591206, 77.05653398465924], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Griffith College
function testFunction42(feature, layer){
  layerGroup.clearLayers();
  map.setView([53.332055480798395, -6.277919211136234], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Limerick
function testFunction43(feature, layer){
  layerGroup.clearLayers();
  map.setView([52.673734083561506, -8.572425021519138], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//University of Bologna
function testFunction44(feature, layer){
  layerGroup.clearLayers();
  map.setView([44.60139185127737, 11.356494771870045], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Hokkaido University
function testFunction45(feature, layer){
  layerGroup.clearLayers();
  map.setView([43.0780201720032, 141.34002372692305], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Konkuk University
function testFunction46(feature, layer){
  layerGroup.clearLayers();
  map.setView([37.54101343909534, 127.07938571303005], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Utrecht University of Applied Sciences
function testFunction47(feature, layer){
  layerGroup.clearLayers();
  map.setView([52.08460671172734, 5.167877855840037], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//CEU San Pablo University
function testFunction48(feature, layer){
  layerGroup.clearLayers();
  map.setView([40.442567679039854, -3.717598113873017], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Linnaeus University
function testFunction49(feature, layer){
  layerGroup.clearLayers();
  map.setView([56.855373681804714, 14.830270476401038], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Lucerne University of Applied Sciences
function testFunction50(feature, layer){
  layerGroup.clearLayers();
  map.setView([47.04687471110781, 8.314944184495129], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//Aberystwyth University
function testFunction51(feature, layer){
  layerGroup.clearLayers();
  map.setView([52.417716129394705, -4.063819828806818], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}
//California State University Monterey Bay
function testFunction52(feature, layer){
  layerGroup.clearLayers();
  map.setView([36.65156440089918, -121.79787360418221], 18);
  lmarker.bindPopup(partnername + "<br>" + feature.properties.Description).addTo(layerGroup);
}