<?php
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
 if(isset($_SESSION['semail']))
 {
   $usr_id =$_SESSION['suserid'];
 
 }
$connect = new PDO('mysql:host=localhost;dbname=test','root','');

$data = array();

$query = "SELECT * FROM events WHERE user_id=$usr_id;  ";

$statement = $connect->prepare($query);

$statement->execute();
$result = $statement->fetchAll();

foreach($result as $row)
{
    $data[] = array(
        'id'       => $row["id"],
        'title'    => $row["title"],
        'start'    => $row["start_event"],
        'end'      => $row["end_event"],
        'color'    =>$row['event_color'],
        'url'      =>$row['weblink'],
        'borderColor' =>$row['borderColor']
     

    );
    
}
echo json_encode($data);
?>