<?php 
    session_start();
    include_once 'includephp/dbh.inc.php';
    include_once 'includephp/functions.inc.php';
?>

<!DOCTYPE html>
<html>
<head>
    <!-- CSS FILES -->
    <link rel='stylesheet' href='CSS/joshua.css'>
    <link rel='stylesheet' href='CSS/profile.css'> 
    <link rel='stylesheet' href='CSS/test.css'> 
    <link rel='stylesheet' href='CSS/test2.css'>
    <link rel='preconnect' href='https://fonts.gstatic.com'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css'>
    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    
    <!-- Javascripts -->

    <!-- ajax script for dynamic webpage -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    
    <!-- Select2 script for form multiple options -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- custom-file-input script for file name to show up -->
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
</head>
<body>
    <!--Research Section-->
    <section>
    <div class='container'>
        <h1>Researches</h1>
         <!-- Main content -->
    <section class='content'>

<!-- Default box -->
<div class='card'>
  <div class='card-header'>
  <?php
     if(isset($_GET['ID']))
     {
          $rp = checkResearchExistsID($con,$_GET['ID']);
          $rc = userIDExists($con,$rp['rcreator']);
          $rorg;
          if(checkOrgID($con,$rp['rorg'])!==false)
          {
            $org = checkOrgID($con,$rp['rorg']);
            $rorg = $org['orgname'];
          }
          else
          {
            $rorg = " ";
          }

          echo " 
          <a href='dashboard2.php'><button class='btn btn-outline-danger fas fa-step-backward'></button></a>
          <h3 class='card-title'>Project Details</h3>
          
          </div>
          
          <div class='card-body'>
          <div class='row'>
              ";
                  echo "
              <div class='col-12 col-md-12 col-lg-8 order-2 order-md-1'>
                      ";
              /*
              <div class='row'>
                  <!-- Bubbles in case we need them.
                  <div class='col-12 col-sm-4'>
                  <div class='info-box bg-light'>
                      <div class='info-box-content'>
                      <span class='info-box-text text-center text-muted'>Estimated budget</span>
                      <span class='info-box-number text-center text-muted mb-0'>2300</span>
                      </div>
                  </div>
                  </div>
                  <div class='col-12 col-sm-4'>
                  <div class='info-box bg-light'>
                      <div class='info-box-content'>
                      <span class='info-box-text text-center text-muted'>Total amount spent</span>
                      <span class='info-box-number text-center text-muted mb-0'>2000</span>
                      </div>
                  </div>
                  </div>
                  <div class='col-12 col-sm-4'>
                  <div class='info-box bg-light'>
                      <div class='info-box-content'>
                      <span class='info-box-text text-center text-muted'>Estimated project duration</span>
                      <span class='info-box-number text-center text-muted mb-0'>20</span>
                      </div>
                  </div>
                  </div>
                  -->
              </div>
              */
                  echo "
              <div class='row'>
                  <div class='col-12'>
                  <h4>Recent Activity</h4>
                      ";
                      /*
                      <div class='post'>
                      <div class='user-block'>
                          <img class='img-circle img-bordered-sm' src='../../dist/img/user1-128x128.jpg' alt='user image'>
                          <span class='username'>
                          <a href='#'>Jonathan Burke Jr.</a>
                          </span>
                          <span class='description'>Shared publicly - 7:45 PM today</span>
                      </div>
                      <!-- /.user-block -->
                      <p>
                          Lorem ipsum represents a long-held tradition for designers,
                          typographers and the like. Some people hate it and argue for
                          its demise, but others ignore.
                      </p>

                      <p>
                          <a href='#' class='link-black text-sm'><i class='fas fa-link mr-1'></i> Demo File 1 v2</a>
                      </p>
                      </div>

                      <div class='post clearfix'>
                      <div class='user-block'>
                          <img class='img-circle img-bordered-sm' src='../../dist/img/user7-128x128.jpg' alt='User Image'>
                          <span class='username'>
                          <a href='#'>Sarah Ross</a>
                          </span>
                          <span class='description'>Sent you a message - 3 days ago</span>
                      </div>
                      <!-- /.user-block -->
                      <p>
                          Lorem ipsum represents a long-held tradition for designers,
                          typographers and the like. Some people hate it and argue for
                          its demise, but others ignore.
                      </p>
                      <p>
                          <a href='#' class='link-black text-sm'><i class='fas fa-link mr-1'></i> Demo File 2</a>
                      </p>
                      </div>

                      <div class='post'>
                      <div class='user-block'>
                          <img class='img-circle img-bordered-sm' src='../../dist/img/user1-128x128.jpg' alt='user image'>
                          <span class='username'>
                          <a href='#'>Jonathan Burke Jr.</a>
                          </span>
                          <span class='description'>Shared publicly - 5 days ago</span>
                      </div>
                      <!-- /.user-block -->
                      <p>
                          Lorem ipsum represents a long-held tradition for designers,
                          typographers and the like. Some people hate it and argue for
                          its demise, but others ignore.
                      </p>

                      <p>
                          <a href='#' class='link-black text-sm'><i class='fas fa-link mr-1'></i> Demo File 1 v1</a>
                      </p>
                      </div>
                      */
                  echo "    
                  </div>
              </div>
                      ";
                  echo "  
              </div>
                      ";
              
              

              echo "
              <div class='col-12 col-md-12 col-lg-4 order-1 order-md-2'>
              <div class='text-muted'>
                  <p class='text-sm'>
                  Project Title
                  <b class='d-block'>$rp[rtitle]</b>
                  </p>
                  <p class='text-sm'>
                  Project Description
                  <b class='d-block'>$rp[rdescript]</b>
                  </p>
                  <p class='text-sm'>
                  Project Link
                  <b class='d-block'><a href='$rp[rlink]'>$rp[rlink]</a></b>
                  </p>
                  <p class='text-sm'>Client Company
                  <b class='d-block'>$rorg</b>
                  </p>
                  <p class='text-sm'>Project Creator
                  <b class='d-block'>$rc[Name]</b>
                  </p>
                  ";

                   //SQL statement for database, might be subjected to change!!**
                  $sql = "SELECT * FROM researchusers WHERE RUrid = ? ORDER BY RUdate;";
                  $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
                  
                  //Condition to prepare the stmt variable if successful carrys on if not show fail message.
                  if(!mysqli_stmt_prepare($stmt,$sql))
                  {
                      header("location: enhancedsearch-results.php?error=stmtfailed");
                      exit();
                  }

                  mysqli_stmt_bind_param($stmt,"s",$rp['rid']);
                  mysqli_stmt_execute($stmt);
                  $result = mysqli_stmt_get_result($stmt);
                  if($numrows = mysqli_num_rows($result) >0)
                  {
                      echo "<p class='text-sm'>Current Members
                              <ul class='users-list clearfix' style='display:inline;'>
                           ";

                      while($row = mysqli_fetch_assoc($result))
                      {
                          $cuser = userIDExists($con,$row['RUuid']);
                          $cpro = profileExistsID($con,$row['RUuid']);
                          echo "
                              
                                  <li>
                                      <img class='rounded-circle' src='img/$cpro[ProfilePicture]' onerror=this.src='img/beard.png' style='width:50px;height:50px;'>
                                      <span class='users-list-name' style='color:blue;'><br>$row[RUstatus]<br></span>
                                      <a class='users-list-name' href='profile.php?name=".$cuser['Name']."&token=".$cuser['Token']."'>$cuser[Name]<br></a>
                                      <span class='users-list-date'>$row[RUdate]</span>
                                      
                                  </li>
                              
                               ";
                           
                      }
                      echo " </ul>
                          </p>
                           ";
                  }
                
                  mysqli_stmt_close($stmt);

                  if(checkResearchGroup($con,$rp['rid'],$_SESSION['suserid'])===false)
                  {
                      echo "
                      <form action='includephp/detailedresearch.inc.php' method='POST'>
                      <input type='submit' name='joinresearch' value='Join Research' class='btn btn-primary'>
                      <input type='hidden' name='crid' value='$rp[rid]'> <!-- current research id -->
                      <input type='hidden' name='cruid' value='$rp[rcreator]'> <!-- current research user id -->
                      <input type='hidden' name='cuid' value = '$_SESSION[suserid]'>
                      </form>
                          ";
                  }
                  else
                  {
                      echo "
                      <form action='includephp/detailedresearch.inc.php' method='POST'>
                      <input type='submit' name='leaveresearch' value='Leave Research' class='btn btn-danger'>
                      <input type='hidden' name='crid' value='$rp[rid]'> <!-- current research id -->
                      <input type='hidden' name='cruid' value='$rp[rcreator]'> <!-- current research user id -->
                      <input type='hidden' name='cuid' value = '$_SESSION[suserid]'>
                      </form>
                          ";
                  }
              echo "    
              </div>
                  
              
              <!--
              <h5 class='mt-5 text-muted'>Project files</h5>
              <ul class='list-unstyled'>
                  <li>
                  <a href='' class='btn-link text-secondary'><i class='far fa-fw fa-file-word'></i> Functional-requirements.docx</a>
                  </li>
                  <li>
                  <a href='' class='btn-link text-secondary'><i class='far fa-fw fa-file-pdf'></i> UAT.pdf</a>
                  </li>
                  <li>
                  <a href='' class='btn-link text-secondary'><i class='far fa-fw fa-envelope'></i> Email-from-flatbal.mln</a>
                  </li>
                  <li>
                  <a href='' class='btn-link text-secondary'><i class='far fa-fw fa-image '></i> Logo.png</a>
                  </li>
                  <li>
                  <a href='' class='btn-link text-secondary'><i class='far fa-fw fa-file-word'></i> Contract-10_12_2014.docx</a>
                  </li>
              </ul>
              <div class='text-center mt-5 mb-3'>
                  <a href='#' class='btn btn-sm btn-primary'>Add files</a>
                  <a href='#' class='btn btn-sm btn-warning'>Report contact</a>
              </div>
              -->
              </div>
          </div>
          </div>
          <!-- /.card-body -->
          ";
      }
      else
      {
          echo "
              <a href='dashboard2.php'><button class='btn btn-outline-danger fas fa-step-backward' style='margin-bottom:10px;'></button></a>
              <div class ='list-group-item'>
              <h5>Research project no longer exists due to the only admin in the project leaving.</h5>
              </div>
              ";
      }
  ?>
</div>
<!-- /.card -->
    <?php
    if(isset($_GET['ID']))
    {
        echo "
        <div class='card-footer'>
            
            <form action='includephp/detailedresearch.inc.php' method='POST' style='width:100%;display:flex;'>
            <div class='input-group input-group-sm'>    
                <input class='form-control' type='text' placeholder='Type a comment' name='commentdata'>
                <input type='hidden' name='UID' value='$_SESSION[suserid]'>
                <input type='hidden' name='RID' value='$_GET[ID]'>
                <div class='input-group-append'>
                    <button class='btn btn-sm btn-primary' type='submit' name='commentsub'>Submit</button>
                </div>
            </div>
            </form>
        </div>
            ";
    
        if(checkComRes($con,$_GET['ID'])!==false)
        {
            
            $sql = "SELECT * FROM comres WHERE CRrid = '$_GET[ID]' ORDER BY CRdate DESC;";
            $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.

            //Condition to prepare the stmt variable if successful carrys on if not show fail message.
            if(!mysqli_stmt_prepare($stmt,$sql))
            {
                throw new exception("STMT failed");
                exit();
            }

            mysqli_stmt_execute($stmt);
            
            $result = mysqli_stmt_get_result($stmt);

            if($numrows = mysqli_num_rows($result) >0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    $comment = checkCommentExistsID($con,$row['CRcomid']);
                    $user = userIDExists($con,$comment['comuid']);
                    $upro = profileExistsID($con,$user['ID']);
                    echo "
                    <div class='card mt-5 border-5 pt-2 active pb-0 px-3'>
                        <div class='card-body'>
                            <div class='post'>
                                <div class='user-block'>
                                    <!-- User information -->
                                    <img class='rounded-circle' src='img/$upro[ProfilePicture]' onerror=this.src='img/beard.png' style='width:50px;height:50px;'>
                                    <span class='username'>
                                        <a href='profile.php?name=".$user['Name']."&token=".$user['Token']."'>$user[Name]</a>
                                        <a href='#' class='float-right btn-tool'><i class='fas fa-times'></i></a>
                                    </span>
                                    <hr>
                                    <!-- User message -->
                                    <p>$comment[commessage]</p>
                                    <hr>
                                    <!-- User date -->
                                    <span class='description'>Commented on: $comment[comdate]</span>
                                </div>
                            </div>
                        </div>
                    </div>
                        ";
                }
            }

            mysqli_stmt_close($stmt);
        }
    }
    ?>
</section>
<!-- /.content -->
    </div>
    </section>
</body>
</html>