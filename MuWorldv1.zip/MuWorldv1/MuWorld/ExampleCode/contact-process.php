<?php
   //print_r($_POST);

   //Validation

   //define variables and set to empty values
   $name_error = $mail_error = $subject_error = $message_error = "";
   $name = $mail = $subject = $message = $success = "";

   //Form is submitted with POST method
   if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST["name"])){ 
       $name_error = "Full name is required";
   } 
   else 
   {
       $name = test_input($_POST["name"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$name))
        {
            $name_error = "Only letters and white space allowed";
        }
    }
   
   //email
   if(empty($_POST["mail"]))
   { 
    $mail_error = "Email is required";
    } 
    else 
    {
         $mail = test_input($_POST["mail"]);
        if(!filter_var($mail, FILTER_VALIDATE_EMAIL))
        {
            $mail_error = "Invalid email";
        }
    }
    

     //subject
     if(empty($_POST["subject"])) 
     { 
        $subject_error = "Subject is required";
    } 
    else 
    {
        $subject = test_input($_POST["subject"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$subject))
        {
         $subject_error = "Only letters and white space allowed";
        }
    }

    //message
     if(empty($_POST["message"]))
     { 
        $message_error = "Message is required";
     } 
     else
     {
        $message = test_input($_POST["message"]);
        if(!preg_match("/^[a-zA-Z ]*$/",$subject))
        {
         $message_error = "Only letters and white space allowed";
        }
     }

    if($name_error == '' and $mail_error == '' and $subject_error == '' and $message_error == '')
    {
    $message_body = '';
    unset($_POST['submit']);
    foreach ($_POST as $key => $value)
    {
        $message_body .= "$key: $value\n";
    } 

        $mailTo = "imighty.jones@gmail.com";
        $headers = "From: ".$mail;
        $txt = "You have recieved an email from ".$name.".\n\n".$message;

        if(mail($mailTo, $subject, $txt, $headers))
        {
            $success = "Message sent, thank you for contacting us!";
            $name = $mail = $subject = $message = "";
        }       
    }
}

function test_input($data){
    $data = trim($data);
    $data = stripcslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
