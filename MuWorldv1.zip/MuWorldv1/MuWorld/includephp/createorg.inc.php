<?php
//Condition to check if button was pressed on the login page to access this code.

if(isset($_POST["oSubmit"]))
{

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  $uemail = $_POST['uemail'];
  $orgname = $_POST['orgname'];
  $orgemail = $_POST['orgemail'];
  $orgtel = $_POST['orgtel'];
  $orgadd = $_POST['orgadd'];
  $orglink = $_POST['orgweb'];
  $orgindust = $_POST['orgindustry'];
  //---------------------------- Error Handlers ---------------------------------
  
  //Condition to check if function returns is false and only false. (!==)**
  //Condition to check if inputs are empty for login.

  if (empty($orgname) || empty($orgemail) || empty($orgtel) || empty($orgadd) || empty($orglink)|| empty($orgindust))
  {
        header("location: ../createorg.php?error=noinput");
        exit();   
  }
  else
  {
    
    if(checkOrgName($con,$orgname) === false)
    {
      createOrganisation($con,$orgname,$orgemail,$orgtel,$orgadd,$orglink,$orgindust);
    }
    else
    {
      header("location: ../createorg.php?error=oe");
      exit();
    }
    
  }

  //------------------------------------------------------------------------------
  //Function to create research.

    header("location: ../createorg.php?error=none");
    exit();
} 
else //If page is accessed will be returned to login.php page to prevent access to this page.
{
    header("location: ../createorg.php");
    exit();
}