<?php
//Condition to check if button was pressed on the login page to access this code.
if(isset($_POST['submit']))
{
  $uname = $_POST['email'];
  $upass = $_POST['pass'];
  
  $errorEmpty = false;
  $errorExists = false;
  $errorValid = false;
  $errorPass = false;

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  //---------------------------- Error Handlers ---------------------------------
  
  //Condition to check if function returns is false and only false. (!==)**
  //Condition to check if inputs are empty for login.
  if(checkEmptyInputsLogin($uname,$upass) !== false)
  {
    echo "<span style='color: red;'>Fill in all fields.</span>";
    $errorEmpty = true;
  }
  else if(uidExists($con,$uname) === false)
  {
    echo "<span style='color: red;'>Account does not exists.</span>";
    $errorExists = true;
  }
  else if(checkUserValidation($con,$uname) !== false)
  {
    echo "<span style='color: red;'>Account is not verified.</span>";
    $errorValid = true;
  }
  else //Success condition.
  {
    do
    {
        if($uExists = uidExists($con,$uname) !== false)
        {
        $uExists = uidExists($con,$uname);
        // Taking database data from associated table created in function IMPORTANT**
        $pwdHashed = $uExists["Password"]; 
        //Returns a true or false if input password matches the password in database.
        $checkPwd = password_verify($upass,$pwdHashed); 
        if($checkPwd===false)
        {
            echo "<span style='color: red;'>Password is invalid.</span>";
            $errorPass = true;
            break;
        }
        }
        

        echo "<span style='color: green;'>Logging in</span>";
        //Function to log user in.
        loginUser($con,$uname,$upass);
    }
    while(0);
  }
  //------------------------------------------------------------------------------

  
  

}
else //If page is accessed will be returned to login.php page to prevent access to this page.
{
    echo "<span style='color: red;'>ERROR!</span>";
}

?>

<script>
    $("#log-email, #log-pass").removeClass("input-error");

    var errorEmpty = "<?php echo $errorEmpty; ?>";
    var errorExists = "<?php echo $errorExists; ?>";
    var errorValid = "<?php echo $errorValid; ?>";
    var errorPass = "<?php echo $errorPass; ?>";

    if(errorEmpty == true)
    {
      $("#log-email, #log-pass").addClass("input-error");
    }
    if(errorExists == true)
    {
      $("#log-email").addClass("input-error");
    }
    if(errorValid == true)
    {
      
    }
    if(errorPass == true)
    {
      $("#log-pass").addClass("input-error");
    }
    if(errorEmpty == false && errorExists == false)
    {
      $("#log-email, #log-pass").val("");
    }

</script>