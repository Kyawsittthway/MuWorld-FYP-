<?php
    include_once 'dbh.inc.php';
    include_once 'functions.inc.php';

    if(isset($_POST['joinresearch']))
    {

    
        if(checkResearchGroup($con,$_POST['crid'],$_POST['cuid'])===false)
        {
            createNotificationResearch($con,$_POST['cruid'],$_POST['cuid'],'join');
            joinResearch($con,$_POST['crid'],$_POST['cuid'],'Member');

            header("location:../detailedresearch.php?ID=$_POST[crid]&?joined=true");
            exit();
        }
        else
        {
            header("location:../detailedresearch.php?ID=$_POST[crid]&?joined=false");
            exit(); 
        }
        
    }
    else if(isset($_POST['leaveresearch']))
    {
        if(checkResearchAdminNum($con,$_POST['crid'],'Admin')==1)
        {
            leaveResearch($con,$_POST['crid'],$_POST['cuid']);
            
            $rentry = checkResearchExistsID($con,$_POST['crid']);
            if($rentry['rcreator']==$_POST['cuid'])
            {
                
                deleteResearch($con,$_POST['crid']);

                header("location:../detailedresearch.php?left?deleted");
                exit();
            }
            
            createNotificationResearch($con,$_POST['cruid'],$_POST['cuid'],'leave');
            header("location:../detailedresearch.php?ID=$_POST[crid]?left");
            exit(); 
        }
        else
        {
            createNotificationResearch($con,$_POST['cruid'],$_POST['cuid'],'leave');
            leaveResearch($con,$_POST['crid'],$_POST['cuid']);
            header("location:../detailedresearch.php?ID=$_POST[crid]?left");
            exit();
        }
        

        
    }
    else if(isset($_POST['commentsub']))
    {
        $message = $_POST['commentdata'];
        
        if(!empty($message))
        {
            //throw new exception();
            createComment($con,$_POST['UID'],$message);
            $comment = checkCommentExists($con,$_POST['UID'],$message);
            createLinkComRes($con,$comment['comid'],$_POST['RID']);
            createNotificationComment($con,$_POST['RID'],$_POST['UID']);
            header("location:../detailedresearch.php?ID=$_POST[RID]?success");
        }
        else
        {
            header("location:../detailedresearch.php?ID=$_POST[RID]?emptyinput");
        }
    }
    else
    {
        header("location:../detailedresearch.php?ID=$_POST[crid]?error=ERROR");
        exit();
    }

    
?>