<?php
//Following three variables are needed to do xaamp local hosting.
$host="localhost";
$user="root";
$password="";
$db="test"; //Subjected to change if new database is created. Important!!!****

//Variable to connect to the mysql database.
$con=mysqli_connect($host,$user,$password,$db);

//Condition to check if connection fails or not.
if(!$con)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>