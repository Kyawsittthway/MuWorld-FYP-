<?php

//-----------------------------------------------------------------------------------------------
//----------------------------- Functions for register page -------------------------------------

//Function to check if any of the fields are empty.
function checkEmptyInputs($fname,$email,$pass,$repass,$aterms)
{
    $result;
    //Condition to check if the variables contain data inside.
    if(empty($fname) ||empty($email)||empty($pass)||empty($repass)||empty($aterms))
    {
         $result=true; //If entered it means one of the variables is empty.
    }
    else
    {
         $result=false; //If not condition success.
    }
    return $result;
}

//Function to check if name is invalid.
function invalidName($fname)
{
    $result;
    //Condition check if the name only contains letters.
    if(!preg_match("/^[a-zA-Z]*$/", $fname))
        $result = true; //if entered it means the condition has other type of inputs.
    else
        $result = false;
    
    return $result;
}

//Function to check if email is invalid.
function invalidEmail($email)
{
    $result;
   
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        $result = true; 
    else
        $result = false;

    return $result;
}

//Function to check if passwords match.
function passMatch($pass,$repass)
{
    $result;
   
    if($pass !==$repass)
        $result = true;
    else
        $result = false;

    return $result;
}

//Function to check database for existing user.
function uidExists($con,$email)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM user WHERE Email = ?;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=stmtfailed");
        exit();
    }

    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"s",$email);
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//Function to check database for existing user.
function userIDExists($con,$uid)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM user WHERE ID = ?;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=stmtfailed");
        exit();
    }

    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"s",$uid);
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//Function to check database for existing user.
function uTokenExists($con,$token)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM user WHERE Token = ?;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=stmtfailed");
        exit();
    }

    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"s",$token);
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//Function to check database for existing user profile.
function profileExists($con,$email)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM profile WHERE ID = ?;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=pcf");
        exit();
    }
    $uidExists = uidExists($con,$email);
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"s",$uidExists["ID"]);
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//Function to check database for existing user profile.
function profileExistsID($con,$uid)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM profile WHERE ID = ?;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=pcf");
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"s",$uid);
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//Function to create a user in the database.
function createUser($con,$name,$email,$pwd,$token)
{
    //SQL statement for database, might be subjected to change!!**
    $sql = "INSERT INTO user (Name, Email, Password,Token) VALUES (?,?,?,?);";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=stmtfailed");
        exit();
    }
    
    //Extra security measurement to hash password to make it unreadable to hackers.
    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"ssss",$name,$email,$hashedPwd,$token);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    createProfile($con,$email);
    
    //Sending verification email with the following code
    $to = $email;
    $subject = "Email Verification";
    $message = "You have successfully registered to Mu World, please verify email to complete 
    registration.<br>"; 
    $message .= "<a href='http://localhost/login.php?token=$token'>Verify Email</a>";
    $headers = "From: nyk.com.sg@gmail.com"; //Preset email for server from config file.
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset-UTF-8" . "\r\n";
    
    mail($to,$subject,$message,$headers);
    //End of code block for verification sending.
}

//Function to create a profile once a user account is created. This will create a record in the
//profile table. IMPORTANT** Subjected to change.
function createProfile($con,$email)
{
    //SQL statement for database, might be subjected to change!!**
    $sql = "INSERT INTO profile(ID,Education,Location,Occupation,ProfilePicture) VALUES(?,?,?,?,?);";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../register.php?error=stmtfailed");
        exit();
    }
    
    $uidExists = uidExists($con,$email);
    //Condition to check if user exists.
    if($uidExists === false)
    {
        header("location: ../register.php?error=usermissing");
        exit();
    }

    //variables to put into bind param. 
    $uid = $uidExists["ID"];
    $v1 = null;
    $v2 = null;
    $v3 = null;
    $v4 = null;
    mysqli_stmt_bind_param($stmt,"sssss",$uid,$v1,$v2,$v3,$v4);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

//-----------------------------------------------------------------------------------------------

//----------------------------- Functions for login page -------------------------------------

function checkEmptyInputsLogin($email,$pass)
{
    $result;
    //Condition to check if the variables contain data inside.
    if( empty($email) || empty($pass) )
    {
         $result=true; //If entered it means one of the variables is empty.
    }
    else
    {
         $result=false; //If not condition success.
    }
    return $result;
}
function checkUserValidation($con,$uname)
{
    $result;
    //Condition to check if the variables contain data inside.
    $uidExist = uidExists($con,$uname);

    if($uidExist["Verified"]==0)
    {
         $result=true; //If entered it means one of the variables is empty.
    }
    else
    {
         $result=false; //If not condition success.
    }
    return $result;
}

function loginUser($con,$email,$pass)
{ 
    $uidExists = uidExists($con,$email);
    //Condition to check if user exists with created function.
    if($uidExists === false)
    {
        //header("location: ../login.php?error=wronglogin");
        //exit();
    }
    
    $uproExists = profileExists($con,$email);
    //Condition to check if user profile exists with created function.
    if($uproExists === false)
    {
        //header("location: ../login.php?error=wronglogin");
        //exit();
    }
    // Taking database data from associated table created in function IMPORTANT**
    $pwdHashed = $uidExists["Password"]; 
    //Returns a true or false if input password matches the password in database.
    $checkPwd = password_verify($pass,$pwdHashed); 

    //Conditions to activate depending on the boolean above.
    if($checkPwd === false)
    {
        //header("location: ../login.php?error=wronglogin");
        //exit();
    }
    else if($checkPwd === true)
    {
        session_start(); //Creates a session that can be access by the whole website.
        //Creating variables that are global to the whole website using the 
        //associated table created in function Important**
        $_SESSION["suserid"] = $uidExists["ID"]; 
        $_SESSION["sfullname"] = $uidExists["Name"];
        $_SESSION["semail"] = $uidExists["Email"];

        $_SESSION["sedu"] = $uproExists["Education"];
        $_SESSION["sloc"] = $uproExists["Location"];
        $_SESSION["socc"] = $uproExists["Occupation"];
        $_SESSION["supic"] = $uproExists["ProfilePicture"];
        $_SESSION["sorg"] = $uproExists["Organisation"];
        //Finally send user to dashboard page if login is successful.
        //header("location: ../test.php");
        //exit();
    }
}

//---------------------------------------------------------------------------------------------

//-------------------------------- profile page ----------------------------------------------

function checkEmptyUsers($currentU, $targetU, $URL, $currentUE)
{
    $result;
    if(empty($currentU) || empty($targetU) || empty($URL) || empty($currentUE))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function CreateNotificationFriend($con,$currentUE,$targetU)
{
    $sName = uidExists($con,$currentUE);
    $message = "You have a friend request from $sName[Name]";
    $sql = "INSERT INTO `notifications` (nuid,ntype,nmessage,nstatus) 
                                 VALUES ('$targetU','friend','$message','unread');";
    $stmt = mysqli_stmt_init($con);
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function CreateFriendRequest($con,$currentU,$targetU)
{
    $sql = "INSERT INTO `friendstatus` (FRuids,FRuidr,FRstatus) 
                                 VALUES ('$currentU','$targetU','pending')";
    $stmt = mysqli_stmt_init($con);
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function createNotificationResearch($con,$ruid,$cuid,$status)
{
    $sName = userIDExists($con,$cuid);

    if(strcmp($status,'join')==0)
    {
        $message = "$sName[Name] has joined your research project.";
    }
    else
    {
        $message = "$sName[Name] has left your research project.";
    }
    $sql = "INSERT INTO `notifications` (nuid,ntype,nmessage,nstatus) 
                                 VALUES ('$ruid','research','$message','unread');";
    $stmt = mysqli_stmt_init($con);
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function createNotificationComment($con,$rid,$cuid)
{
    $suser = userIDExists($con,$cuid);
    $sname = $suser['Name'];
    $research = checkResearchExistsID($con,$rid);
    $ruser = userIDExists($con,$research['rcreator']);
    $ruid = $ruser['ID'];
    $message = "$sname has commented on your research project called '$research[rtitle]'.";
    $modmessage = str_replace( array("#", "'", ";"), ' ', $message); //IMPORTANT SQL STATEMENTS CAN'T TAKE STRINGS WITH "'" in it.
    $sql = "INSERT INTO `notifications` (nuid,ntype,nmessage,nstatus) VALUES ('$ruid','comment','$modmessage','unread');";
    $stmt = mysqli_stmt_init($con);
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function createNotificationReport($con,$reportid,$uid,$status)
{
    $report = checkReportExistsID($con,$reportid);
    $event = checkEventExists($con,$report['EReid']);
    $message = "Admin has $status your report on the following event called $event[title].";

    $sql = "INSERT INTO `notifications` (nuid,ntype,nmessage,nstatus) VALUES ('$uid','report','$message','unread');";
    $stmt = mysqli_stmt_init($con);
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function checkNotifications($con,$uid)
{
    $sql = "SELECT * FROM `notifications` WHERE nuid = $uid AND nstatus='unread';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($numofrows = mysqli_num_rows($resultData))
    {
        return $numofrows;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkNotificationsType($con,$uid,$type)
{
    $sql = "SELECT * FROM `notifications` WHERE `nuid` = $uid AND `ntype` = '$type' AND `nstatus` ='unread';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($numofrows = mysqli_num_rows($resultData))
    {
        return $numofrows;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkFriendRequest($con,$currentU,$targetU)
{
    $sql = "SELECT * FROM `friendstatus` WHERE (FRuids = $currentU OR FRuids = $targetU) AND 
                                               (FRuidr = $targetU OR FRuidr = $currentU);";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkFriendNumber($con,$Uid)
{
    $sql = "SELECT * FROM `friendstatus` WHERE (FRuids = $Uid OR FRuidr = $Uid) AND FRstatus = 'accepted';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($numofrow = mysqli_num_rows($resultData))
    {
        return $numofrow;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//--------------------------------------------------------------------------------------------

//-------------------------------- editprofile page ---------------------------------------

//Function to check if no values are inputted.
function checkEmptyValues($org,$dep,$edu,$loc,$occ,$pic,$skill)
{
    $result;
    if(empty($org)&&empty($dep)&&empty($edu)&&empty($loc)&&empty($occ)&&empty($pic)&&empty($skill))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function checkOrg($org)
{
    $result;
    if(!empty($org))
    {
       $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function checkOrgName($con, $org)
{
    $sql = "SELECT * FROM `organisations` WHERE `orgname` = '$org';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row= mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkOrgID($con,$orgID)
{
    $sql = "SELECT * FROM `organisations` WHERE orgid = '$orgID';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row= mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkDepCon($dep)
{
    $result;
    if(!empty($dep))
    {
       $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function checkDepName($con,$dep)
{
    $sql = "SELECT * FROM `departments` WHERE Dname = '$dep';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row= mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkDepID($con,$dep)
{
    $sql = "SELECT * FROM `departments` WHERE Did = '$dep';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row= mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

//Function to check if edu has a value
function checkEdu($edu)
{
    $result;
    if(!empty($edu))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}
//Function to check if loc has a value
function checkLoc($loc)
{
    $result;
    if(!empty($loc))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}
//Function to check if occ has a value
function checkOcc($occ) 
{
    $result;
    if(!empty($occ))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}
//Function to check if pic has a value
function checkPic($pic)
{
    $result;
    if(!empty($pic))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function checkSkills($skills)
{
    $result;
    if(!empty($skills))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function checkSkillExists($con,$sname)
{
    $sql = "SELECT * FROM `skills` WHERE `sname` = '$sname';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkSkillExistsID($con,$sid)
{
    $sql = "SELECT * FROM `skills` WHERE `sid` = '$sid';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function addUserSkills($con,$skills,$uid)
{
    foreach($skills as $selected)
    {
        $sname = checkSkillExists($con,$selected);
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO skillsuser (SUsid,SUuid) VALUES ($sname[sid],$uid);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../editprofile.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

//Function to update User profile with the chosen column in table.
function updateUserProfile($con,$uID,$data,$col)
{
    $profileExists = profileExistsID($con,$uID);
    if($profileExists === false)
    {
        header("location: ../editprofile.php?error=profilemissing??");
        exit();
    }
    //SQL statement for database, might be subjected to change!!**
    $sql = "UPDATE profile SET $col = ? WHERE ID = ?;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        header("location: ../editprofile.php?error=stmtfailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt,"ss",$data,$uID);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $profileExists = profileExistsID($con,$uID);

    $_SESSION["sedu"] = $profileExists["Education"];
    $_SESSION["sloc"] = $profileExists["Location"];
    $_SESSION["socc"] = $profileExists["Occupation"];
    $_SESSION["supic"] = $profileExists["ProfilePicture"];
    $_SESSION["sorg"] = $profileExists["Organisation"];
    $_SESSION["sdep"] = $profileExists["Department"];
}

//--------------------------------------------------------------------------------------------

//------------------------------------ search functions --------------------------------------

    function checkEmptyInput($input)
    {
        $result;
        if(empty($input))
        {
            $result = true;
        }
        else
        {
            $result = false;
        }
        return $result;
    }

//--------------------------------------------------------------------------------------------



//------------------------------------ Research feature --------------------------------------
    function checkEmptyResearch($title,$descript,$link)
    {
        $result;
        if(empty($title) ||empty($descript) ||empty($link))
            $result = true;
        else
            $result = false;

        return $result;
    }

    function createResearch($con,$title,$descript,$link,$uemail)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO research(rtitle,rdescript,rlink,rcreator) VALUES(?,?,?,?);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            header("location: ../createresearch.php?error=stmtfailed");
            exit();
        }
        
        $uidExists = uidExists($con,$uemail);
        //Condition to check if user exists.
        if($uidExists === false)
        {
            header("location: ../createresearch.php?error=usermissing");
            exit();
        }

        //variables to put into bind param. 
        $uid = $uidExists["ID"];

        mysqli_stmt_bind_param($stmt,"ssss",$title,$descript,$link,$uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $result = checkResearchExists($con,$title,$descript,$link,$uemail);
        if($result ===false)
        {
            header("location: ../createresearch.php?error=researchmissing");
            exit();
        }
        else
        {
            createLink($con,$result['rid'],$uid);
        }
    }

    function createResearchWithOrg($con,$title,$descript,$link,$uemail,$orgid)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO research(rtitle,rdescript,rlink,rorg,rcreator) VALUES(?,?,?,?,?);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            header("location: ../createresearch.php?error=stmtfailed");
            exit();
        }
        
        $uidExists = uidExists($con,$uemail);
        //Condition to check if user exists.
        if($uidExists === false)
        {
            header("location: ../createresearch.php?error=usermissing");
            exit();
        }

        //variables to put into bind param. 
        $uid = $uidExists["ID"];

        mysqli_stmt_bind_param($stmt,"sssss",$title,$descript,$link,$orgid,$uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        $result = checkResearchExists($con,$title,$descript,$link,$uemail);
        if($result ===false)
        {
            header("location: ../createresearch.php?error=researchmissing");
            exit();
        }
        else
        {
            createLink($con,$result['rid'],$uid);
        }
    }

    function checkResearchExists($con,$title,$descript,$link,$uemail)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM research WHERE rtitle = ? AND rdescript = ? AND rlink = ? AND rcreator = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        $uidExists = uidExists($con,$uemail);
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"ssss",$title,$descript,$link,$uidExists["ID"]);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_fetch_assoc($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

    mysqli_stmt_close($stmt);
    }

    function checkResearchExistsID($con,$rid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM research WHERE rid = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"s",$rid);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_fetch_assoc($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

    mysqli_stmt_close($stmt);
    }

    function checkResearchNumber($con,$uid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM research WHERE rcreator = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"s",$uid);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($numofrows = mysqli_num_rows($resultData))
        {
            return $numofrows;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function createLink($con,$rid,$uid)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO researchusers(RUrid,RUuid,RUstatus) VALUES(?,?,?);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            header("location: ../createresearch.php?error=stmtfailed");
            exit();
        }
        $status = "Admin";
        mysqli_stmt_bind_param($stmt,"sss",$rid,$uid,$status);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    function deleteResearch($con,$rid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "DELETE FROM research WHERE rid = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"s",$rid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    function joinResearch($con,$rid,$uid,$status)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO researchusers(RUrid,RUuid,RUstatus) VALUES(?,?,?);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            header("location: ../createresearch.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt,"sss",$rid,$uid,$status);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    function leaveResearch($con,$rid,$uid)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "DELETE FROM researchusers WHERE RUrid = ? AND RUuid =?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            header("location: ../createresearch.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt,"ss",$rid,$uid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    function checkResearchGroup($con,$rid,$uid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM researchusers WHERE RUrid = ? AND RUuid = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"ss",$rid,$uid);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_fetch_assoc($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function checkResearchGroupUID($con,$uid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM researchusers WHERE RUuid = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"s",$uid);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_num_rows($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function checkResearchAdminNum($con,$rid,$status)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM researchusers WHERE RUrid = ? AND RUstatus = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"ss",$rid,$status);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($rows = mysqli_num_rows($resultData))
        {
            return $rows;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function checkResearchAdmin($con,$rid,$status)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM researchusers WHERE RUuid = ? AND RUstatus = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            header("location: ../createresearch?error=crestmtfailed");
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"ss",$rid,$status);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_fetch_assoc($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function createComment($con,$uid,$message)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO comments (comuid,commessage) VALUES(?,?);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            exit();
        }
        mysqli_stmt_bind_param($stmt,"ss",$uid,$message);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    function checkCommentExists($con,$uid,$message)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM comments WHERE comuid = ? AND commessage = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"ss",$uid,$message);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_fetch_assoc($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    
    function checkCommentExistsID($con,$comid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM comments WHERE comid = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"s",$comid);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($row = mysqli_fetch_assoc($resultData))
        {
            return $row;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }

    function createLinkComRes($con,$comid,$rid)
    {
        //SQL statement for database, might be subjected to change!!**
        $sql = "INSERT INTO comres (CRcomid,CRrid) VALUES(?,?);";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            exit();
        }
        mysqli_stmt_bind_param($stmt,"ss",$comid,$rid);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
    
    function checkComRes($con,$rid)
    {
        //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
        $sql = "SELECT * FROM comres WHERE CRrid = ?;";
        $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
        
        //Condition to prepare the stmt variable if successful carrys on if not show fail message.
        if(!mysqli_stmt_prepare($stmt,$sql))
        {
            trigger_error($con->error, E_USER_ERROR); //used to check sql errors
            exit();
        }
        //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
        mysqli_stmt_bind_param($stmt,"s",$rid);
        mysqli_stmt_execute($stmt);
        
        //Put the results of the stmt into the resultData variable. This is the user input
        //after ensuring the input is safe.
        $resultData = mysqli_stmt_get_result($stmt);

        //Condition to check if data exists in the database matches with input.
        if($numofrows = mysqli_num_rows($resultData))
        {
            return $numofrows;
        }
        else
        {
            $result = false;
            return $result;
        }

        mysqli_stmt_close($stmt);
    }
//--------------------------------------------------------------------------------------------

//------------------------------------ Organisation page --------------------------------------

function createOrganisation($con,$orgname,$orgemail,$orgtel,$orgadd,$orglink,$orgindust)
{
    //SQL statement for database, might be subjected to change!!**
    $sql = "INSERT INTO `organisations` (orgname,orgemail,orgcontact,orgaddress,orglink,orgindustry) VALUES(?,?,?,?,?,?);";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.

    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))

    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }

    mysqli_stmt_bind_param($stmt,"ssssss",$orgname,$orgemail,$orgtel,$orgadd,$orglink,$orgindust);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

//--------------------------------------------------------------------------------------------

//------------------------------------ Event features --------------------------------------

function checkEventExists($con,$eid)
{
     //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
     $sql = "SELECT * FROM admin_event WHERE id = ?;";
     $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
     
     //Condition to prepare the stmt variable if successful carrys on if not show fail message.
     if(!mysqli_stmt_prepare($stmt,$sql))
     {
         trigger_error($con->error, E_USER_ERROR); //used to check sql errors
         exit();
     }
     //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
     mysqli_stmt_bind_param($stmt,"s",$eid);
     mysqli_stmt_execute($stmt);
     
     //Put the results of the stmt into the resultData variable. This is the user input
     //after ensuring the input is safe.
     $resultData = mysqli_stmt_get_result($stmt);

     //Condition to check if data exists in the database matches with input.
     if($row = mysqli_fetch_assoc($resultData))
     {
         return $row;
     }
     else
     {
         $result = false;
         return $result;
     }

     mysqli_stmt_close($stmt);
}

function checkEmptyReport($eid,$uid,$hevent,$devent,$cevent)
{
    $result;
    if(empty($eid)||empty($uid)||empty($hevent)||empty($devent)||empty($cevent))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

function checkReportExists($con,$eid,$uid)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM eventreports WHERE EReid = $eid AND ERuid = $uid;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function checkReportExistsID($con,$rid)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "SELECT * FROM eventreports WHERE ERid = $rid;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    
    //Put the results of the stmt into the resultData variable. This is the user input
    //after ensuring the input is safe.
    $resultData = mysqli_stmt_get_result($stmt);

    //Condition to check if data exists in the database matches with input.
    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function createReport($con,$eid,$uid,$hevent,$devent,$cevent,$status)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "INSERT INTO eventreports (EReid,ERuid,Hevent,Devent,Cevent,ERstatus) VALUES (?,?,?,?,?,?);";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_bind_param($stmt,"ssssss",$eid,$uid,$hevent,$devent,$cevent,$status);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function updateReportStatus($con,$reportid,$status)
{
    //SQL Command for database, could be subjected to change. IMPORTANT!!!!***
    $sql = "UPDATE `eventreports` SET ERstatus = '$status' WHERE ERid = $reportid;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR); //used to check sql errors
        exit();
    }
    //Parameters goes as follow prepared SQL, amount of strings, amount of input from user.
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

//--------------------------------------------------------------------------------------------

//------------------------------------ Copy-paste for more --------------------------------------

//--------------------------------------------------------------------------------------------
?>