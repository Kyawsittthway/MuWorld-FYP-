<?php

include_once 'dbh.inc.php';
include_once 'functions.inc.php';

if(isset($_POST['accepted']))
{
    updateReportStatus($con,$_POST['reportid'],'accepted');
    createNotificationReport($con,$_POST['reportid'],$_POST['reportuser'],'accepted');
    header("location: ../reports.php?status=accepted");
    exit();
}
else if(isset($_POST['rejected']))
{
    updateReportStatus($con,$_POST['reportid'],'rejected');
    createNotificationReport($con,$_POST['reportid'],$_POST['reportuser'],'rejected');
    header("location: ../reports.php?status=rejected");
    exit();
}
else
{
    throw new exception("FATAL ERROR in reports.inc.php");
}

?>