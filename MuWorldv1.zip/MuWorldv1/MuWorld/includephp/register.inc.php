<?php

if(isset($_POST['submit']))
{
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass = $_POST['pass'];
  $repass = $_POST['repass'];
  $aterms = $_POST['aterms'];

  $errorEmpty = false;
  $errorEmail = false;
  $errorPassMatch = false;
  $errorExists = false;

  $token = md5(time().$email);

  include_once 'dbh.inc.php';
  include_once 'functions.inc.php';

  if(empty($name) || empty($email) || empty($pass) || empty($repass) || strcmp($aterms,"false")==0)
  {
      echo "<span style='color: red;'>Fill in all fields.</span>";
      $errorEmpty = true;
  }
  else if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
      echo "<span style='color: red;'>Write a valid email address.</span>";
      $errorEmail = true;
  }
  else if(passMatch($pass,$repass)!== false)
  {
      echo "<span style='color: red;'>Password do not match.</span>";
      $errorPassMatch = true;
  }
  else if(uidExists($con,$email) !== false)
  {
      echo "<span style='color: red;'>Email already exists.</span>";
      $errorExists = true;
  }
  else
  {
      echo "<span style='color: green;'>Register was Successfull, please verify email before logging in.</span>";
      createUser($con,$name,$email,$pass,$token);
      exit();
  }
}
else
{
  echo "<span style='color: red;'>There was an error!!!</span>";
}
?>

<script>
    $("#reg-name, #reg-email, #reg-pass, #reg-repass, #reg-aterms").removeClass("input-error");

    var errorEmpty = "<?php echo $errorEmpty; ?>";
    var errorEmail = "<?php echo $errorEmail; ?>";
    var errorPassMatch = "<?php echo $errorPassMatch; ?>";
    var errorExists = "<?php echo $errorExists; ?>";

    if(errorEmpty == true)
    {
      $("#reg-name, #reg-email, #reg-pass, #reg-repass, #reg-aterms").addClass("input-error");
    }
    if(errorEmail == true)
    {
      $("#reg-email").addClass("input-error");
    }
    if(errorPassMatch == true)
    {
      $("#reg-pass,#reg-repass").addClass("input-error");
    } 
    if(errorExists == true)
    {
      $("#reg-email").addClass("input-error");
    }
    if(errorEmpty == false && errorEmail == false && errorPassMatch == false && errorExists == false)
    {
      $("#reg-name, #reg-email, #reg-pass, #reg-repass, #reg-aterms").val("");
    }

</script>