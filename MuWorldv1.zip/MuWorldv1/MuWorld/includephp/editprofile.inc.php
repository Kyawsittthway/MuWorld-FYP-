<?php
//Condition to check if button was pressed on the login page to access this code.

if(isset($_POST["pSubmit"]))
{
  $org = $_POST["orgtext"];
  $edu = $_POST["edutext"];
  $loc = $_POST["loctext"];
  $occ = $_POST["occtext"];
  $dep = $_POST["depart"];
  $filename = $_FILES["profilepic"]["name"];
  $tmpname = $_FILES["profilepic"]["tmp_name"]; //HATE MY LIFE, TYPO HERE STUCK FOR HOURS FUCK ME SIDEWAYSSS
  $folder = "../img/";
   
  $UID = $_POST['uID'];
  if(!is_dir($folder))
  {
    if(!mkdir($folder,0777,true))
    {
      mkdir($folder,0777,true);
    }
  }

  $target_dir = "../img/";
  $target_file = $target_dir.basename($filename);

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  //---------------------------- Error Handlers ---------------------------------
  
  //Condition to check if function returns is false and only false. (!==)**
  //Condition to check if inputs are empty for login.

  if (checkEmptyValues($org,$dep,$edu,$loc,$occ,$filename,$_POST['selectskills']) !== false)
  {
      header("location: ../editprofile.php?error=noinput");
      exit();
  }

  //------------------------------------------------------------------------------
  //Function to update user profile.

  if(checkOrg($org) === true)
  {
    $checkorg = checkOrgName($con,$org);
    $col = "Organisation";
    
    updateUserProfile($con,$UID,$checkorg['orgid'],$col);
  }

  if(checkDepCon($dep) === true)
  {
    $checkdep = checkDepName($con,$dep);
    $col = "Department";
    updateUserProfile($con,$UID,$checkdep['Did'],$col);
  }

  if (checkEdu($edu) === true)
  {
      $col = "Education";
      updateUserProfile($con,$UID,$edu,$col);
  }
  if (checkLoc($loc) === true)
  {
      $col = "Location";
      updateUserProfile($con,$UID,$loc,$col);
  }
  if (checkOcc($occ) === true)
  {
      $col = "Occupation";
      updateUserProfile($con,$UID,$occ,$col);
  }
  if (checkPic($filename) === true)
  {
      if (move_uploaded_file($tmpname, $target_file))
      {
        $col = "ProfilePicture";
        updateUserProfile($con,$UID,$filename,$col);
        header("location: ../editprofile.php?error=movesuccess");
        exit();
      } 
      else
      { 
        header("location: ../editprofile.php?error=movefailed");
        exit();
      } 

  }
  if (checkSkills($_POST['selectskills']) === true)
  {
      //throw new Exception(); //Can be use to do error checking.
      addUserSkills($con,$_POST['selectskills'],$UID);
  }

      header("location: ../editprofile.php?error=none");
      exit();
}
else //If page is accessed will be returned to login.php page to prevent access to this page.
{
    header("location: ../editprofile.php");
    exit();
}