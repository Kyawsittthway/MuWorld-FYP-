<?php

if(isset($_POST['submit']))
{
  $name = $_POST['name'];
  $email = $_POST['email'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];

  $errorEmpty = false;
  $errorEmail = false;

  if(empty($name) || empty($email) || empty($subject) || empty($message))
  {
      echo "<span style='color: red;'>Fill in all fields!</span>";
      $errorEmpty = true;
  }
  else if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
      echo "<span style='color: red;'>Write a valid email address!</span>";
      $errorEmail = true;
  }
  else 
  {
      echo "<span style='color: green; font-size:24px;'>Message was sent!</span>";
      
      $mailTo = "imighty.jones@gmail.com";
      $headers = "From: ".$email;
      $txt = "You have recieved an email from ".$name." User email: " .$email. ".\n\n".$message;

      mail($mailTo, $subject, $txt, $headers);
  }
}
else
{
  echo "<span style='color: red;'>There was an error!!!</span>";
}
?>

<script>
    $("#mail-name, #mail-email, #mail-subject, #mail-message").removeClass("input-error");

    var errorEmpty = "<?php echo $errorEmpty; ?>";
    var errorEmail = "<?php echo $errorEmail; ?>";

    if(errorEmpty == true)
    {
      $("#mail-name").addClass("input-error");
    }
    if(errorEmail == true)
    {
      $("#mail-email").addClass("input-error");
    }
    if(errorEmpty == false && errorEmail == false)
    {
      $("#mail-name, #mail-email,#mail-message,#mail-subject").val("");
    }
</script> 