<?php
include_once 'dbh.inc.php';
include_once 'functions.inc.php';

if(isset($_POST['deletenote']))
{    
    $nid = $_POST['NID'];

    $sql = "UPDATE notifications SET nstatus = 'read' WHERE nid = $nid AND ntype = 'research';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../researchnote.php?notread=$nid");
    exit();
}
else if(isset($_POST['deletecom']))
{
    $nid = $_POST['NID'];

    $sql = "UPDATE notifications SET nstatus = 'read' WHERE nid = $nid AND ntype = 'comment';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../comments.php?notread=$nid");
    exit();
}
else if(isset($_POST['deletenoti']))
{
    $nid = $_POST['NID'];

    $sql = "UPDATE notifications SET nstatus = 'read' WHERE nid = $nid;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../allnotifications.php?notread=$nid");
    exit();
}
else if(isset($_POST['deletereport']))
{
    $nid = $_POST['NID'];

    $sql = "UPDATE notifications SET nstatus = 'read' WHERE nid = $nid AND ntype = 'report';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../reportupdates.php?read=$nid");
    exit();
}








?>