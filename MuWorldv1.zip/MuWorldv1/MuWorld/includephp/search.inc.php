<?php
//Condition to check if button was pressed on the login page to access this code.
if(isset($_POST["subsearch"]))
{
  $input = $_POST["searchinput"];

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  //---------------------------- Error Handlers ---------------------------------
  
  if(checkEmptyInput($input)!==false)
  {
    $url = $_POST['location'];
    header("location: ../$url?error=emptysearch");
    exit();
  }

  //------------------------------------------------------------------------------

  header("location: ../enhancedsearch-results.php?input=$input");
  exit();

}
else //If page is accessed will be returned to login.php page to prevent access to this page.
{
    header("location: ../index.php");
    exit();
}