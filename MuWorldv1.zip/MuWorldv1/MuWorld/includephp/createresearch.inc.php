<?php
//Condition to check if button was pressed on the login page to access this code.

if(isset($_POST["rSubmit"]))
{
  $title = $_POST["ir-title"];
  $descript = $_POST["ir-text"];
  $link = $_POST["ir-link"];

  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  $uemail = $_POST['uemail'];
  $orgname = $_POST['orgtext'];

  $orgdata = checkOrgName($con,$orgname);
  //---------------------------- Error Handlers ---------------------------------
  
  //Condition to check if function returns is false and only false. (!==)**
  //Condition to check if inputs are empty for login.

  if (checkEmptyResearch($title,$descript,$link) !== false)
  {
      header("location: ../createresearch.php?error=noinput");
      exit();
  }

  if(checkResearchExists($con,$title,$descript,$link,$uemail)!== false)
  {
    header("location: ../createresearch.php?error=rne");
    exit();
  }

  //------------------------------------------------------------------------------
  //Function to create research.
    if($orgdata!==false)
    {
      createResearchWithOrg($con,$title,$descript,$link,$uemail,$orgdata['orgid']);
    }
    else
    {
      createResearch($con,$title,$descript,$link,$uemail);
    }

    header("location: ../createresearch.php?error=none");
    exit();
} 
else //If page is accessed will be returned to login.php page to prevent access to this page.
{
    header("location: ../createresearch.php");
    exit();
}