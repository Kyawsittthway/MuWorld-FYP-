<?php
session_start(); //Start session to use session commands.
session_unset(); //Unset other sessions on the website.
session_destroy(); //Destroy session.

//Sends user back to homepage.
header("location: ../index.php");
exit();
?>