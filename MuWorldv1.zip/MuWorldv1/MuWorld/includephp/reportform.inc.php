<?php
include_once 'dbh.inc.php';
include_once 'functions.inc.php';

if(isset($_POST['rfSubmit']))
{
    $eid = $_POST['eid'];
    $uid = $_POST['UID'];
    $hevent = $_POST['hevent'];
    $devent = $_POST['devent'];
    $cevent = $_POST['cevent'];

//-------------------------- Error conditions ------------------------------------
    
    if(checkEmptyReport($eid,$uid,$hevent,$devent,$cevent))
    {
        header("Location: ../reportform.php?error=emptyinputs");
        exit();
    }

    if(checkReportExists($con,$eid,$uid))
    {
        header("Location: ../reportform.php?error=re");
        exit();
    }

//-------------------------- Functions after error checking ------------------------------------

//Create event report function.    
createReport($con,$eid,$uid,$hevent,$devent,$cevent,'pending');

header("Location: ../reportform.php?error=none");
exit();
}



?>