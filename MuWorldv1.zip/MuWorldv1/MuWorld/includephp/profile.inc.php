<?php
//Condition to check if button was pressed on the login page to access this code.
if(isset($_POST["addfriend"]))
{
  $currentU = $_POST['currentU'];
  $targetU = $_POST['targetU'];
  $URL = $_POST['url'];
  $currentUE = $_POST['currentUE'];
  require_once 'dbh.inc.php';
  require_once 'functions.inc.php';

  //---------------------------- Error Handlers ---------------------------------
  
  if(checkEmptyUsers($currentU, $targetU,$URL,$currentUE)!==false)
  {
    header("location: ../profile.php?$URL?error=emptyvalues");
    exit();
  }

  //------------------------------------------------------------------------------

  CreateNotificationFriend($con,$currentUE,$targetU);

  CreateFriendRequest($con,$currentU,$targetU);

  header("location: ../profile.php?$URL");
  exit();

}
else //If page is accessed will be returned to login.php page to prevent access to this page.
{
    header("location: ../index.php");
    exit();
}