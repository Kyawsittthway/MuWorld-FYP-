<?php

include_once 'dbh.inc.php';
include_once 'functions.inc.php';

if(isset($_POST['accept']))
{
    $uids = $_POST['uids'];
    $uidr = $_POST['uidr'];
    //SQL statement for database, might be subjected to change!!**
    $sql = "UPDATE friendstatus SET FRstatus = 'accepted' WHERE FRuids = $uids AND FRuidr = $uidr;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    $user = userIDExists($con,$uids);
    $sql = "UPDATE notifications SET nstatus = 'read' WHERE nuid = $uidr AND ntype = 'friend' AND nmessage LIKE '%$user[Name]%';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../friendrequest.php?accepted=$user[Name]");
    exit();
}
else if(isset($_POST['decline']))
{
    $uids = $_POST['uids'];
    $uidr = $_POST['uidr'];
    //SQL statement for database, might be subjected to change!!**
    $sql = "DELETE FROM friendstatus WHERE FRuids = $uids AND FRuidr = $uidr;";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $user = userIDExists($con,$uids);

    $sql = "DELETE FROM notifications WHERE nuid = $uidr AND ntype = 'friend' AND nmessage LIKE '%$user[Name]%';";
    $stmt = mysqli_stmt_init($con); //Prepared statement to ensure user cannot temper with database.
    
    //Condition to prepare the stmt variable if successful carrys on if not show fail message.
    if(!mysqli_stmt_prepare($stmt,$sql))
    {
        trigger_error($con->error, E_USER_ERROR);
        exit();
    }

    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../friendrequest.php?declined=$user[Name]");
    exit();
}
else
{
    header("location: ../friendrequest.php");
    exit();
}

?>