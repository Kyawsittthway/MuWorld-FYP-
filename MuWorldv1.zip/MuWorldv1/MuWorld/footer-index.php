<!--Javascript for Toggle Menu-->
<script>
        var navLinks = document.getElementById("navLinks");

        function showMenu(){
            navLinks.style.right = "0";
        }
        function hideMenu(){
            navLinks.style.right = "-200px";
        }

    </script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="javascript/idx.js"></script>
</body>
</html>