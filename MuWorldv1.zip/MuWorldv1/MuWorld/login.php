<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie-edge">
    <title>Mu World Website</title>
    <link rel="stylesheet" href="CSS/reg.css">
    <link rel="stylesheet" href="CSS/joshua.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <!-- Ajax scripts to have a non-refreshing page. -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function()
        {
            $("form").submit(function(event)
            {
                event.preventDefault();
                var email = $("#log-email").val();
                var pass = $("#log-pass").val();
                var lsubmit = $("#log-submit").val();

                $(".log-message").load("includephp/login.inc.php",
                {
                    email: email,
                    pass: pass,
                    submit: lsubmit

              
                }, function(responseTxt, statusTxt, xhr){
                    if(responseTxt.includes("Logging in"))
                    {
                        window.location.href = "dashboard2.php";
                    }
                });

                
            });
        });
    </script>

</head>
<body>

<main id="main-area">
    <!-- registration area -->
    <section id="login-form">
        <div class="row m-0">
            <div class="col-lg-4 offset-lg-2">
                <div class="text-center pb-5">
                    <h1 class="login-title text-dark">Login</h1>
                    <p class="p-1 m-0 font-ubuntu text-black-50">Log in and prepare to meet new users!</p>
                    <span class="font-ubuntu text-black-50">Create an <a href="register.php"> account</a></span>
                </div>
                <div class="upload-profile-image d-flex justify-content-center pb-5">
                    <div class="text-center"> 
                    <img src="<?php echo isset($user['profileImage']) ? $user['profileImage'] : './img/beard.png' ; ?>" style="width: 200px; height: 200px" class="img rounded-circle" alt="profile">                  
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <form action="includephp/login.inc.php" method="post" enctype="multipart/form-data" id="log-form">                       
                        <div class="form-row my-4">
                            <div class="col">
                                <input type="email" id="log-email" name="email" class="form-control" placeholder="Email*">
                            </div>
                        </div>

                        <div class="form-row my-4">
                            <div class="col">
                                <input type="password" id="log-pass" name="password" class="form-control" placeholder="password*">
                                
                            </div>
                        </div>
                        <span class="font-ubuntu text-black-50">Not feeling it? you can always go <a href="index.php"> back</a></span>
                        <div class="submit-btn text-center my-5">
                            <button type="submit" id="log-submit" name="submit" class="btn btn-warning rounded-pill text-dark px-5">Continue</button>
                            <br>
                            <br>
                            <br>
                            <span class="log-message" id="log-message"></span>
                        </div>
                        

                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- FOOTER -->
    <section class="footer">
    <h4>MuWorld</h4>
<p>A multi-media connection system. <br>A platform to provide FOLLOW UPS for user to stay in touch
    with each other. <br><a href="faq.php">FAQ</a></p>
    <p>Made with <i class="fa fa-heart"></i> by Local Sense</p>
</section>

</main>

</body>
</html>