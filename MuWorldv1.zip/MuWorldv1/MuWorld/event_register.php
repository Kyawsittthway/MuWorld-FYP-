<?php
      session_start();
      include_once 'header.php';
      include_once 'includephp/dbh.inc.php';
      include_once 'includephp/functions.inc.php';

   if(isset($_SESSION['semail']))
   {
     $usr_id =$_SESSION['suserid'];
   
   } 

   $connect = mysqli_connect("localhost","root","","test");
   if(isset($_POST['submit']))
   {
       $email = $_POST['email'];
       $eventID =$_POST['eventName'];
       $sql_check = "SELECT * FROM eventgoinguser WHERE event_id='$eventID' AND usrid='$usr_id'";
       $res_check=mysqli_query($connect,$sql_check);
       
       if(mysqli_num_rows($res_check)>0){
           echo "<h3 style='text-align:center;color:red;padding:10px;background-color:black;'>You have already registered for this event!!!<br>Click cancel to go home page.</h3>";
       }
       else{
       $insert=mysqli_query($connect,"INSERT INTO `eventgoinguser`(`event_id`,`usrid`,`email`) VALUES ('$eventID','$usr_id','$email')");
    //    echo $insert;
       if($insert)
       {
        echo "<h1 style='text-align:center;color:green;'>&check;Thanks for Registration!</h1><br>";
        echo "<div class='nav-button' style='text-align:center;'><a href='index.php'>Go Back to Home</a>";
       }
    }
      
   }
//    
  

  
   function fill_eventName($connect)
   {
       $output = '';
       $sql="SELECT * FROM admin_event";
       $result=mysqli_query($connect,$sql);
       while($row=mysqli_fetch_array($result))
       {
           $output .='<option value="'.$row["id"].'">'.$row["title"].'</option>';
       }
       return $output;
   }
   function fill_time($connect)
   {
       $output ='';
       $sql = "SELECT * FROM admin_event";
       $result =mysqli_query($connect,$sql);

       while($row=mysqli_fetch_array($result))
       {
     
        $output .='<option value="'.$row["id"].'">'.$row["admin_start"].'</option>';
    
       }
       return $output;
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration</title>

    <link rel="stylesheet" href="CSS/calendar.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
</head>
<body>
    <div class="container" style="margin-top:4rem;margin-bottom:3rem;">
    <div class="event-register-heading" style="text-align:center; ">
        <h1 style="text-align:center;">Event Registration Page</h1>
    </div> 
    <form method="POST">
    <div class="event-register-body" style="text-align:center;">
        <div class="form-group"><br>
            <label for="username" style="margin-bottom:1rem;">Name</label>
            <input type="text" name="username" value="" required> 
        </div><br>

        <div class="form-group"  >
            <label for="email" style="margin-bottom:2rem;">Email</label>
            <input type="email" name="email" value="" required>
        </div>

       
            <label style="margin-left:1rem;">Available Events</label>
            <br>
        <select name="eventName" id="event-name" style="margin-left:2.2rem;width:13rem;margin-bottom:1rem;">
            <option>...</option>
           <?php echo fill_eventName($connect);?>
        </select>
        <br>
       

        <label style="margin-left:1rem;">Duration of Events</label>
        <div id='showStart' style="margin-bottom:1rem;">
            <select name="event-startTime" id ="event-startTime">
                <option>...</option>
            
        </select>
        </div>
        <input type="submit" class="btn btn-success" name="submit" value="Confirm" style='background: crimson;'>
        <button id="cancel-btn-event" class="btn btn-secondary"><a href='publicEvent.php' style='color:white;'>Cancel</a></button>

    </div>
</form>
</div>
</body>
</html>
<script>  
 $(document).ready(function(){  
      $('#event-name').change(function(){  
           var id = $(this).val();  
           console.log(id);
           $.ajax({  
                url:"loadeventData.php",  
                method:"POST",  
                data:{id:id},  
                success:function(data){  
                     $('#showStart').html(data);  
                }  
           });  
      });  
 });  
 </script> 