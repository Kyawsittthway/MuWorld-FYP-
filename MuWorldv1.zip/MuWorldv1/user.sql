-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2021 at 02:55 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_event`
--

CREATE TABLE `admin_event` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `admin_start` datetime NOT NULL,
  `admin_end` datetime NOT NULL,
  `admin_color` varchar(10) NOT NULL DEFAULT '#fd08cd',
  `link` varchar(256) DEFAULT NULL,
  `adminBorder` varchar(10) NOT NULL DEFAULT '#FFFFFF'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_event`
--

INSERT INTO `admin_event` (`id`, `title`, `admin_start`, `admin_end`, `admin_color`, `link`, `adminBorder`) VALUES
(4, 'YK touchingself day', '2021-03-20 23:30:00', '2021-03-24 23:30:00', '#fd08cd', NULL, '#FFFFFF'),
(6, 'Jumbo', '2021-03-09 00:00:00', '2021-03-09 04:30:00', '#fd08cd', NULL, '#FFFFFF'),
(7, 'Joko', '2021-03-07 02:00:00', '2021-03-07 04:30:00', '#fd08cd', NULL, '#FFFFFF'),
(13, 'Time to buy witcher 3', '2021-04-10 07:00:00', '2021-04-10 20:30:00', '#fd08cd', '', '#FFFFFF'),
(14, 'Papaya', '2021-04-12 03:00:00', '2021-04-12 04:30:00', '#fd08cd', '', '#FFFFFF'),
(15, 'Molaja', '2021-04-13 00:00:00', '2021-04-14 00:00:00', '#fd08cd', 'https://www.google.com', '#FFFFFF'),
(17, 'Josh', '2021-04-14 00:00:00', '2021-04-15 00:00:00', '#fd08cd', 'Not Provided', '#FFFFFF');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comid` int(11) NOT NULL,
  `comuid` int(11) NOT NULL,
  `commessage` text NOT NULL,
  `comdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comid`, `comuid`, `commessage`, `comdate`) VALUES
(3, 1, 'This is the data that I am going to submit', '2021-04-09 00:09:05'),
(4, 7, 'yk sucks', '2021-04-09 00:11:34'),
(5, 5, 'I literally have no idea what kind of lunatics created this website???', '2021-04-09 00:13:16'),
(6, 7, 'hi', '2021-04-09 00:13:33'),
(7, 5, 'I literally have no idea what kind of lunatics created this website', '2021-04-09 00:13:38'),
(8, 5, 'Hail Hitler eat my foot~_~', '2021-04-09 00:14:49'),
(9, 7, 'supp', '2021-04-09 00:15:54'),
(10, 5, '1001 1011 0000 1110 10110', '2021-04-09 00:16:25'),
(11, 7, 'you gonna work not?', '2021-04-09 00:17:31'),
(12, 5, 'sumimasen , is this working or not?', '2021-04-09 00:18:51'),
(13, 7, 'noob', '2021-04-09 00:20:02'),
(14, 5, 'Baby! let\'s go your brother\'s party?', '2021-04-09 00:20:15'),
(15, 7, 'yk is noob', '2021-04-09 00:20:19'),
(16, 7, 'yes its working noob', '2021-04-09 00:20:30'),
(17, 7, 'you shit', '2021-04-09 00:20:38'),
(18, 7, 'piece of shit', '2021-04-09 00:20:45'),
(19, 7, 'kthxbye', '2021-04-09 00:21:01'),
(20, 5, '@NYK come and see this dumb sheet', '2021-04-09 00:21:22'),
(21, 7, 'hi Josh', '2021-04-09 00:21:23'),
(22, 7, 'hi Charles', '2021-04-09 00:21:40'),
(23, 5, 'Salamat Shopeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!', '2021-04-09 00:21:43'),
(24, 7, 'hi Sahana', '2021-04-09 00:21:55'),
(25, 5, 'Hello', '2021-04-09 00:25:35'),
(26, 5, 'NYK\'s ass should be whopped by his mother', '2021-04-09 00:26:36'),
(27, 1, 'This is the data that I am going to submit', '2021-04-09 00:33:17'),
(28, 1, 'comment x2', '2021-04-09 00:42:00'),
(29, 1, 'comment x2', '2021-04-09 00:42:48'),
(30, 7, 'yk sucks', '2021-04-09 00:43:19'),
(31, 1, 'get your inbox maxed out booyyyyyy', '2021-04-09 00:43:24'),
(32, 1, 'get your inbox maxed out booyyyyyy', '2021-04-09 00:44:57'),
(33, 1, 'get your inbox maxed out booyyyyyy', '2021-04-09 00:47:05'),
(34, 1, 'get your inbox maxed out booyyyyyy', '2021-04-09 00:47:24'),
(35, 1, 'get your inbox maxed out booyyyyyy', '2021-04-09 00:47:45'),
(36, 1, 'get your inbox maxed out booyyyyyy', '2021-04-09 00:52:48'),
(37, 1, 'test test', '2021-04-09 00:56:27'),
(38, 1, 'what is going on????', '2021-04-09 00:58:31'),
(39, 7, '?', '2021-04-09 00:59:27'),
(40, 1, 'test test', '2021-04-09 00:59:27'),
(41, 1, 'what is going on, face palm', '2021-04-09 01:00:05'),
(42, 1, 'test test', '2021-04-09 01:03:20'),
(43, 1, 'test test', '2021-04-09 01:03:42'),
(44, 1, 'test test', '2021-04-09 01:09:18'),
(45, 1, 'test test', '2021-04-09 01:09:27'),
(46, 1, 'this is not working out :D', '2021-04-09 01:09:47'),
(47, 8, 'i can get notifications now!!', '2021-04-09 01:10:25'),
(48, 7, '?', '2021-04-09 01:10:35'),
(49, 7, 'hello', '2021-04-09 01:10:47'),
(50, 7, 'have?', '2021-04-09 01:11:14'),
(51, 7, 'did u', '2021-04-09 01:11:26'),
(52, 1, 'YOU SUCK YOU SUCK', '2021-04-09 01:11:56'),
(53, 1, 'spam spam', '2021-04-09 01:12:57'),
(54, 1, 'spam', '2021-04-09 01:13:02'),
(55, 1, 'sapm spam spam', '2021-04-09 01:13:08'),
(56, 1, 'sapm you side ways', '2021-04-09 01:13:13'),
(57, 8, 'hii', '2021-04-09 01:17:53'),
(58, 1, 'comment x2', '2021-04-09 01:18:17'),
(59, 8, 'hellooo', '2021-04-09 01:18:33'),
(60, 8, 'testingg', '2021-04-09 01:23:22'),
(61, 6, 'Hello', '2021-04-09 01:29:38'),
(62, 7, 'hi', '2021-04-09 01:30:00'),
(63, 1, 'Hello this research looks interesting XD', '2021-04-09 01:30:04'),
(64, 7, 'you boy or girl', '2021-04-09 01:30:13'),
(65, 7, 'yk sucks', '2021-04-09 01:30:23'),
(66, 8, 'hellloooo', '2021-04-09 01:30:48'),
(71, 7, 'this?', '2021-04-09 02:03:38'),
(72, 7, 'This is the comment section.', '2021-04-09 02:03:58'),
(73, 1, 'YOU SUCK YOU SUCK', '2021-04-09 18:05:21'),
(74, 1, 'you suck x 2', '2021-04-09 18:07:44'),
(75, 4, 'test test', '2021-04-10 15:36:21');

-- --------------------------------------------------------

--
-- Table structure for table `comres`
--

CREATE TABLE `comres` (
  `CRcomid` int(11) NOT NULL,
  `CRrid` int(11) NOT NULL,
  `CRdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comres`
--

INSERT INTO `comres` (`CRcomid`, `CRrid`, `CRdate`) VALUES
(3, 16, '2021-04-09 00:09:05'),
(4, 16, '2021-04-09 00:11:34'),
(4, 17, '2021-04-09 01:30:23'),
(6, 16, '2021-04-09 00:13:33'),
(6, 17, '2021-04-09 01:30:00'),
(7, 16, '2021-04-09 00:13:38'),
(8, 16, '2021-04-09 00:14:49'),
(9, 16, '2021-04-09 00:15:54'),
(10, 16, '2021-04-09 00:16:25'),
(11, 16, '2021-04-09 00:17:31'),
(12, 16, '2021-04-09 00:18:51'),
(13, 16, '2021-04-09 00:20:02'),
(14, 16, '2021-04-09 00:20:15'),
(15, 16, '2021-04-09 00:20:19'),
(16, 16, '2021-04-09 00:20:30'),
(17, 16, '2021-04-09 00:20:38'),
(18, 16, '2021-04-09 00:20:45'),
(19, 16, '2021-04-09 00:21:01'),
(20, 16, '2021-04-09 00:21:22'),
(21, 16, '2021-04-09 00:21:23'),
(22, 16, '2021-04-09 00:21:40'),
(23, 16, '2021-04-09 00:21:44'),
(24, 16, '2021-04-09 00:21:55'),
(25, 16, '2021-04-09 00:25:36'),
(26, 16, '2021-04-09 00:26:36'),
(31, 16, '2021-04-09 00:43:25'),
(37, 16, '2021-04-09 00:56:27'),
(38, 16, '2021-04-09 00:58:31'),
(39, 16, '2021-04-09 00:59:27'),
(41, 16, '2021-04-09 01:00:05'),
(46, 16, '2021-04-09 01:09:48'),
(47, 16, '2021-04-09 01:10:25'),
(49, 16, '2021-04-09 01:10:47'),
(53, 7, '2021-04-09 01:12:57'),
(54, 7, '2021-04-09 01:13:02'),
(55, 7, '2021-04-09 01:13:08'),
(56, 7, '2021-04-09 01:13:13'),
(61, 16, '2021-04-09 01:29:38'),
(63, 17, '2021-04-09 01:30:04'),
(64, 17, '2021-04-09 01:30:13'),
(66, 17, '2021-04-09 01:30:48'),
(71, 16, '2021-04-09 02:03:38'),
(72, 20, '2021-04-09 02:03:58');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `Did` int(11) NOT NULL,
  `Dname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`Did`, `Dname`) VALUES
(1, 'Sales'),
(2, 'Information Technology (IT)'),
(3, 'Human Resource (HR)');

-- --------------------------------------------------------

--
-- Table structure for table `eventgoinguser`
--

CREATE TABLE `eventgoinguser` (
  `event_id` int(11) NOT NULL,
  `usrid` int(11) NOT NULL,
  `email` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `eventgoinguser`
--

INSERT INTO `eventgoinguser` (`event_id`, `usrid`, `email`) VALUES
(6, 5, 'Joba@gmail.com'),
(4, 5, 'nyk.com.sg@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `eventreports`
--

CREATE TABLE `eventreports` (
  `ERid` int(11) NOT NULL,
  `EReid` int(11) NOT NULL,
  `ERuid` int(11) NOT NULL,
  `Hevent` varchar(256) NOT NULL COMMENT 'Host',
  `Devent` text NOT NULL COMMENT 'Description',
  `Cevent` text NOT NULL COMMENT 'Contacts',
  `ERstatus` varchar(256) NOT NULL,
  `ERdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_event` datetime NOT NULL,
  `end_event` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_color` varchar(10) NOT NULL DEFAULT '#2ae26a',
  `weblink` varchar(256) DEFAULT 'Not Provided',
  `borderColor` varchar(10) NOT NULL DEFAULT '#000000'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `start_event`, `end_event`, `user_id`, `event_color`, `weblink`, `borderColor`) VALUES
(28, 'w', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 4, '#2ae26a', 'Not Provided', '#000000'),
(29, 'asd', '2021-03-26 00:00:00', '2021-03-27 00:00:00', 4, '#2ae26a', 'Not Provided', '#000000'),
(30, 'l', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 4, '#2ae26a', 'Not Provided', '#000000'),
(31, 's', '2021-03-26 00:00:00', '2021-03-27 00:00:00', 4, '#2ae26a', 'Not Provided', '#000000'),
(32, 'cv', '2021-03-01 00:00:00', '2021-03-02 00:00:00', 4, '#2ae26a', 'Not Provided', '#000000'),
(37, 'YK\'s blue', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 2, '#0071c5', 'Not Provided', '#000000'),
(38, 'YK\'s amraella', '2021-03-03 00:00:00', '2021-03-04 00:00:00', 2, '#FFD700', 'Not Provided', '#000000'),
(39, 'YK\'s hair', '2021-03-27 00:00:00', '2021-03-28 00:00:00', 2, '#000', 'Not Provided', '#000000'),
(56, 'Junko\'s BD', '2021-03-27 00:00:00', '2021-03-28 00:00:00', 3, '#FF8C00', 'Not Provided', '#000000'),
(60, 'Test Event', '2021-04-03 00:30:00', '2021-04-03 04:00:00', 7, '#0071c5', 'Not Provided', '#000000'),
(62, 'Bruno Mar\'s concept', '2021-03-25 00:00:00', '2021-03-26 00:00:00', 5, '#0071c5', 'Not Provided', '#000000'),
(64, 'test test', '2021-04-10 00:00:00', '2021-04-11 00:00:00', 8, '#0071c5', 'Not Provided', '#000000'),
(81, 'George\'s Vanaa', '2021-04-09 23:00:00', '2021-04-09 23:30:00', 5, '#0071c5', 'Not Provided', '#000000'),
(85, 'Lomalo', '2021-03-31 11:00:00', '2021-04-01 11:00:00', 7, '#ff6347', 'Not Provided', '#000000'),
(89, 'WorkTalk', '2021-04-14 11:30:00', '2021-04-14 14:30:00', 8, '#0071c5', 'Not Provided', '#000000'),
(93, 'Banana\'s picker', '2021-04-10 02:30:00', '2021-04-10 04:00:00', 5, '#FFD700', 'Not Provided', '#000000'),
(103, 'Test', '2021-04-08 00:00:00', '2021-04-09 00:00:00', 4, '#0071c5', 'Test', '#000000');

-- --------------------------------------------------------

--
-- Table structure for table `friendstatus`
--

CREATE TABLE `friendstatus` (
  `FRuids` int(11) NOT NULL,
  `FRuidr` int(11) NOT NULL,
  `FRstatus` varchar(20) NOT NULL,
  `FRdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendstatus`
--

INSERT INTO `friendstatus` (`FRuids`, `FRuidr`, `FRstatus`, `FRdate`) VALUES
(1, 4, 'accepted', '2021-04-07 23:24:05'),
(1, 5, 'accepted', '2021-03-29 00:50:17'),
(1, 6, 'accepted', '2021-04-09 01:26:24'),
(2, 1, 'accepted', '2021-03-25 11:40:49'),
(2, 3, 'accepted', '2021-03-26 20:35:36'),
(3, 1, 'accepted', '2021-03-25 14:14:40'),
(4, 7, 'accepted', '2021-04-07 23:45:43'),
(4, 8, 'pending', '2021-04-10 15:43:36'),
(7, 1, 'accepted', '2021-04-07 23:23:58'),
(8, 1, 'accepted', '2021-04-08 18:01:06');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `Lid` int(11) NOT NULL,
  `Lname` varchar(256) NOT NULL,
  `Lcdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`Lid`, `Lname`, `Lcdate`) VALUES
(1, 'Singapore', '2021-03-28 08:16:55'),
(2, 'Australia', '2021-03-28 08:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `nid` int(11) NOT NULL,
  `nuid` int(11) NOT NULL,
  `ntype` varchar(11) NOT NULL,
  `nmessage` text NOT NULL,
  `nstatus` varchar(11) NOT NULL,
  `ndate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table to store notifications on the website.';

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`nid`, `nuid`, `ntype`, `nmessage`, `nstatus`, `ndate`) VALUES
(6, 1, 'friend', 'You have a friend request from Melissa Low', 'read', '2021-03-25 11:40:49'),
(7, 1, 'friend', 'You have a friend request from Liang Chai', 'read', '2021-03-25 14:14:40'),
(8, 3, 'friend', 'You have a friend request from Melissa Low', 'read', '2021-03-26 20:35:36'),
(9, 5, 'friend', 'You have a friend request from Ng Yong Kang', 'read', '2021-03-29 00:50:17'),
(11, 1, 'friend', 'You have a friend request from Doris', 'read', '2021-04-07 23:23:58'),
(12, 4, 'friend', 'You have a friend request from Ng Yong Kang', 'read', '2021-04-07 23:24:05'),
(13, 7, 'friend', 'You have a friend request from Joshua', 'read', '2021-04-07 23:45:43'),
(14, 1, 'research', 'Joshua has joined your research project.', 'read', '2021-04-08 12:20:40'),
(15, 1, 'research', 'Joshua has joined your research project.', 'read', '2021-04-08 12:56:10'),
(16, 1, 'research', 'Joshua has joined your research project.', 'read', '2021-04-08 12:58:52'),
(17, 1, 'research', 'Joshua has left your research project.', 'read', '2021-04-08 12:58:56'),
(25, 7, 'research', 'Ng Yong Kang has joined your research project.', 'read', '2021-04-08 13:19:06'),
(26, 7, 'research', 'Ng Yong Kang has left your research project.', 'read', '2021-04-08 13:20:14'),
(27, 4, 'research', 'Ng Yong Kang has joined your research project.', 'read', '2021-04-08 13:20:37'),
(28, 7, 'research', 'Ng Yong Kang has joined your research project.', 'read', '2021-04-08 13:48:12'),
(29, 7, 'research', 'Ng Yong Kang has left your research project.', 'read', '2021-04-08 13:52:02'),
(31, 1, 'research', 'Joshua has joined your research project.', 'read', '2021-04-08 17:48:32'),
(32, 7, 'research', 'Sahana has joined your research project.', 'read', '2021-04-08 17:59:14'),
(33, 7, 'research', 'Sahana has left your research project.', 'read', '2021-04-08 17:59:22'),
(34, 1, 'friend', 'You have a friend request from Sahana', 'read', '2021-04-08 18:01:06'),
(35, 7, 'research', 'Sahana has joined your research project.', 'read', '2021-04-08 18:01:33'),
(36, 1, 'comment', 'Array has commented on your research project called This is a research yk created', 'read', '2021-04-09 00:33:17'),
(37, 1, 'comment', 'Ng Yong Kang has commented on your research project called This is a research yk created', 'read', '2021-04-09 00:42:48'),
(38, 1, 'comment', 'Ng Yong Kang has commented on your research project called This is a research yk created.', 'unread', '2021-04-09 00:59:27'),
(39, 8, 'comment', 'Ng Yong Kang has commented on your research project called  Factors affecting nursing student s sleep  .', 'read', '2021-04-09 01:09:18'),
(40, 8, 'comment', 'Ng Yong Kang has commented on your research project called  Factors affecting nursing student s sleep  .', 'read', '2021-04-09 01:09:27'),
(41, 8, 'comment', 'Ng Yong Kang has commented on your research project called  Factors affecting nursing student s sleep  .', 'read', '2021-04-09 01:09:48'),
(42, 8, 'comment', 'Sahana has commented on your research project called  Factors affecting nursing student s sleep  .', 'read', '2021-04-09 01:10:25'),
(43, 8, 'comment', 'Doris has commented on your research project called  Factors affecting nursing student s sleep  .', 'read', '2021-04-09 01:10:35'),
(44, 8, 'comment', 'Doris has commented on your research project called  Factors affecting nursing student s sleep  .', 'read', '2021-04-09 01:10:47'),
(45, 1, 'comment', 'Doris has commented on your research project called  This is a research yk created .', 'unread', '2021-04-09 01:11:14'),
(46, 1, 'comment', 'Doris has commented on your research project called  This is a research yk created .', 'unread', '2021-04-09 01:11:26'),
(47, 7, 'comment', 'Ng Yong Kang has commented on your research project called  MuWorld Social Website .', 'read', '2021-04-09 01:11:56'),
(48, 4, 'comment', 'Ng Yong Kang has commented on your research project called  Mu World .', 'read', '2021-04-09 01:12:57'),
(49, 4, 'comment', 'Ng Yong Kang has commented on your research project called  Mu World .', 'read', '2021-04-09 01:13:02'),
(50, 4, 'comment', 'Ng Yong Kang has commented on your research project called  Mu World .', 'read', '2021-04-09 01:13:08'),
(51, 4, 'comment', 'Ng Yong Kang has commented on your research project called  Mu World .', 'read', '2021-04-09 01:13:13'),
(52, 7, 'comment', 'Sahana has commented on your research project called  MuWorld Social Website .', 'read', '2021-04-09 01:17:53'),
(53, 7, 'comment', 'Ng Yong Kang has commented on your research project called  MuWorld Social Website .', 'read', '2021-04-09 01:18:18'),
(54, 7, 'comment', 'Sahana has commented on your research project called  MuWorld Social Website .', 'read', '2021-04-09 01:18:33'),
(55, 7, 'comment', 'Sahana has commented on your research project called  MuWorld Social Website .', 'read', '2021-04-09 01:23:22'),
(56, 6, 'friend', 'You have a friend request from Ng Yong Kang', 'read', '2021-04-09 01:26:24'),
(57, 8, 'comment', 'Vicky has commented on your research project called  Factors affecting nursing student s sleep  .', 'unread', '2021-04-09 01:29:38'),
(58, 8, 'research', 'Vicky has joined your research project.', 'unread', '2021-04-09 01:29:43'),
(59, 6, 'comment', 'Doris has commented on your research project called  Murdoch Focused Research .', 'unread', '2021-04-09 01:30:00'),
(60, 6, 'comment', 'Ng Yong Kang has commented on your research project called  Murdoch Focused Research .', 'unread', '2021-04-09 01:30:04'),
(61, 6, 'research', 'Ng Yong Kang has joined your research project.', 'unread', '2021-04-09 01:30:07'),
(62, 6, 'comment', 'Doris has commented on your research project called  Murdoch Focused Research .', 'unread', '2021-04-09 01:30:13'),
(63, 6, 'comment', 'Doris has commented on your research project called  Murdoch Focused Research .', 'unread', '2021-04-09 01:30:23'),
(64, 6, 'comment', 'Sahana has commented on your research project called  Murdoch Focused Research .', 'unread', '2021-04-09 01:30:48'),
(69, 8, 'comment', 'Doris has commented on your research project called  Factors affecting nursing student s sleep  .', 'unread', '2021-04-09 02:03:39'),
(70, 7, 'comment', 'Doris has commented on your research project called  Research on Dogs .', 'read', '2021-04-09 02:03:58'),
(71, 3, 'comment', 'Ng Yong Kang has commented on your research project called  YK is a ladyboy (FUN FACT) .', 'unread', '2021-04-09 18:05:21'),
(72, 3, 'comment', 'Ng Yong Kang has commented on your research project called  YK is a ladyboy (FUN FACT) .', 'unread', '2021-04-09 18:07:44'),
(76, 1, 'report', 'Admin has rejected your report on the following event called Time to buy witcher 3.', 'read', '2021-04-10 04:33:08'),
(77, 1, 'report', 'Admin has rejected your report on the following event called Time to buy witcher 3.', 'read', '2021-04-10 04:40:01'),
(78, 1, 'report', 'Admin has accepted your report on the following event called Time to buy witcher 3.', 'read', '2021-04-10 04:40:13'),
(79, 4, 'comment', 'Joshua has commented on your research project called  Create example research .', 'read', '2021-04-10 15:36:21'),
(80, 7, 'research', 'Joshua has joined your research project.', 'unread', '2021-04-10 15:41:17'),
(81, 8, 'friend', 'You have a friend request from Joshua', 'unread', '2021-04-10 15:43:36'),
(82, 4, 'report', 'Admin has rejected your report on the following event called Time to buy witcher 3.', 'read', '2021-04-10 15:46:43');

-- --------------------------------------------------------

--
-- Table structure for table `occupations`
--

CREATE TABLE `occupations` (
  `Oid` int(11) NOT NULL,
  `Oname` varchar(256) NOT NULL,
  `Ocdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `occupations`
--

INSERT INTO `occupations` (`Oid`, `Oname`, `Ocdate`) VALUES
(1, 'Student', '2021-03-28 08:56:35'),
(2, 'Researcher', '2021-03-28 08:56:35'),
(3, 'Staff', '2021-03-28 08:56:46');

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE `organisations` (
  `orgid` int(11) NOT NULL,
  `orgname` varchar(256) NOT NULL,
  `orgemail` varchar(256) NOT NULL,
  `orgcontact` varchar(20) NOT NULL,
  `orgaddress` varchar(256) NOT NULL,
  `orglink` varchar(256) NOT NULL,
  `orgindustry` varchar(256) NOT NULL,
  `orgcdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organisations`
--

INSERT INTO `organisations` (`orgid`, `orgname`, `orgemail`, `orgcontact`, `orgaddress`, `orglink`, `orgindustry`, `orgcdate`) VALUES
(1, 'Murdoch University', 'mu@g.com', '+65 2324 4545', 'Perth', 'https://www.murdoch.edu.au/', 'University', '2021-03-28 20:51:07'),
(2, 'Kaplan (SG)', 'kaplan@g.com', '+65 0843 3445', 'Wilkie', 'https://www.kaplan.com.sg/', 'Private School', '2021-04-08 17:25:49'),
(3, 'Google', 'gg@g.com', '+65 3534 4563', 'California', 'https://www.google.com/', 'Search Engine', '2021-04-09 18:53:47'),
(4, 'McDonald', 'mcd@g.com', '+65 7848 1234', 'Chicago', 'https://www.mcdonalds.com.sg/', 'Fast Food', '2021-04-09 20:05:12'),
(5, 'Facebook', 'fb@g.com', '+65 1234 5678', 'Menlo Park', 'https://www.facebook.com/', 'Social Network', '2021-04-10 00:36:41');

-- --------------------------------------------------------

--
-- Table structure for table `orgdep`
--

CREATE TABLE `orgdep` (
  `ODorgid` int(11) NOT NULL,
  `ODDid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orgdep`
--

INSERT INTO `orgdep` (`ODorgid`, `ODDid`) VALUES
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `ID` int(11) NOT NULL COMMENT 'Foreign Key From user table',
  `Organisation` int(11) DEFAULT NULL COMMENT 'Foreign Key from organisations table.',
  `Department` int(11) DEFAULT NULL COMMENT 'Foreign key from departments table.',
  `Education` varchar(256) DEFAULT NULL,
  `Location` text DEFAULT NULL,
  `Occupation` text DEFAULT NULL,
  `ProfilePicture` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`ID`, `Organisation`, `Department`, `Education`, `Location`, `Occupation`, `ProfilePicture`) VALUES
(1, 2, 2, 'Double Degree in Computer Science & Cyber Forensics', 'Singapore', 'Student', 'unr_mionkll_210213_0159_2rnqlag.png'),
(2, NULL, NULL, 'Double Degree in Marketing & Sales', 'Singapore, Toa Payoh street 10 (310213)', 'Website Engineer', 'user3-128x128.jpg'),
(3, NULL, NULL, NULL, NULL, NULL, 'CHAIAHHHH.jpeg'),
(4, 1, 2, NULL, NULL, 'Student', 'unr_kylepalacios_210128_0058_zskm9.png'),
(5, NULL, NULL, NULL, NULL, NULL, 'IMG_E3326.JPG'),
(6, 1, NULL, NULL, 'Singapore', 'Student', 'LOL.jpg'),
(7, 2, 2, NULL, 'Australia', 'Researcher', 'seth-doyle-uJ8LNVCBjFQ-unsplash.jpg'),
(8, 1, NULL, NULL, 'Singapore', 'Staff', 'IMG-20141219-WA0050.jpg'),
(9, NULL, NULL, NULL, NULL, NULL, NULL),
(10, NULL, NULL, NULL, NULL, NULL, NULL),
(11, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE `research` (
  `rid` int(11) NOT NULL,
  `rtitle` varchar(256) NOT NULL,
  `rdescript` text NOT NULL,
  `rlink` varchar(256) DEFAULT NULL,
  `rorg` int(11) DEFAULT NULL COMMENT 'Foreign Key from organisations table.',
  `rcreator` int(11) NOT NULL COMMENT 'Foreign key from user table',
  `rcdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `research`
--

INSERT INTO `research` (`rid`, `rtitle`, `rdescript`, `rlink`, `rorg`, `rcreator`, `rcdate`) VALUES
(4, 'Research on monkeys', 'Researching monkeys buttocks...', 'https://www.yahoo.com/', 1, 2, '2021-03-25 00:00:00'),
(5, 'Research on Chefs in Singapore', 'Research is made to analyze the many difficulties a Chef in Singapore faces.', 'https://www.msn.com/', 1, 3, '2021-03-27 11:32:13'),
(7, 'Mu World', 'A research project to create a website to allow researchers to collaborate and stay connected, this project will be used to provide a baseline on how to do so and executed on a later date.', 'http://localhost/index.php', 1, 4, '2021-03-28 19:23:15'),
(16, 'Factors affecting nursing student\'s sleep ', 'This is a research about the factors affecting students sleep who are currently studying nursing.', 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6286721/', 1, 8, '2021-04-08 18:05:33'),
(17, 'Murdoch Focused Research', 'Murdoch is a research-led university, which focuses on multidisciplinary translational research with real-life impact. We apply new knowledge from the lab and insights from public policy debates to real world challenges, improving business, policy, practice and outcomes. Everything we do is focused on better serving society and supporting the environments we live in.', 'https://www.murdoch.edu.au/research/research-focus', 1, 6, '2021-04-09 01:24:16'),
(20, 'Research on Dogs', 'rawr', 'https://www.fairprice.com.sg/', 1, 7, '2021-04-09 01:36:18');

-- --------------------------------------------------------

--
-- Table structure for table `researchusers`
--

CREATE TABLE `researchusers` (
  `RUrid` int(11) NOT NULL,
  `RUuid` int(11) NOT NULL,
  `RUstatus` varchar(11) NOT NULL,
  `RUdate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `researchusers`
--

INSERT INTO `researchusers` (`RUrid`, `RUuid`, `RUstatus`, `RUdate`) VALUES
(4, 2, 'Admin', '2021-03-27 19:12:32'),
(4, 4, 'Member', '2021-04-07 13:51:03'),
(5, 1, 'Member', '2021-03-27 21:41:01'),
(5, 3, 'Admin', '2021-03-27 19:12:32'),
(5, 7, 'Member', '2021-04-08 03:07:33'),
(7, 1, 'Member', '2021-03-28 19:25:48'),
(7, 4, 'Admin', '2021-03-28 19:23:15'),
(7, 5, 'Member', '2021-03-28 19:30:59'),
(7, 6, 'Member', '2021-03-28 19:40:36'),
(7, 7, 'Member', '2021-04-07 19:56:28'),
(7, 8, 'Member', '2021-03-28 19:45:23'),
(16, 6, 'Member', '2021-04-09 01:29:43'),
(16, 8, 'Admin', '2021-04-08 18:05:33'),
(17, 1, 'Member', '2021-04-09 01:30:07'),
(17, 6, 'Admin', '2021-04-09 01:24:16'),
(20, 4, 'Member', '2021-04-10 15:41:17'),
(20, 7, 'Admin', '2021-04-09 01:36:18');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `sid` int(11) NOT NULL,
  `sname` varchar(256) NOT NULL,
  `scategory` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`sid`, `sname`, `scategory`) VALUES
(1, 'HTML', 'Programming Language'),
(2, 'Javascript', 'Programming Language'),
(3, 'PHP', 'Programming Language'),
(4, 'Sales', 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `skillsuser`
--

CREATE TABLE `skillsuser` (
  `SUsid` int(11) NOT NULL,
  `SUuid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skillsuser`
--

INSERT INTO `skillsuser` (`SUsid`, `SUuid`) VALUES
(1, 1),
(1, 8),
(2, 1),
(3, 2),
(4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Name` varchar(256) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `Password` varchar(256) NOT NULL,
  `Token` varchar(256) NOT NULL,
  `Verified` tinyint(1) NOT NULL DEFAULT 0,
  `CreateDate` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Email`, `Password`, `Token`, `Verified`, `CreateDate`) VALUES
(1, 'Ng Yong Kang', 'nyk.com.sg@gmail.com', '$2y$10$xl7Mv5ULT9VCnoYuEgVl7eKErgJIRUgeyUHiS5fVjPJSPnfQbHZrG', 'c2a4c741cbefdb5284f45553989125f8', 1, '2021-03-19 23:12:42.931176'),
(2, 'Melissa Low', 'nykslashbaka@gmail.com', '$2y$10$Y4KwMzSxq88YOZBhbgLsv..kTAvs/qqj7uSsLSuBkoPQVNq8I/Ghi', 'ab258a2a44d8ecc3b75ff5201f22ee95', 1, '2021-03-25 03:32:10.074092'),
(3, 'Liang Chai', 'lc@gmail.com', '$2y$10$Ip8OGFwU6TabXgQGtnfbZ.SaixwVHVKbgA1WVfiSD4dfVJNF2tLOG', 'a2448283b0b8d51ccffb81b44e4f2c07', 1, '2021-03-25 06:13:26.069540'),
(4, 'Joshua', 'j@gmail.com', '$2y$10$5ssGPu0aFl.lmkS7WIwpH.2IHPhneWmYAr1YKhi/RULjpg7FDYacm', '896010de9d955ee0c976c9daab4be196', 1, '2021-03-28 11:15:00.413777'),
(5, 'Charles', 'c@gmail.com', '$2y$10$A7HrbEuvpcKrwOq70urfn.DytCpFnY.o1KREiB/FSh0cxXAxf5QRa', '5ce8fc049c802a892e0886d667fdcd96', 1, '2021-03-28 11:29:40.626232'),
(6, 'Vicky', 'v@gmail.com', '$2y$10$EJWkPp0CI2lQ166dhU/AuOBdx4.lVzfZoHBpFYNLQkEBTpyhwBr02', '60ab8e1877d7e801b1dbf36658ea1ec6', 1, '2021-03-28 11:39:38.969578'),
(7, 'Doris', 'd@gmail.com', '$2y$10$4rAsYdaEKeUvNXrfO7pxnOCqYqNiBOeaXn8RdGmxidygKo8hqxBfO', '7267ad5cc5f808b098e2e54d94be6922', 1, '2021-03-28 11:41:05.817528'),
(8, 'Sahana', 's@gmail.com', '$2y$10$m/YThdNE48a8VtZPtJHtwe0Y3uuD2PwrQWcEFR56zs2ZFMN0inKOK', '454631628bb2238a83f795e76aba1fcd', 1, '2021-03-28 11:44:04.226488'),
(9, 'Joshua', 'joshualuis.alas@gmail.com', '$2y$10$UDMFxiJK0eHB1R8/DBrWo.iYrei2xu9sXB/NHUFkzpmzhHoe5TIu2', '6a812d17b1e71fc75b4e0e491493c5fd', 0, '2021-04-05 02:47:47.274223'),
(10, 'Doris', 'doris_3_@hotmail.com', '$2y$10$4ODUWyT2rzdlieIf5P/2CuZXZeo6hrAlcpxD2rVw.gVFqBUrC.qiS', '29f19a772c8ac8d89b50d87d6393c9a7', 0, '2021-04-05 07:40:37.845517'),
(11, 'First Name Last Name', 'test1@gmail.com', '$2y$10$OCoCtUHCe/cU4pzWZ8vaG.ahOJ8KvxoC0wOkPtVojL4eZujHuU9Ty', 'c2cf37d9932767101d90467018730c39', 0, '2021-04-07 18:29:52.469038');

-- --------------------------------------------------------

--
-- Table structure for table `uservisit`
--

CREATE TABLE `uservisit` (
  `visit_id` int(11) NOT NULL,
  `visit_name` varchar(256) NOT NULL,
  `visit_email` varchar(256) NOT NULL,
  `visit_location` varchar(256) NOT NULL,
  `visit_associationEmail` varchar(256) NOT NULL,
  `visit_duration` varchar(256) NOT NULL,
  `visit_purpose` text NOT NULL,
  `visit_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uservisit`
--

INSERT INTO `uservisit` (`visit_id`, `visit_name`, `visit_email`, `visit_location`, `visit_associationEmail`, `visit_duration`, `visit_purpose`, `visit_uid`) VALUES
(1, 'qwe', 'qwe@gmail.com', 'qwe', 'qwe', 'qwe', 'qwe', 5),
(2, 'Ng Yong Kang', 'nyk@gmail.com', 'Striphouse', 'joshu@gmail.com', '1 hour', 'To strip', 5),
(3, 'Ng Yong Kang', 'qqq@gmail.com', 'Striphouse', 'pola@gmail.com', 'qwe', 'qwe', 5),
(4, 'Ng Yong Kang', 'qqq@gmail.com', 'Striphouse', 'pola@gmail.com', 'qwe', 'qwe', 5),
(5, 'Jolly Bee', 'j@gmail.com', 'nyk house', 'nyk@gmail.com', '1 day', 'To collect debt', 5),
(6, 'v', 'vz@gmail.com', 'Howard University', 'howard@gmail.com', '1 hours', 'visit la', 5),
(7, 'Little Jay', 'lj@gmail.com', 'NYK houyse', 'banana@gmail.com', '2 hours', 'to do shit', 5),
(8, 'Joshua', 'j@gmail.com', 'Kaplan Singapore', 'c@gmail.com', '1 hour', 'Job', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_event`
--
ALTER TABLE `admin_event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comid`),
  ADD KEY `comuid` (`comuid`);

--
-- Indexes for table `comres`
--
ALTER TABLE `comres`
  ADD PRIMARY KEY (`CRcomid`,`CRrid`),
  ADD KEY `CR-link-to-research` (`CRrid`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`Did`);

--
-- Indexes for table `eventgoinguser`
--
ALTER TABLE `eventgoinguser`
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`usrid`);

--
-- Indexes for table `eventreports`
--
ALTER TABLE `eventreports`
  ADD PRIMARY KEY (`ERid`),
  ADD KEY `Eid` (`EReid`),
  ADD KEY `Uid` (`ERuid`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test` (`user_id`);

--
-- Indexes for table `friendstatus`
--
ALTER TABLE `friendstatus`
  ADD PRIMARY KEY (`FRuids`,`FRuidr`),
  ADD KEY `FR_link-to-user(r)` (`FRuidr`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`Lid`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`nid`),
  ADD KEY `nuid` (`nuid`);

--
-- Indexes for table `occupations`
--
ALTER TABLE `occupations`
  ADD PRIMARY KEY (`Oid`);

--
-- Indexes for table `organisations`
--
ALTER TABLE `organisations`
  ADD PRIMARY KEY (`orgid`);

--
-- Indexes for table `orgdep`
--
ALTER TABLE `orgdep`
  ADD PRIMARY KEY (`ODorgid`,`ODDid`),
  ADD KEY `OD-link-to-dep` (`ODDid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Organisation` (`Organisation`),
  ADD KEY `Department` (`Department`);

--
-- Indexes for table `research`
--
ALTER TABLE `research`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `r-creator` (`rcreator`),
  ADD KEY `rorg` (`rorg`);

--
-- Indexes for table `researchusers`
--
ALTER TABLE `researchusers`
  ADD PRIMARY KEY (`RUrid`,`RUuid`),
  ADD KEY `ru_link-to-user` (`RUuid`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `skillsuser`
--
ALTER TABLE `skillsuser`
  ADD PRIMARY KEY (`SUsid`,`SUuid`),
  ADD KEY `su_link-to-user` (`SUuid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `uservisit`
--
ALTER TABLE `uservisit`
  ADD PRIMARY KEY (`visit_id`),
  ADD KEY `visit_uid` (`visit_uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_event`
--
ALTER TABLE `admin_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `Did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eventreports`
--
ALTER TABLE `eventreports`
  MODIFY `ERid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `Lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `nid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `occupations`
--
ALTER TABLE `occupations`
  MODIFY `Oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `organisations`
--
ALTER TABLE `organisations`
  MODIFY `orgid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `research`
--
ALTER TABLE `research`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `uservisit`
--
ALTER TABLE `uservisit`
  MODIFY `visit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `COM-link-to-user` FOREIGN KEY (`comuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comres`
--
ALTER TABLE `comres`
  ADD CONSTRAINT `CR-link-to-comment` FOREIGN KEY (`CRcomid`) REFERENCES `comments` (`comid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `CR-link-to-research` FOREIGN KEY (`CRrid`) REFERENCES `research` (`rid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eventgoinguser`
--
ALTER TABLE `eventgoinguser`
  ADD CONSTRAINT `event_id` FOREIGN KEY (`event_id`) REFERENCES `admin_event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_id` FOREIGN KEY (`usrid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `eventreports`
--
ALTER TABLE `eventreports`
  ADD CONSTRAINT `ER-link-to-events` FOREIGN KEY (`EReid`) REFERENCES `admin_event` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ER-link-to-user` FOREIGN KEY (`ERuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `test` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `friendstatus`
--
ALTER TABLE `friendstatus`
  ADD CONSTRAINT `FR_link-to-user(r)` FOREIGN KEY (`FRuidr`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FR_link-to-user(s)` FOREIGN KEY (`FRuids`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `n_link_to_user` FOREIGN KEY (`nuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orgdep`
--
ALTER TABLE `orgdep`
  ADD CONSTRAINT `OD-link-to-dep` FOREIGN KEY (`ODDid`) REFERENCES `departments` (`Did`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `OD-link-to-org` FOREIGN KEY (`ODorgid`) REFERENCES `organisations` (`orgid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `User Department` FOREIGN KEY (`Department`) REFERENCES `departments` (`Did`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `User Organisation` FOREIGN KEY (`Organisation`) REFERENCES `organisations` (`orgid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `User Profile` FOREIGN KEY (`ID`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `research`
--
ALTER TABLE `research`
  ADD CONSTRAINT `link-to-user` FOREIGN KEY (`rcreator`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `r-link-to-org` FOREIGN KEY (`rorg`) REFERENCES `organisations` (`orgid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `researchusers`
--
ALTER TABLE `researchusers`
  ADD CONSTRAINT `ru_link-to-research` FOREIGN KEY (`RUrid`) REFERENCES `research` (`rid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_link-to-user` FOREIGN KEY (`RUuid`) REFERENCES `user` (`ID`);

--
-- Constraints for table `skillsuser`
--
ALTER TABLE `skillsuser`
  ADD CONSTRAINT `su_link-to-skills` FOREIGN KEY (`SUsid`) REFERENCES `skills` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `su_link-to-user` FOREIGN KEY (`SUuid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `uservisit`
--
ALTER TABLE `uservisit`
  ADD CONSTRAINT `visit_uid` FOREIGN KEY (`visit_uid`) REFERENCES `user` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
